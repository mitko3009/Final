/*
**********************************************************************
**
**   File: tab_indexes.sql                                                         
**   $Date: 2014/03/28 11:36:32 $                                                                     
**   $Revision: 1.5 $                                                                 
**   Description: Lists the indexes and their columns for a particular table.
**
**********************************************************************
*/

break on ind_name SKIP 1 
col column_name format a22 
col column_expression format a22 
col index_type format a22 

var vcTableName varchar2(30);
var vcColumnName varchar2(30);
  
begin
  :vcTableName := upper('&table_name');
  :vcColumnName := upper('&column_name');
end;
/

SELECT i.index_name ind_name, 
       decode(i.index_type, 'NORMAL', NULL, i.index_type) index_type, 
       ic.column_name, 
       uie.column_expression 
  FROM all_ind_columns ic, all_Ind_Expressions uie, all_indexes i 
 WHERE ic.table_name = :vcTableName
   AND ic.index_owner = :vcOwner
   AND uie.table_name(+) = ic.table_name 
   AND uie.index_name(+) = ic.index_name 
   AND uie.column_position(+) = ic.column_position 
   and uie.index_owner(+)=ic.index_owner
   and i.owner=ic.index_owner
   AND i.index_name = ic.index_name 
   AND (
     	   :vcColumnName IS NULL
   		   OR
	   		 EXISTS
	       ( 
	         SELECT 1
	           FROM all_ind_columns
	          WHERE TABLE_NAME = ic.table_name
	            AND index_name = ic.index_name
	            AND column_name like '%'||:vcColumnName||'%'
	       )
	     )  
 ORDER BY 1,ic.column_position;
