/*
**********************************************************************
**
**   File: sql_awr_id.sql                                                         
**   $Date: 2013/10/04 10:00:08 $                                                                     
**   $Revision: 1.1 $                                                                 
**   Description: Display all cursors from dba_hist_sqltext that match the search criteria (sql_text).
**
**********************************************************************
*/

column sql_text format a165
select sql_id, sql_text
  from dba_hist_sqltext
 where upper(sql_text) like upper('%&sql_text%')
;