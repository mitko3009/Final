/*
**********************************************************************
**
**   File: ses_undef.sql                                                         
**   $Date: 2013/07/16 08:40:00 $                                                                     
**   $Revision: 1.1 $                                                                 
**   Description: Undefine session id (SID) defined previously via "@@".
**
**********************************************************************
*/

undef sid