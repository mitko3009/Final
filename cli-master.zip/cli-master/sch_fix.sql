--fix tables with degree >1
SET serverout ON
BEGIN
  FOR s IN (SELECT table_name FROM user_tables WHERE DEGREE>1)
  LOOP
    dbms_output.put_line('ALTER TABLE '||s.table_name||' noparallel');
    EXECUTE IMMEDIATE 'ALTER TABLE '||s.table_name||' noparallel';
  END LOOP;
END;
/

 
--fix indexes with degree >1 
BEGIN
  FOR s IN (SELECT index_name FROM user_indexes WHERE DEGREE>1)
  LOOP
    dbms_output.put_line('ALTER INDEX '||s.index_name||' noparallel');
    EXECUTE IMMEDIATE 'ALTER INDEX '||s.index_name||' noparallel';
  END LOOP;
END;
/


--rebuild unusable indexes
DECLARE 
e VARCHAR2(300);
BEGIN
    FOR C1 IN(
      SELECT a.*, ROWNUM r 
      FROM (
        SELECT table_name, index_name
          FROM all_indexes 
         WHERE owner = USER
           AND status<>'VALID'
         ORDER BY 1,2) a
    )
    LOOP
      e:='ALTER INDEX '||c1.index_name ||' REBUILD';
      dbms_output.put_line(e);
      EXECUTE IMMEDIATE e;
    end loop;  
END;
/

quit;



