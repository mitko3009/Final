/*
**********************************************************************
**
**   File: app_ad_loads.sql                                                         
**   $Date: 2013/12/14 13:29:20 $                                                                     
**   $Revision: 1.1 $                                                                 
**   Description: List the last "N" AD loads.
**
**********************************************************************
*/

col load_from format a20
col load_to format a20
col load_begin format a20
col load_end format a20
col load_mode format a20
col load_status format a20
SELECT *                                                                       
  FROM (SELECT  id,                                                            
                to_char(load_from, 'dd/mm/yyyy hh24:mi:ss') load_from,         
                to_char(load_to, 'dd/mm/yyyy hh24:mi:ss') load_to,             
                to_char(load_begin, 'dd/mm/yyyy hh24:mi:ss') load_begin,       
                to_char(load_end, 'dd/mm/yyyy hh24:mi:ss') load_end, load_mode,
                load_status                                                    
           FROM ad_loads                                                       
          ORDER BY ID DESC)                                                    
 WHERE ROWNUM <= &ROWNUM                                                      
 ORDER BY ID
;