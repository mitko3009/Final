/*
**********************************************************************
**
**   File: opt_pack_sql.sql                                                         
**   $Date: 2017/03/06 09:42:17 $                                                                     
**   $Revision: 1.11 $                                                                 
**   Description: Get everything necessary for creation of an optimization file: get binds, get SQL and output all as an optimization file. Final goal is to automate creation of an optimization file.
**
**********************************************************************
*/

SET serverout ON
set lines 300
DECLARE
  lineLen      number:=250;
  vcSqlText    VARCHAR2(4000);
  vcHostName   VARCHAR2(100);
  vcSourceName VARCHAR2(100);
  nSourceLine NUMBER;
  vcModule VARCHAR2(100);
  vcTypeWait VARCHAR2(30);
  nElapsedTime NUMBER;
  nTypedWaitTime NUMBER;
  nTypeWaitTime NUMBER;
  nbgets NUMBER;
  nExecutions NUMBER;
  -- Local variables here
  --SQL ID of the sql before optimization
  vcOldSqlId VARCHAR2(30) := '&old_sql_id';
  --SQL ID of the sql after optimization
  vcNewSqlId VARCHAR2(30) := '&new_sql_id';  
  --print function used for strings longer than 255 characters
  PROCEDURE p(p_string IN VARCHAR2) IS
    l_string varchar2(32767) DEFAULT p_string;
  BEGIN
    LOOP
      EXIT WHEN l_string IS NULL;
      dbms_output.put_line(substr(l_string, 1, lineLen));
      l_string := substr(l_string, lineLen+1);
    END LOOP;
  END;
  procedure setLen is 
    ver varchar2(30);
  begin
    select substr(version,1,2) into ver from v$instance;
    if ver='10' then 
      lineLen:=250;--765;
    else
      lineLen:=32767/2;
    end if;
  end;
BEGIN
  --make output buffer large
  dbms_output.enable(NULL);
  setLen;
  
  SELECT instance_name||' '||host_name INTO vcHostName FROM v$instance;

  SELECT ao.object_name,
         vsql.PROGRAM_LINE#,
         vsql.MODULE,         
         vsql.EXECUTIONS,
         vsql.ELAPSED_TIME,
         vsql.BUFFER_GETS,         
         round(greatest(application_wait_time, concurrency_wait_time, cluster_wait_time, user_io_wait_time, plsql_exec_time, java_exec_time, cpu_time)),   
       CASE
          greatest(application_wait_time, concurrency_wait_time, cluster_wait_time, user_io_wait_time, plsql_exec_time, java_exec_time, cpu_time)
           WHEN application_wait_time THEN
            0
           WHEN concurrency_wait_time THEN
            1
           WHEN cluster_wait_time THEN
            2
           WHEN user_io_wait_time THEN
            3
           WHEN plsql_exec_time THEN
            4
           WHEN java_exec_time THEN
            5
           WHEN cpu_time THEN
            6
         END max_wait
    INTO vcSourceName,
         nSourceLine,
         vcModule,
         nExecutions,
         nElapsedTime,
         nbgets,         
         nTypedWaitTime,
         nTypeWaitTime
    FROM v$sql vsql, all_objects ao
   WHERE vsql.sql_id = '&&sql_id'
     AND ao.object_id (+) = vsql.program_id
     AND ROWNUM = 1;

  -- Test statements here
  dbms_output.put_line('/********************************************************************************');
  dbms_output.put_line('*********       E-mail subject: ');
  dbms_output.put_line('*********             Instance: ' || vcHostName);
  dbms_output.put_line('*********          Description: ');
  dbms_output.put_line('Problem: ');
  dbms_output.put_line('Slowness has been experienced in '|| vcModule||' module.');
  dbms_output.put_line('Analysis:');
  dbms_output.put_line('SQL &&sql_id from '||nvl(vcSourceName, vcModule) ||' module.');
/*  
  dbms_output.put_line('Execution of SQL &&sql_id is problematic due to its '
  ||(case when nExecutions>10000 then 'high number of executions: '|| nEXECUTIONS
  when nTypeWaitTime=3 then 'high IO wait time: '||nTypedWaitTime
  when nTypeWaitTime=6 then 'high CPU time: '||nTypedWaitTime
  when nbgets>100000 then 'high number of logical reads: ' ||nbgets END));
*/
  dbms_output.put_line('Suggestions:');
/*
  IF nExecutions>10000 THEN dbms_output.put_line('Could you please check if it is possible to decrease number of executions of the statement?'); 
  END IF;
*/  
  dbms_output.put_line('*********               SQL_ID: &&sql_id');
  dbms_output.put_line('*********      Program/Package: ' || vcSourceName || ' Line: ' || nSourceLine);
  dbms_output.put_line('*********              Request: ');
  dbms_output.put_line('*********               Author: ');
  dbms_output.put_line('********* Received e-mail date: ' ||
                       to_char(SYSDATE, 'dd-mm-yyyy'));
  dbms_output.put_line('*********      Resolution date: ' ||
                       to_char(SYSDATE, 'dd-mm-yyyy'));
  dbms_output.put_line('***********************************************************************************/');
  dbms_output.put(chr(10));
  dbms_output.put_line('/********************************OLD SQL*******************************************/');
  dbms_output.put(chr(10));

 
  dbms_output.put_line(chr(10));
  dbms_output.put_line('set lines 300');
  dbms_output.put_line(chr(10));
  --get bind data for the SQL
  FOR s IN (SELECT last_captured || CHR(10) ||
                   '--------------------------------' last_captured,
                   'var '||substr(name,2)||' '||replace(replace(
                     case 
                       when datatype_string like 'CHAR%' 
                       then 'VARCHAR2'||substr(datatype_string,5) 
                       else datatype_string
                     end
                   ,'2000','1000'),'4000','1000')||';'||CHR(10)||
                   'exec '||name||' := '''||value_string||''';' decl                   
              FROM (SELECT b.last_captured,
                           b.position,
                           case 
                             when substr(name,2,1) between '0' and '9'
                             then ':B'||substr(name,2,1)
                             else name
                           end name,                           
                           decode(value_string, 'NULL', NULL, value_string) value_string,
                           datatype_string
                      FROM v$sql_bind_capture b
                     WHERE b.sql_id = '&&sql_id'
                       AND last_captured > SYSDATE - 12 / 24
                     ORDER BY last_captured, position))
  LOOP
--    dbms_output.put_line(replace(replace(s.decl,'''',''''''),chr(10), ' '));
    dbms_output.put_line(s.decl);
  END LOOP;
  dbms_output.put_line(chr(10));

  --get sql text
  SELECT dbms_lob.substr(sql_fulltext, 4000, 1)
    INTO vcSqlText
    FROM v$sql
   WHERE sql_id = '&&sql_id'
     AND rownum = 1;

  p(vcSqlText);
  dbms_output.put_line(';');
  --write statement to output the plan  
  dbms_output.put_line('SELECT * FROM table(dbms_xplan.display_cursor(NULL, NULL ,''RUNSTATS_LAST +peeked_binds +cost +outline''));');
  dbms_output.put_line(chr(10));

  dbms_output.put_line(chr(10));

  dbms_output.put_line('/********************************OLD SQL*******************************************/');

  dbms_output.put_line('/********************************OLD Metrics***************************************/');
  dbms_output.put_line('/*');
  IF vcOldSqlId IS NOT NULL
  THEN
    -- print metrics of the reproduced version of the old SQL
    FOR s IN (SELECT *
                FROM TABLE(DBMS_XPLAN.display_cursor(vcOldSqlId, NULL, 'RUNSTATS_LAST +peeked_binds +cost +outline')))
    LOOP
      dbms_output.put_line(s.plan_table_output);
    END LOOP;
  END IF;  
  dbms_output.put_line('');  
  dbms_output.put_line('*/');
  dbms_output.put_line('/********************************OLD Metrics***************************************/');

  dbms_output.put_line('/********************************New SQL*******************************************/');
  IF vcNewSqlId IS NOT NULL
  THEN
    --get sql text
    SELECT dbms_lob.substr(sql_fulltext, 4000, 1) || ';'
      INTO vcSqlText
      FROM v$sql
     WHERE sql_id = vcNewSqlId
       AND rownum = 1;
  END IF;
--  dbms_output.put_line(vcSqlText);
  p(vcSqlText);

  dbms_output.put_line(';');
  dbms_output.put_line(chr(10));
  dbms_output.put_line('SELECT * FROM table(dbms_xplan.display_cursor(NULL, NULL ,''RUNSTATS_LAST +peeked_binds +cost +outline ''));');
  dbms_output.put_line(chr(10));
  dbms_output.put_line('/********************************New SQL*******************************************/');
  dbms_output.put_line('/********************************New Metrics***************************************/');
  dbms_output.put_line('/*');
  IF vcNewSqlId IS NOT NULL
  THEN
    -- print metrics of the proposed version of the old SQL
    FOR s IN (SELECT *
                FROM TABLE(DBMS_XPLAN.display_cursor(vcNewSqlId, NULL, 'RUNSTATS_LAST +peeked_binds +cost +outline ')))
    LOOP
      dbms_output.put_line(s.plan_table_output);
    END LOOP;
  END IF;
  dbms_output.put_line('');  
  dbms_output.put_line('*/');
  dbms_output.put_line('/********************************New Metrics***************************************/');
  dbms_output.put_line('/********************************Index statistics**********************************/');
  dbms_output.put_line('/*');
  dbms_output.put_line('*/');
  dbms_output.put_line('/********************************Index statistics**********************************/');
  dbms_output.put_line('/********************************Other SQLs****************************************/');
  dbms_output.put_line('/*');
  dbms_output.put_line('*/ ');
  dbms_output.put_line('/********************************Other SQLs****************************************/');
END;
/
SET serverout OFF;
