/*
**********************************************************************
**
**   File: ash.sql                                                         
**   $Date: 2013/05/15 14:44:54 $                                                                     
**   $Revision: 1.1 $                                                                 
**   Description: Execute the extended script for ASH report generation that applies a number of filters.
**
**********************************************************************
*/

@$RDBMS_HOME/rdbms/admin/ashrpti.sql
