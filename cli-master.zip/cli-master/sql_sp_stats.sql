/*
**********************************************************************
**
**   File: sql_sp_stats.sql                                                         
**   $Date: 2015/04/03 14:30:47 $                                                                     
**   $Revision: 1.2 $                                                                 
**   Description: Display SQL statistics based on Statspack data. Support filtring and grouping by different criteria.
**   Depends on: spack_def_snaps.sql
**
**********************************************************************
*/

col module format a17
col sql_id format a19;
col max_wait format a9;
col period format a11;
col "ELAP/EXEC" format 9999999.99
col "GETS/EXEC" format 9999999999.9
col "READS/EXEC" format 9999999999.9
col "ROWS/EXEC" format 9999999999.9
col GETS   format 999999999999
col READS  format 9999999999
col ROWS   format 99999999
col EXEC   format 9999999999

SELECT 'Analyzed from '|| :s_begin_time || ' to ' || :v_end_time FROM dual;

SELECT
period
, sql_id
, old_hash_value
, module
, round(delta_elapsed_time/1000000) elapsed
,  round(greatest(delta_application_wait_time, delta_concurrency_wait_time, (delta_cluster_wait_time), (delta_user_io_wait_time), (delta_plsql_exec_time), (delta_java_exec_time), (delta_cpu_time))/(greatest(delta_elapsed_time,1))*100)||'% '||
  CASE greatest(delta_application_wait_time, delta_concurrency_wait_time, (delta_cluster_wait_time), (delta_user_io_wait_time), (delta_plsql_exec_time), (delta_java_exec_time), (delta_cpu_time))
   WHEN delta_application_wait_time THEN 'app'
   WHEN delta_concurrency_wait_time THEN 'conc'
   WHEN delta_cluster_wait_time THEN 'clust'
   WHEN delta_user_io_wait_time THEN 'io'
   WHEN delta_plsql_exec_time THEN 'plsql'
   WHEN delta_java_exec_time THEN 'java'
   WHEN delta_cpu_time THEN 'cpu'
  END max_wait 
, delta_buffer_gets gets
, delta_disk_reads "READS"
, delta_rows_processed "ROWS"
, round((delta_elapsed_time/1000000)/greatest(delta_executions,1),2) "ELAP/EXEC"
, round(delta_buffer_gets/greatest(delta_executions,1),1) "GETS/EXEC"
, round(delta_disk_reads/greatest(delta_executions,1),1) "READS/EXEC"
, round(delta_rows_processed/greatest(delta_executions,1),1) "ROWS/EXEC"
, delta_executions EXEC
, plan_hash_value
from(
  select 
              decode('&&group_by',
		                 's', to_char(snap.snapid),
		                 'h', to_char(snap.begin_interval_time,'hh24:mi'),
		                 'd', to_char(snap.begin_interval_time,'yyyy/mm/dd'),
		                 'w', to_char(snap.begin_interval_time,'ww')
		               ) period
              , sql_id
              , old_hash_value
              , module
              , phv plan_hash_value
              , sum(case
                    when snap_id = &&begin_snap and prev_snap_id = -1 
                    then 0
                    else
                         case when (address != prev_address)
                                or (elapsed_time < prev_elapsed_time)
                              then elapsed_time
                              else elapsed_time - prev_elapsed_time
                         end
                    end)                  delta_elapsed_time
              , sum(case
                    when snap_id = &&begin_snap and prev_snap_id = -1 
                    then 0
                    else
                         case when (address != prev_address) 
                                or (buffer_gets < prev_buffer_gets)
                              then buffer_gets
                              else buffer_gets - prev_buffer_gets
                         end
                   end)                    delta_buffer_gets
              , sum(case
                    when snap_id = &&begin_snap and prev_snap_id = -1 
                    then 0
                    else
                         case when (address != prev_address)
                                or (disk_reads < prev_disk_reads)
                              then disk_reads
                              else disk_reads - prev_disk_reads
                         end
                    end)                   delta_disk_reads                   
              , sum(case
                    when snap_id = &&begin_snap and prev_snap_id = -1 
                    then 0
                    else
                         case when (address != prev_address)
                                or (rows_processed < prev_rows_processed)
                              then rows_processed
                              else rows_processed - prev_rows_processed
                         end
                    end)                   delta_rows_processed
              , sum(case
                    when snap_id = &&begin_snap and prev_snap_id = -1 
                    then 0
                    else
                         case when (address != prev_address)
                                or (executions < prev_executions)
                              then executions
                              else executions - prev_executions
                         end
                    end)                   delta_executions
              , sum(case
                    when snap_id = &&begin_snap and prev_snap_id = -1 
                    then 0
                    else
                         case when (address != prev_address)
                                or (cpu_time < prev_cpu_time)
                              then cpu_time
                              else cpu_time - prev_cpu_time
                         end
                    end)                  delta_cpu_time
              , sum(case
                    when snap_id = &&begin_snap and prev_snap_id = -1 
                    then 0
                    else
                         case when (address != prev_address)
                                or (parse_calls < prev_parse_calls)
                              then parse_calls
                              else parse_calls - prev_parse_calls
                         end
                    end)                   delta_parse_calls
              , max(sharable_mem)          max_sharable_mem
              , sum(case when snap_id = &&end_snap
                         then last_sharable_mem
                         else 0
                    end)                   last_sharable_mem
              , sum(case
                    when snap_id = &&begin_snap and prev_snap_id = -1 
                    then 0
                    else
                         case when (address != prev_address)
                                or (version_count < prev_version_count)
                              then version_count
                              else version_count - prev_version_count
                         end
                    end)                   delta_version_count
              , max(version_count)         max_version_count
              , sum(case when snap_id = &&end_snap
                         then last_version_count
                         else 0
                    end)                   last_version_count
              , sum(case
                    when snap_id = &&begin_snap and prev_snap_id = -1 
                    then 0
                    else
                         case when (address != prev_address)
                                or (cluster_wait_time < prev_cluster_wait_time)
                              then cluster_wait_time
                              else cluster_wait_time - prev_cluster_wait_time
                         end
                    end)                   delta_cluster_wait_time
              , sum(case
                    when snap_id = &&begin_snap and prev_snap_id = -1 
                    then 0
                    else
                         case when (address != prev_address)
                                or (application_wait_time < prev_application_wait_time)
                              then application_wait_time
                              else application_wait_time - prev_application_wait_time
                         end
                    end)                   delta_application_wait_time
              , sum(case
                    when snap_id = &&begin_snap and prev_snap_id = -1 
                    then 0
                    else
                         case when (address != prev_address)
                                or (concurrency_wait_time < prev_concurrency_wait_time)
                              then concurrency_wait_time
                              else concurrency_wait_time - prev_concurrency_wait_time
                         end
                    end)                   delta_concurrency_wait_time
              , sum(case
                    when snap_id = &&begin_snap and prev_snap_id = -1 
                    then 0
                    else
                         case when (address != prev_address)
                                or (user_io_wait_time < prev_user_io_wait_time)
                              then user_io_wait_time
                              else user_io_wait_time - prev_user_io_wait_time
                         end
                    end)                   delta_user_io_wait_time
              , sum(case
                    when snap_id = &&begin_snap and prev_snap_id = -1 
                    then 0
                    else
                         case when (address != prev_address)
                                or (plsql_exec_time < prev_plsql_exec_time)
                              then plsql_exec_time
                              else plsql_exec_time - prev_plsql_exec_time
                         end
                    end)                   delta_plsql_exec_time                     
              , sum(case
                    when snap_id = &&begin_snap and prev_snap_id = -1 
                    then 0
                    else
                         case when (address != prev_address)
                                or (java_exec_time < prev_java_exec_time)
                              then java_exec_time
                              else java_exec_time - prev_java_exec_time
                         end
                    end)                   delta_java_exec_time
          from (select /*+ first_rows */
                       -- windowing function
                       snap_id
                     , old_hash_value
                     , text_subset
                     , module
                     , sql_id
                     , (lag(snap_id, 1, -1) 
                       over (partition by old_hash_value
                                        , dbid
                                        , instance_number
                            order by snap_id))    prev_snap_id
                     , (lead(snap_id, 1, -1)
                       over (partition by old_hash_value
                                        , dbid
                                        , instance_number
                            order by snap_id))    next_snap_id
                     , address
                     ,(lag(address, 1, hextoraw(0)) 
                       over (partition by old_hash_value 
                                        , dbid
                                        , instance_number
                             order by snap_id))   prev_address
                     , buffer_gets
                     ,(lag(buffer_gets, 1, 0) 
                       over (partition by old_hash_value 
                                        , dbid
                                        , instance_number
                             order by snap_id))   prev_buffer_gets
                     , cpu_time
                     ,(lag(cpu_time, 1, 0) 
                       over (partition by old_hash_value 
                                        , dbid
                                        , instance_number
                             order by snap_id))   prev_cpu_time
                     , executions
                     ,(lag(executions, 1, 0) 
                       over (partition by old_hash_value 
                                        , dbid
                                        , instance_number
                             order by snap_id))   prev_executions
                     , elapsed_time
                     ,(lag(elapsed_time, 1, 0) 
                       over (partition by old_hash_value 
                                        , dbid
                                        , instance_number
                             order by snap_id))   prev_elapsed_time                     
                     , disk_reads
                     ,(lag(disk_reads, 1, 0) 
                       over (partition by old_hash_value 
                                        , dbid
                                        , instance_number
                             order by snap_id))   prev_disk_reads
                     , parse_calls
                     ,(lag(parse_calls, 1, 0) 
                       over (partition by old_hash_value 
                                        , dbid
                                        , instance_number
                             order by snap_id))   prev_parse_calls
                     , sharable_mem
                     ,(last_value(sharable_mem) 
                       over (partition by old_hash_value 
                                        , dbid
                                        , instance_number
                             order by snap_id))   last_sharable_mem
                     ,(lag(sharable_mem, 1, 0) 
                       over (partition by old_hash_value 
                                        , dbid
                                        , instance_number
                             order by snap_id))   prev_sharable_mem
                     , version_count
                     ,(lag(version_count, 1, 0) 
                       over (partition by old_hash_value 
                                        , dbid
                                        , instance_number
                             order by snap_id))   prev_version_count
                     ,(last_value(version_count) 
                       over (partition by old_hash_value 
                                        , dbid
                                        , instance_number
                             order by snap_id))   last_version_count
                     , cluster_wait_time
                     ,(lag(cluster_wait_time, 1, 0) 
                       over (partition by old_hash_value 
                                        , dbid
                                        , instance_number
                             order by snap_id))   prev_cluster_wait_time
                     , rows_processed
                     ,(lag(rows_processed, 1, 0) 
                       over (partition by old_hash_value 
                                        , dbid
                                        , instance_number
                             order by snap_id))   prev_rows_processed
                     , s.application_wait_time
                     ,(lag(application_wait_time, 1, 0) 
                       over (partition by old_hash_value 
                                        , dbid
                                        , instance_number
                             order by snap_id))   prev_application_wait_time
                     , s.concurrency_wait_time
                     ,(lag(concurrency_wait_time, 1, 0) 
                       over (partition by old_hash_value 
                                        , dbid
                                        , instance_number
                             order by snap_id))   prev_concurrency_wait_time
                     , s.user_io_wait_time
                     ,(lag(user_io_wait_time, 1, 0) 
                       over (partition by old_hash_value 
                                        , dbid
                                        , instance_number
                             order by snap_id))   prev_user_io_wait_time
                     , s.plsql_exec_time
                     ,(lag(plsql_exec_time, 1, 0) 
                       over (partition by old_hash_value 
                                        , dbid
                                        , instance_number
                             order by snap_id))   prev_plsql_exec_time
                     , s.java_exec_time
                     ,(lag(java_exec_time, 1, 0) 
                       over (partition by old_hash_value 
                                        , dbid
                                        , instance_number
                             order by snap_id))   prev_java_exec_time                             
                from stats$sql_summary s
               where s.snap_id between &&begin_snap and &&end_snap         
   and ('&&old_hash_value' is null or s.old_hash_value='&&old_hash_value')
   and ('&&sql_id' is null or s.sql_id='&&sql_id')
   AND ('&&sql_text' is null OR upper(sql_text) LIKE upper('%&sql_text%') ESCAPE '\')
   AND ('&&module' is null OR upper(module) LIKE upper('%&module%') ESCAPE '\')
               ) sql_summary , 
             (select snap_id snapid, snap_time, lag(snap_time, 1, null) over (order by snap_id) begin_interval_time
                from stats$snapshot snap) snap,
             (select snap_id snapid, sql_id sqlid, old_hash_value ohv, plan_hash_value phv from STATS$SQL_PLAN_USAGE) splan
               where sql_summary.snap_id=snap.snapid
               and splan.ohv (+) =sql_summary.old_hash_value
               and splan.snapid (+) = sql_summary.snap_id
        group by old_hash_value
               , module
               , phv
               , sql_id
               ,
                   decode('&group_by',
		                 's', to_char(snap.snapid),
		                 'h', to_char(snap.begin_interval_time,'hh24:mi'),
		                 'd', to_char(snap.begin_interval_time,'yyyy/mm/dd'),
		                 'w', to_char(snap.begin_interval_time,'ww')
		               )
order by decode('&group_by', '', delta_elapsed_time, max(snap.snapid)) desc                   
)
where rownum<=nvl('&rownum',20)
/*3*/;

undef module
undef sql_text
undef group_by
undef rownum
ttitle off
-- group_by (s-snap, h-hour, d-date, w-week, n-null, default-plan_hash)

