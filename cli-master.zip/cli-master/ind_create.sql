/*
**********************************************************************
**
**   File: ind_create.sql                                                         
**   $Date: 2013/12/16 12:16:30 $                                                                     
**   $Revision: 1.2 $                                                                 
**   Description: Create a test index with "test_pt_" prefix.
**
**********************************************************************
*/

SET TIMING ON;
SET serverout ON;
DECLARE
  l_prefix VARCHAR2(10) := 'TEST_'||'&&yourname'||'_';
  l_table_name VARCHAR2(30) := upper('&table_name');
  l_index_name VARCHAR2(30) := upper(l_prefix||'&index_name');
  l_fields_cvs VARCHAR2(99) := upper('&fields_csv');
  l_parallel VARCHAR2(2) := '&parallel';
  l_create_index VARCHAR2(200) := 'CREATE INDEX '||l_index_name||' ON '||l_table_name||'('||l_fields_cvs||') UNUSABLE';
  l_unlock_stats VARCHAR2(200) := 'BEGIN DBMS_STATS.UNLOCK_TABLE_STATS(USER,'''||l_table_name||'''); END;';
  l_alter_index_rebuild VARCHAR2(200) := 'ALTER INDEX '||l_index_name||' REBUILD COMPUTE STATISTICS NOLOGGING PARALLEL '||l_parallel;
  l_alter_index_logging VARCHAR2(200) := 'ALTER INDEX '||l_index_name||' LOGGING NOPARALLEL';
  l_lock_stats VARCHAR2(200) := 'BEGIN DBMS_STATS.LOCK_TABLE_STATS(USER,'''||l_table_name||'''); END;';
BEGIN
  EXECUTE IMMEDIATE l_create_index;
  EXECUTE IMMEDIATE l_unlock_stats;
  EXECUTE IMMEDIATE l_alter_index_rebuild;
  EXECUTE IMMEDIATE l_alter_index_logging;
  EXECUTE IMMEDIATE l_lock_stats;
  dbms_output.put_line(l_create_index||';');
  dbms_output.put_line(l_unlock_stats);
  dbms_output.put_line(l_alter_index_rebuild||';');
  dbms_output.put_line(l_alter_index_logging||';');
  dbms_output.put_line(l_lock_stats);    
END;
/
SET serverout OFF;
SET TIMING OFF;