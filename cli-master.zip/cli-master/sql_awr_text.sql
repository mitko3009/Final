/*
**********************************************************************
**
**   File: sql_awr_text.sql                                                         
**   $Date: 2015/05/13 14:32:08 $                                                                     
**   $Revision: 1.6 $                                                                 
**   Description: Display the AWR text of a particular SQL.
**
**********************************************************************
*/

set head off
set lines 32676

column sql_text format a32676

SELECT sql_text||chr(10)||';' sql_text, upper('sql_text_end') FROM dba_hist_sqltext s, v$database d WHERE sql_id = '&&sql_id' and s.dbid=d.dbid
;

set head on
