/*
**********************************************************************
**
**   File: ses_temp_usage.sql                                                         
**   $Date: 2017/02/09 10:45:02 $                                                                     
**   $Revision: 1.1 $                                                                 
**   Description: List sessions temp usage
**
**********************************************************************
*/


col sid format 999999
col serial# format 999999
col user_name format a20
col event format a25 truncate
col pid format a10
col spid format a10
col module format a20 truncate
col logon_time format a10
col sql_trace format a9
col machine format a10 truncate
col action format a25 truncate
col status format a17 truncate

SELECT S.sid,
       S.serial#,
       S.username, 
       S.osuser, 
       S.process pid,
       P.spid, 
       S.module,
       S.program, 
       SUM (T.blocks) * TBS.block_size / 1024 / 1024 mb_used,
       T.tablespace,
       COUNT(*) sort_ops
  FROM v$tempseg_usage T, v$session S, dba_tablespaces TBS, v$process P
 WHERE T.session_addr = S.saddr
   AND S.paddr = P.addr
   AND T.tablespace = TBS.tablespace_name
GROUP BY S.sid, S.serial#, S.username, S.osuser, S.process, P.spid, S.module, S.program, TBS.block_size, T.tablespace
ORDER BY mb_used desc
;

