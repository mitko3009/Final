/*
**********************************************************************
**
**   File: tab_gather_stats.sql                                                         
**   $Date: 2015/12/18 14:10:04 $                                                                     
**   $Revision: 1.5 $                                                                 
**   Description: Gather statistics of a table. If histogram parameter is filled in with a column name only a histogram on that column is gathered.
**
**********************************************************************
*/

DECLARE
  lTableName VARCHAR2(30) := upper('&table_name');
  lSampleSize VARCHAR2(30) := '&sample_size';
  lHistogram VARCHAR2(100) := '&histogram';
  lDegree NUMBER := greatest(nvl('&degree',1),32);
  lCascade VARCHAR2(30) := '&cascade';
  lInvalidate VARCHAR2(30) := '&invalidate';
BEGIN
	dbms_stats.gather_table_stats(ownname => USER, tabname => lTableName,
	  estimate_percent => case when lSampleSize is null then dbms_stats.auto_sample_size else to_number(lSampleSize) end,
	  method_opt => case when lHistogram is null then 'FOR ALL COLUMNS SIZE 1' else 'FOR COLUMNS '||lHistogram||' SIZE AUTO' end,
		degree => lDegree,
		cascade => case lCascade when 'true' then true else false end,
    no_invalidate => case lInvalidate when 'true' then false else true end,
	  force => true
	);
  
  dbms_output.put_line('begin
  dbms_stats.gather_table_stats(ownname => USER, tabname => '''||lTableName||''',
    estimate_percent => '||case when lSampleSize is null then 'dbms_stats.auto_sample_size' else lSampleSize end||',
    method_opt => '''||case when lHistogram is null then 'FOR ALL COLUMNS SIZE 1' else 'FOR COLUMNS '||lHistogram||' SIZE AUTO' end||''',
    degree => '||to_char(lDegree)||',
    cascade => '||case lCascade when 'true' then 'true' else 'false' end||',
    no_invalidate => '||case lInvalidate when 'true' then 'false' else 'true' end||',
    force => true
  );
end;');
END;
/
