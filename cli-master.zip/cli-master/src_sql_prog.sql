/*
**********************************************************************
** 
**   File: src_sql_prog.sql                                                         
**   $Date: 2014/09/22 14:10:29 $                                                                     
**   $Revision: 1.1 $                                                                 
**   Description: Show program information for particular sql.
**
**********************************************************************
*/

SELECT o.object_name program_name, o.object_type program_type, s.program_line#
  FROM v$sql s, all_objects o
 WHERE s.sql_id = '&sql_id'
   AND o.object_id = s.PROGRAM_ID
 ;