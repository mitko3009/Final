/*
**********************************************************************
**
**   File: trc.sql                                                         
**   $Date: 2017/06/07 13:56:38 $                                                                     
**   $Revision: 1.15 $                                                                 
**   Description: Enable/disable SQL*Trace for sessions identified by pid/sid/module. By default the current session is traced.
**
**********************************************************************
*/
SET serverout ON;

DECLARE
  nLevel NUMBER;
  nDemoLevel number;  
  vcPID varchar2(12) := '&pid'; 
  nSID number := to_number('&sid');
  vcModule varchar2(50) := '&module';
  vcTraceMethod VARCHAR2(100);
  vcPlSqlBlock VARCHAR2(1000);
  bStopTrace BOOLEAN := case when nvl('&EnableTrace_from_0_to_1_def_1','1')= '1' then false else true end;
  bBinds BOOLEAN := case when upper('&Binds_from_0_to_1_default_1')= '0' then false else true end;
  bWaits BOOLEAN := case when upper('&Waits_from_0_to_1_default_1')= '0' then false else true end;  
  vcPlans varchar2(30) := case nvl('&nplanStat_from_0_to_3_def_3','3') when '0' then 'never' when '3' then 'all_executions' when '2' then 'clever' else 'first_execution' end;
  vcNewPlan varchar2(30);
  vcDemoPlan varchar2(30);
  b1 boolean;
  b2 boolean;
  v1 varchar2(30);
  function bitor(p1 in number, p2 in number) return number is
  begin
    return (p1+p2)-bitand(p1,p2);
  end bitor;
  function calculateLevel(bW in boolean,bB in boolean, vp in varchar2, opvcNewPlan out varchar2) return number is
    nW number;
    nB number;
    nP number;
    r number:=0;
  begin
     nW:=(case when bW=true then 4 else 0 end);
     nB:=(case when bB=true then 8 else 0 end);
     r:=nw+nb-bitand(nw,nb);    
     if to_number(substr(&_O_RELEASE,1,8))<=11010000 then     
       nP:=0;     
       opvcNewPlan:='first_execution';       
     else
       if to_number(substr(&_O_RELEASE,1,8))>=11020002 then     
         --variant with all options:
         nP:=(case vp when 'all_executions' then 16 when 'never' then 32 when 'clever' then 64 else 0 end);
         --not possible to set level 64 with dbms_monitor:
         opvcNewPlan:=(case vp when 'clever'  then 'all_executions' else vp end);
       else
         nP:=(case vp when 'all_executions' then 16 when 'clever' then 16 when 'never' then 32 else 0 end);
         opvcNewPlan:=(case vp when 'all_executions' then 'all_executions' when 'clever' then 'all_executions' when 'never' then 'never' else 'first_execution' end);
       end if;
     end if;
     r:=bitor(r,nP);
     --last command:it has to be 1 in order to enable trace
     r:=case when r>0 then r else 1 end;
     return r;
  end;  
BEGIN   
  dbms_output.enable(NULL);    
  IF vcPID IS NULL AND nSID IS NULL AND vcModule IS NULL THEN
  	nSID := userenv('sid');
  END IF;
  if bStopTrace=false then   
    nLevel:=calculateLevel(bBinds, bWaits, vcPlans, vcNewPlan);          
    dbms_output.put_line('-----------------------------------------------------------------------------');
    dbms_output.put_line('Input plan_stat:'||vcPlans ||chr(10)||' used for DBMS_MONITOR Plan_stat:'|| vcNewPlan ||chr(10)||' used for DBMS_SYSTEM Level: '||nLevel ||chr(10));    
    --show table with all levels in order to be clear what has been selected:
    dbms_output.put_line(rpad('LEVEL',5,' ') ||' '||rpad('BINDS',5)  ||' ' ||rpad('WAITS',5)  ||' IN PLAN_STATS'||'   USED PLAN_STATS' );  
    dbms_output.put_line(rpad('-',5,'-') ||' '||rpad('-',5,'-')  ||' ' ||rpad('-',5,'-') ||' ' ||rpad('-',15,'-')||' ' ||rpad('-',15,'-') );
    for k in 0..3
    loop
      for j in 0..1
      loop
        for i in 0..1
        loop
          b1:=case i when 1 then true else false end;
          b2:=case j when 1 then true else false end;
          v1:=case k when 1 then 'all_executions' when 2 then 'never' when 0 then 'first_execution' else 'clever' end;
          nDemoLevel:=calculateLevel(b1, b2, v1, vcDemoPlan);        
          dbms_output.put_line(rpad(to_char(nDemoLevel),5,' ') ||' '
            ||case b1 when true then rpad('TRUE',5) when false then 'FALSE' end ||' ' 
            ||case b2 when true then rpad('TRUE',5) when false then 'FALSE' end ||' '
            || rpad(v1,15, ' ') ||' '
            || (case when nDemoLevel>=64 then v1 else vcDemoPlan end)
            ||case when b1=bBinds and b2=bWaits and v1=vcPlans and nDemoLevel=nLevel then ' <-- dbms_system ' else ' ' end
            ||case when b1=bBinds and b2=bWaits and v1=(case when vcPlans='clever' then 'all_executions' else vcPlans end) 
              and (case when nDemoLevel>=64 then v1 else vcDemoPlan end)=vcNewPlan then '<-- dbms_monitor' else ' ' end);
        end loop;  
      end loop;
    end loop;  
    --set to a plan_stat that exist for Oracle version and used method:
    vcPlans:=vcNewPlan;  
  end if;  
  --check for execute grants on trace packages:  
  BEGIN
    select /*+ optimizer_features_enable('10.2.0.5')*/table_name
      INTO vcTraceMethod
      from (
        select * 
        from (           
          select owner, table_name 
                FROM dba_tab_privs
               WHERE table_name IN ('DBMS_SYSTEM', 'DBMS_MONITOR', 'USER_TRACE', 'TRACE_CODIX_ON')
                 AND (
                      grantee = USER
                      or
                      grantee IN (select granted_role from dba_role_privs where grantee = USER)
                     )
                 AND PRIVILEGE = 'EXECUTE'
          union          
          select user owner, privilege table_name 
            FROM dba_sys_privs 
           where privilege like 'ALTER SESSION' 
             and nSID = userenv('sid')
             and ( grantee = USER
                      or
                   grantee IN (select granted_role from dba_role_privs where grantee = USER) )          
        )        
         ORDER BY CASE 
                 WHEN nSID = userenv('sid') and table_name='ALTER SESSION' THEN 0
                 WHEN table_name='DBMS_SYSTEM'                     THEN 1
                 WHEN table_name='DBMS_MONITOR'                    THEN 2
                 WHEN table_name='USER_TRACE'                      THEN 3
                 WHEN table_name='TRACE_CODIX_ON'                  THEN 4
                 ELSE 99
               END )
    WHERE rownum=1       
    ;
  EXCEPTION WHEN no_data_found THEN
  	IF nSID = userenv('sid') THEN
  		vcTraceMethod := 'ALTER SESSION';
    ELSE
      raise_application_error(-20001, 'You are not authorized to execute neither DBMS_SYSTEM nor DBMS_MONITOR!');
    END IF;
  END;
  
  dbms_output.put_line('-----------------------------------------------------------------------------');
  dbms_output.put_line('Traces (host: '||SYS_CONTEXT('USERENV','HOST')||', server_host: '||SYS_CONTEXT('USERENV','SERVER_HOST')||'):');
      
  for s in (
    SELECT s.sid, s.serial#, s.program,
           'cd '||udd.value||'; ls -l | grep -i '||lower(i.instance_name)||'_ora_'||p.spid||'.trc' trace_file
      FROM v$session s,
           v$process p,
$IF DBMS_DB_VERSION.VER_LE_10 $THEN
           (select value from v$parameter where name = 'user_dump_dest') udd,
$ELSIF DBMS_DB_VERSION.VER_LE_11 $THEN
           (select value from v$parameter where name = 'user_dump_dest') udd,
$ELSE
           (select value from v$diag_info where name = 'Diag Trace') udd,
$END          
           v$instance i
     WHERE (s.sid = nSID or nSID is null)
       AND (s.process = vcPID or vcPID is null)
       AND (s.module like '%'||vcModule||'%')
       AND s.TYPE != 'BACKGROUND'
       AND p.addr = s.paddr
  ) LOOP
    dbms_output.put_line('');
    vcPlSqlBlock := NULL;

    IF vcTraceMethod like '%DBMS_SYSTEM' THEN
      vcPlSqlBlock := 
'
begin 
  --sys.dbms_system.set_int_param_in_session(:sid, :serial#, ''max_dump_file_size'', 500*1024*1024); --> dont work on 12c
  sys.dbms_system.set_ev(:sid, :serial#, 10046, :level, '''');
end;';        
      dbms_output.put_line('EXECUTE IMMEDIATE '||vcPlSqlBlock||' USING '''||s.sid||''', '''||s.serial#||''', '||to_char(nLevel)||';');
      EXECUTE IMMEDIATE vcPlSqlBlock USING s.sid, s.serial#, nLevel;
    ELSIF vcTraceMethod like '%DBMS_MONITOR' THEN
      IF bStopTrace = false THEN

        if to_number(substr(&_O_RELEASE,1,8))>=11010000 then     
          vcPlSqlBlock :=                                               
'
begin
  sys.dbms_monitor.session_trace_enable(:sid, :serial#, waits => '||(case when bWaits = true then 'TRUE' else 'FALSE' end) ||', binds => '||(case when bBinds = true then 'TRUE' else 'FALSE' end)|| ', plan_stat=>'''||vcPlans ||''' );
end;';        
        else
          vcPlSqlBlock :=                                               
'
begin
  sys.dbms_monitor.session_trace_enable(:sid, :serial#, waits => '||(case when bWaits = true then 'TRUE' else 'FALSE' end) ||', binds => '||(case when bBinds = true then 'TRUE' else 'FALSE' end) ||');
end;';
        end if;
        dbms_output.put_line('EXECUTE IMMEDIATE '||vcPlSqlBlock||' USING '''||s.sid||''', '''||s.serial#||''';');      
        EXECUTE IMMEDIATE vcPlSqlBlock USING s.sid, s.serial#;        
      ELSE
        vcPlSqlBlock := 'begin dbms_monitor.session_trace_disable(:sid, :serial#); end;';
        dbms_output.put_line('EXECUTE IMMEDIATE '||vcPlSqlBlock||' USING '''||s.sid||''', '''||s.serial#||''';');
        EXECUTE IMMEDIATE vcPlSqlBlock USING s.sid, s.serial#;             
      END IF;                                                            
    ELSIF vcTraceMethod LIKE '%USER_TRACE' ESCAPE '\' THEN
      vcPlSqlBlock := 'begin '||vcTraceMethod||'(:sid, :serial#, :on_off); end;';
      dbms_output.put_line('EXECUTE IMMEDIATE '||vcPlSqlBlock||' USING '''||s.sid||''', '''||s.serial#||''', '''||CASE nLevel WHEN 0 THEN 'off' ELSE 'on' END||''';');
      EXECUTE IMMEDIATE vcPlSqlBlock USING s.sid, s.serial#, CASE nLevel WHEN 0 THEN 'off' ELSE 'on' END;
    ELSIF vcTraceMethod = 'DBASECU.TRACE_CODIX_ON' THEN -- dfx specific
      IF bStopTrace = false THEN
        vcPlSqlBlock := 'begin dbasecu.trace_codix_on(:sid, :serial#); end;';
      ELSE
        vcPlSqlBlock := 'begin dbasecu.trace_codix_off(:sid, :serial#); end;';
      END IF;
      
      dbms_output.put_line('EXECUTE IMMEDIATE '||vcPlSqlBlock||' USING '''||s.sid||''', '''||s.serial#||''';');
      EXECUTE IMMEDIATE vcPlSqlBlock USING s.sid, s.serial#;      
    ELSIF vcTraceMethod = 'ALTER SESSION' THEN
    	IF bStopTrace = false THEN
    		vcPlSqlBlock := 'alter session set events ''10046 trace name context forever, level '||to_char(nLevel)||'''';
    	ELSE
    		vcPlSqlBlock := 'alter session set events ''10046 trace name context off''';
    	END IF;
    	
    	dbms_output.put_line('EXECUTE IMMEDIATE '||vcPlSqlBlock);
    	EXECUTE IMMEDIATE vcPlSqlBlock;    	
    ELSE
    	raise_application_error(-20001, 'Unexpected trace method - '|| vcTraceMethod ||'!');
    END IF;
    
    dbms_output.put_line(s.trace_file);
  end loop;
  /*
  nplanStat_from_0_to_3_def_3 0:
    0 - never
    1 - first_execution
    2 - clever - if execution_time_per_sql >1min then all_executions else first_execution
    3 - all_executions 
  */
END;
/

SET serverout OFF;
