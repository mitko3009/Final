/*
**********************************************************************
**
**   File: ash_view.sql                                                         
**   $Date: 2016/01/20 15:23:21 $
**   $Revision: 1.4 $
**   Description: Query the session activity (v$active_session_history). Filter by different criteria. Uses a user defined group by clause.
**
**********************************************************************
*/

col "FROM" format a20
col "TO" format a20
col event format a25 truncate
col MODULE format a17
col perc format a4
col sid format 99999
col serial# format 9999999
col active format 9999999
col object_name format a30
col sample_time format a25

define order_by="8 desc"

var days_back number;
exec :days_back := nvl('&&days_back',0);

SELECT /*+ optimizer_features_enable('11.2.0.4')*/ *
  FROM (
				SELECT decode(COUNT(DISTINCT ash.module), 1, MAX(nvl(substr(ash.module,1,instr(ash.module,'@')-1),ash.module))) "module",
				       decode(COUNT(DISTINCT ash.sql_id), 1, MAX(ash.sql_id)) "sql_id",
				       decode(COUNT(DISTINCT ash.session_id), 1, MAX(ash.session_id)) "sid",
				       decode(COUNT(DISTINCT ash.session_serial#), 1, MAX(ash.session_serial#)) "serial#",
				       decode(COUNT(DISTINCT nvl(ash.event, ash.session_state)), 1, MAX(nvl(ash.event, ash.session_state))) "event",
				       to_char(MIN(ash.sample_time),'yyyy/mm/dd hh24:mi:ss') "from",
				       to_char(MAX(ash.sample_time),'yyyy/mm/dd hh24:mi:ss') "to",
				       COUNT(*) "active",
				       to_char(round(COUNT(*)/SUM(COUNT(*)) over()*100))||'%' "perc",
				       &&group_by
				  FROM v$active_session_history ash, all_objects o, 
               (select object_name plsql_entry_object_name, procedure_name plsql_entry_procedure_name, object_id, subprogram_id from dba_procedures) plsql_entry, 
               (select object_name plsql_object_name, procedure_name plsql_procedure_name, object_id, subprogram_id from dba_procedures) plsql_current
				 WHERE ash.sample_time between to_date(to_char(sysdate,'dd')||nvl('&&from_hhmi','0000'),'ddhh24mi')-:days_back and to_date(to_char(sysdate,'dd')||nvl('&&to_hhmi','2359'),'ddhh24mi')-:days_back
				   AND (
				         '&&module' is null 
				         	OR 
				         	upper(ash.module) LIKE upper('%&module%') ESCAPE '\' 
				         	OR 
				         	upper(ash.program) LIKE upper('%&module%') ESCAPE '\'
				         	OR
				         	upper('&&module') = 'NULL' and ash.module IS NULL
				       )
				   AND ('&&sql_id' IS NULL OR ash.sql_id = '&sql_id')
				   AND ('&&sid' IS NULL OR ash.session_id = '&sid')
				   AND ('&&event' IS NULL OR upper(nvl(ash.event, ash.session_state)) LIKE upper('%&event%') ESCAPE '\')
				   &&add_filters
				   AND o.object_id(+) = ash.current_obj#
           AND plsql_entry.object_id(+) = ash.plsql_entry_object_id
           AND plsql_entry.subprogram_id(+) = ash.plsql_entry_subprogram_id
           AND plsql_current.object_id(+) = ash.plsql_object_id
           AND plsql_current.subprogram_id(+) = ash.plsql_object_id
				 GROUP BY &group_by
				 ORDER BY &order_by
			 )
  WHERE rownum <= to_number(nvl('&&rownum','30'))
;

-- group_by extra options: object_name, plsql_object_name, plsql_procedure_name, plsql_entry_object_name, plsql_entry_procedure_name