/*
**********************************************************************
**
**   File: sys_check.sql
**   $Date: 2021/11/24 07:54:09 $
**   $Revision: 1.50 $
**   Description: Executes a number of sanity checks on various levels and reports detected problems, warnings etc.
**                There is an input parameters
**                - $1 - Optional - Name of the schema
**
**********************************************************************
*/
SET serverout ON format wrapped;
set termout off feedback off
col dv_schema new_value 1
select null dv_schema from dual where  1=2;
select nvl('&1', USER ) dv_schema from dual;
set termout on 
var bv_schema_name_begin VARCHAR2(60);
var bv_schema_name       VARCHAR2(60);
var bv_isImxSchema       NUMBER;
WHENEVER SQLERROR EXIT SQL.SQLCODE;
exec SELECT UPPER('&1') INTO :bv_schema_name FROM DUAL;
exec SELECT SYS_CONTEXT('userenv','current_schema') INTO :bv_schema_name_begin FROM DUAL;
exec SELECT count(*) INTO :bv_isImxSchema FROM (SELECT owner FROM all_tables WHERE table_name = 'G_ETUDE' AND owner=:bv_schema_name);
exec IF :bv_isImxSchema=1 THEN EXECUTE IMMEDIATE 'ALTER SESSION SET CURRENT_SCHEMA='||:bv_schema_name; ELSE raise_application_error(-20000,'Used schema :'||:bv_schema_name||' is not iMX schema. Please provide valid iMX schema name' ); END IF;
undef 1;
WHENEVER SQLERROR CONTINUE;
set feedback on

DECLARE
    ETableNotExist EXCEPTION;
    PRAGMA EXCEPTION_INIT(ETableNotExist, -942);
    major_release varchar2(2);
    detailed_release varchar2(4);
    instancename varchar2(10);
    hostname v$instance.host_name%type;
    schema_imx varchar2(10);
    vcActivite varchar2(30);
    procedure check_oracle_release;
    procedure check_oracle_statistics;
    procedure check_objects;
    procedure detect_imx_schema;
    procedure instance_metrics(business varchar2, p_metric_name varchar2,output boolean DEFAULT TRUE,threshold_ok number DEFAULT 9999999 , threshold_ugly number DEFAULT 9999999,  p_status OUT varchar2 );
    procedure instance_sga(business varchar2);
    procedure instance_parameter;
    procedure sql_statements;
    procedure instance_wait_class;
    procedure instance_session;
    procedure help;
    procedure rate_chained(output boolean DEFAULT TRUE, threshold_ok number, threshold_ugly number, p_status OUT varchar2 );
    output_level NUMBER;
    mark_problems NUMBER:=1;
    fr boolean default true; /*first row in the table output*/
    vScriptVersion VARCHAR2(60) DEFAULT '$Revision: 1.50 $  $Date: 2021/11/24 07:54:09 $';

    --output that there is a serous problem
    PROCEDURE problem(str IN VARCHAR2) IS
    BEGIN
      IF(mark_problems=1) THEN
        dbms_output.put_line('PROB: '||str);
      ELSE
        dbms_output.put_line(str);      
      END IF;
    END; 

    --output WARN - warning - level between PROB and INFO
    PROCEDURE warn(str IN VARCHAR2) IS
    BEGIN
      IF output_level>=4 THEN
        IF(mark_problems=1) THEN
          dbms_output.put_line('WARN: '||str);
        ELSE
          dbms_output.put_line(str);      
        END IF;
      END IF;
    END; 

    /*true - if we have to show warnings. NOTE: Script work differently when executed manually (with level>=4).*/    
    FUNCTION showWarn
      RETURN BOOLEAN
    IS
    BEGIN
      IF output_level>=4 THEN
        RETURN true;
      END IF;
      RETURN false;
    END showWarn;
    
    --output info - used for things that could be a problem - lowest level
    PROCEDURE info(str IN VARCHAR2) IS
    BEGIN
      IF output_level>=8 THEN
        IF(mark_problems=1) THEN
          dbms_output.put_line('INFO: '||str);
        ELSE
          dbms_output.put_line(str);      
        END IF;
      END IF;
    END;    

    /*true - if we have to show info messages*/    
    FUNCTION showInfo
      RETURN BOOLEAN
    IS
    BEGIN
      IF output_level>=8 THEN
        RETURN true;
      END IF;
      RETURN false;
    END showInfo;
    
    PROCEDURE HEAD(str IN VARCHAR2) IS
    BEGIN
      IF(mark_problems=1) THEN
        dbms_output.put_line('      '||str);
      ELSE
        dbms_output.put_line(str);      
      END IF;
    END;    
    
    procedure lined 
    is
    begin
      HEAD(rpad('*',80,'*'));
    end lined;
    
    procedure line 
    is
    begin
      HEAD(rpad('_',80,'_'));
      HEAD('');
    end line;
    procedure linee
    is
    begin
      HEAD('');
    end linee;
    
    --
    -- procedure help
    --
    procedure help
    is
    begin
      --
      HEAD('-');
      HEAD('example to start it under sqlplus : ');
      HEAD('-');
      HEAD('var status varchar2(10);');
      HEAD('set serveroutput on size 10000 ');
      HEAD('set feed off');
      HEAD('set lines 160');
      HEAD('-');
      HEAD('3 input parameters : ');
      HEAD('-');
      HEAD('1st parameter : business ==> ''debt'' or ''factoring''');
      HEAD('2nd parameter : layer (top-down methodology) ==> 2,3,4,5 or 0 ( all layers (by default))');
      HEAD('-                     layer = 2 : Instance review');
      HEAD('-                     layer = 3 : Tune Instance');
      HEAD('-                     layer = 4 : Tune Objects');
      HEAD('-                     layer = 5 : Tune SQL');
      HEAD('-');
      HEAD('To know the release of the package : ');
      HEAD('-');
      HEAD('select pck_monitoring.release_pck from dual; ');
    end;
    --
    -- ORACLE RELEASE
    --
    procedure check_oracle_release
    is
    begin
      select substr(version,1,instr(version,'.')-1), substr(version,1,instr(version,'.',1,2)-1),instance_name, host_name  into major_release, detailed_release, instancename, hostname from v$instance;
    --
    HEAD('Hostname : '||hostname||' ; Instance_name : '||instancename||' ; Major Release : '||major_release||' ; Detailed Release : '||detailed_release);
    end;
    --
    -- DETECT IMX SCHEMA
    --
    PROCEDURE detect_imx_schema
    is
    BEGIN
      SELECT :bv_schema_name INTO schema_imx FROM DUAL;
      HEAD('Current DB USER: '||USER||';   Schema IMX: '||schema_imx);
    END;
    --
    -- CHECK STATISTICS
    --
    procedure check_oracle_statistics
    is
    pending_parameter VARCHAR2(10);
    check_number      NUMBER;
    check_number_1    NUMBER;
    dynamic_sql       VARCHAR2(1000);
    begin
    --
    if major_release>='11'
    then
      select value into pending_parameter from sys.v_$parameter where name='optimizer_use_pending_statistics';
      --
      if pending_parameter ='FALSE'
      then
        if showInfo then
          lined;
          HEAD(' Statistics checking');
          lined;
          linee;
        end if;
        info('Oracle uses published statistics : OK');
      else
        lined;
        HEAD(' Statistics checking');
        lined;
        linee;
        problem('Oracle uses pending statistics : Check the reason');
      end if;
      --
      -- at this moment, to CODIX, we don't use preferences. We will see this later.
      -- check if some preferences have been created
      --
      dynamic_sql := 'select count(*) from ALL_TAB_STAT_PREFS where owner = '''||schema_imx||'''';
      execute immediate dynamic_sql into check_number;
      --
      if check_number = 0
      then
        if showInfo then line; end if;
        info('Number of created statistics preferences : ' || check_number||' ==> OK');
      else
        line; 
        problem('Number of created statistics preferences : ' || check_number||' ==> Check these created preferences');
      end if;
      --
      -- at this moment, to CODIX, we don't use extented statistics. We will see this later.
      -- check if some extented statistics  have been created
      --
      dynamic_sql := 'select count(*) from all_stat_extensions where CREATOR = '''||schema_imx||'''';
      execute immediate dynamic_sql into check_number;
      --
      if check_number = 0
      then
        if showInfo then  line; end if;
        info('Number of created extented statistics : ' || check_number||' ==> OK');
      else
        line; 
        problem('Number of created extented statistics : ' || check_number||' ==> Check these extended statistics');
      end if;
    --
    end if; -- release 11g
      --
      -- check for tables without stats
      --
      fr:=true;
      FOR C1 IN(
      SELECT at.table_name, ROWNUM r, ao.created
        FROM all_tables at, all_objects ao
       WHERE at.table_name=ao.object_name AND at.owner=schema_imx AND ao.owner=schema_imx AND at.temporary != 'Y' 
         AND NOT EXISTS (SELECT 1 FROM all_external_tables WHERE all_external_tables.owner = schema_imx AND at.table_name=all_external_tables.table_name)
         AND (at.table_name NOT LIKE 'DR$%' AND at.table_name NOT LIKE 'SYS%' AND at.table_name NOT LIKE 'BIN$%')
         AND at.table_name NOT IN ('MSG_QUEUE', 'T_ENC', 'TEL_LISTE','T_COLL_SEARCHRESULT','IMX_INSTANCE', 'CLI_DOSSIER','CHAINED_ROWS')
         AND last_analyzed IS NULL
      )
      LOOP
      IF C1.created > SYSDATE - 8 
        THEN IF fr AND showWarn THEN 
              line;
              HEAD('Check for tables without statistics:');
              linee;
              HEAD(rpad('Table name',30)||' '||rpad('Created',30,' ') );
              HEAD(rpad('-',30,'-')||' '||rpad('-',30,'-') );
              fr:=false;
             END IF;
             warn(rpad(C1.table_name,30,' ')||' '||rpad(C1.created,30,' ') );
        ELSE IF fr THEN
              line;
              HEAD('Check for tables without statistics:');
              linee;
              HEAD(rpad('Table name',30)||' '||rpad('Created',30,' ') );
              HEAD(rpad('-',30,'-')||' '||rpad('-',30,'-') );
              fr:=false;
             END IF;
             problem(rpad(C1.table_name,30,' ')||' '||rpad(C1.created,30,' ') );
     END IF;
     end loop;
      --
      -- check for indexes without stats
      --
      fr:=true;
      FOR C1 IN(
        SELECT i.table_name, i.index_name, ao.created tab_created, t.num_rows tab_num_rows
         FROM all_indexes i, all_tables t, all_objects ao
        WHERE i.table_name=t.table_name AND i.table_name=ao.object_name AND i.owner = schema_imx AND t.owner=schema_imx AND ao.owner=schema_imx AND i.temporary != 'Y'  
          AND NOT EXISTS (SELECT 1 FROM all_external_tables WHERE all_external_tables.owner = schema_imx AND i.table_name=all_external_tables.table_name)
          AND (i.table_name NOT LIKE 'DR$%' AND i.table_name NOT LIKE 'SYS%' AND i.table_name NOT LIKE 'BIN$%')
          AND i.table_name NOT IN ('MSG_QUEUE', 'T_ENC', 'TEL_LISTE','T_COLL_SEARCHRESULT', 'IMX_INSTANCE', 'CLI_DOSSIER','CHAINED_ROWS')
          AND i.last_analyzed IS NULL
      )
      LOOP
      IF ( C1.tab_created < SYSDATE - 8 OR C1.tab_num_rows > 0)
        THEN IF fr THEN
               line;
               HEAD('Check for indexes without statistics:');
               linee;
               HEAD('List of indexes without statistics:');
               linee;
               HEAD(rpad('Table name',30)||' '||rpad('Table Created',30,' ')||' '||rpad('Index name',30,' '));
               HEAD(rpad('-',30,'-')||' '||rpad('-',30,'-')||' '||rpad('-',30,'-'));
               fr:=false;
            END IF;
            problem(rpad(C1.table_name,30,' ')||' '||rpad(C1.tab_created,30,' ')||' '||rpad(C1.index_name,30,' '));
        ELSE IF fr AND showWarn THEN
               line;
               HEAD('Check for indexes without statistics:');
               linee;
               HEAD('List of indexes without statistics:');
               linee;
               HEAD(rpad('Table name',30)||' '||rpad('Table Created',30,' ')||' '||rpad('Index name',30,' '));
               fr:=false;
               HEAD(rpad('-',30,'-')||' '||rpad('-',30,'-') );
            END IF;
            warn(rpad(C1.table_name,30,' ')||' '||rpad(C1.tab_created,30,' ')||' '||rpad(C1.index_name,30,' '));
     END IF;
     end loop; 
      --
      -- check if some UNLOCKED segments are found.
      ---- check for tables with unlocked stats
      check_number:=0;
      check_number_1:=0;
      SELECT NVL(SUM(case when ao.created < SYSDATE - 8 then 1 else 0 end),0), 
             NVL(SUM(case when ao.created >= SYSDATE - 8 then 1 else 0 end),0)
        INTO check_number, check_number_1
        FROM all_tab_statistics ats, all_tables t, all_objects ao
       WHERE ats.table_name = t.table_name AND ats.table_name=ao.object_name AND ao.owner=schema_imx 
         AND ats.owner = schema_imx AND t.owner = schema_imx AND t.temporary != 'Y'
         AND (ats.table_name NOT LIKE 'DR$%' AND ats.table_name NOT LIKE 'SYS%' AND ats.table_name NOT LIKE 'BIN$%')
         AND ats.table_name NOT IN ('MSG_QUEUE', 'T_ENC', 'TEL_LISTE','T_COLL_SEARCHRESULT', 'IMX_INSTANCE', 'CLI_DOSSIER','CHAINED_ROWS')
         AND NOT EXISTS (SELECT 1 FROM all_mviews WHERE all_mviews.mview_name = ats.table_name AND all_mviews.owner = schema_imx) -- PT-20
         AND ats.stattype_locked IS NULL;
      --
      IF (check_number + check_number_1) = 0
      THEN
        if showInfo then line; end if;
        info('Number of Imx Tables where the oracle statistics are not locked : ' || check_number ||' ==> OK');
      ELSE
        IF check_number_1 > 0 AND showWarn then line;
        warn('Number of Imx Tables where the oracle statistics are not locked (Table DATE cteation >= SYSDATE-8) : ' || check_number_1||' ==> Check  the reason');
        end if;
        if check_number > 0 then line;
        problem('Number of Imx Tables where the oracle statistics are not locked (Table DATE cteation < SYSDATE-8) : ' || check_number||' ==> Check  the reason');
        end if;

        FOR C1 IN(
          SELECT ats.table_name, ROWNUM r, ao.created, (CASE WHEN created < SYSDATE - 8 THEN 1 else 0 end  ) is_prob
            FROM all_tab_statistics ats, all_tables t, all_objects ao
           WHERE ats.table_name = t.table_name AND ats.table_name=ao.object_name AND ao.owner=schema_imx 
             AND ats.owner = schema_imx AND t.owner = schema_imx AND t.temporary != 'Y'
             AND (ats.table_name NOT LIKE 'DR$%' AND ats.table_name NOT LIKE 'SYS%' AND ats.table_name NOT LIKE 'BIN$%')
             AND ats.table_name NOT IN ('MSG_QUEUE', 'T_ENC', 'TEL_LISTE','T_COLL_SEARCHRESULT', 'IMX_INSTANCE', 'CLI_DOSSIER','CHAINED_ROWS')
             AND ats.stattype_locked IS NULL
            )
        LOOP
          IF C1.is_prob = 0 AND showWarn THEN 
          IF C1.r=1
          THEN 
            linee;
            HEAD(rpad('Table name',30)||' '||rpad('Created',30,' '));
            HEAD(lpad('-',30,'-')||' '||lpad('-',30,'-'));
          END IF;
          warn(rpad(C1.table_name,30,' ')||' '||rpad(C1.created,30,' ')); 
          END IF;
          
          IF C1.is_prob = 1 THEN 
          IF C1.r=1
          THEN 
            linee;
            HEAD(rpad('Table name',30)||' '||rpad('Created',30,' '));
            HEAD(lpad('-',30,'-')||' '||lpad('-',30,'-'));
          END IF;
           problem(rpad(C1.table_name,30,' ')||' '||rpad(C1.created,30,' ')); 
          END IF;
        end loop;

      END IF;
      check_number:=0;
      check_number_1:=0;
      ---- check for indexes with unlocked stats
      SELECT NVL(SUM(case when ao.created < SYSDATE - 8 OR t.num_rows>0 then 1 else 0 end),0), 
             NVL(SUM(case when ao.created >= SYSDATE - 8 AND nvl(t.num_rows,0)=0 then 1 else 0 end),0)
        INTO check_number, check_number_1
        FROM all_ind_statistics ais, all_tables t, all_objects ao
       WHERE ais.table_name = t.table_name AND ais.table_name=ao.object_name AND ais.owner = schema_imx AND ao.owner=schema_imx AND t.owner = schema_imx  AND t.temporary != 'Y'
         AND (ais.table_name NOT LIKE 'DR$%' AND ais.table_name NOT LIKE 'SYS%' AND ais.table_name NOT LIKE 'BIN$%')
         AND (ais.index_name NOT LIKE 'SYS_IL%$' AND ais.index_name NOT LIKE 'SYS_IOT%')
         AND ais.table_name NOT IN ('MSG_QUEUE', 'T_ENC', 'TEL_LISTE','T_COLL_SEARCHRESULT', 'IMX_INSTANCE', 'CLI_DOSSIER','CHAINED_ROWS')
         AND NOT EXISTS (SELECT 1 FROM all_mviews WHERE all_mviews.mview_name = ais.table_name AND all_mviews.owner = schema_imx) -- PT-20
         AND ais.stattype_locked IS NULL;
      --  
      IF (check_number + check_number_1) = 0
      THEN
        if showInfo then line; end if;
        info('Number of Imx indexes where the oracle statistics are not locked : ' || check_number||' ==> OK');
      ELSE
        IF check_number_1 > 0 AND showWarn then line;
        warn('Number of Imx indexes where the oracle statistics are not locked (Table DATE cteation >= SYSDATE-8 and table num_rows is 0) : ' || check_number_1||' ==> Check  the reason');
        end if;
        IF check_number > 0 then line;
        problem('Number of Imx indexes where the oracle statistics are not locked (Table DATE cteation < SYSDATE-8 or table num_rows > 0) : ' || check_number||' ==> Check  the reason');
        end if;
        for C1 in (
        SELECT ais.table_name, ais.index_name, ao.created tab_created, t.num_rows tab_num_rows,  ROWNUM r
          FROM all_ind_statistics ais, all_tables t, all_objects ao
         WHERE ais.table_name = t.table_name AND ais.table_name=ao.object_name AND ais.owner = schema_imx AND ao.owner=schema_imx AND t.owner = schema_imx  AND t.temporary != 'Y'
           AND (ais.table_name NOT LIKE 'DR$%' AND ais.table_name NOT LIKE 'SYS%' AND ais.table_name NOT LIKE 'BIN$%')
           AND (ais.index_name NOT LIKE 'SYS_IL%$' AND ais.index_name NOT LIKE 'SYS_IOT%')
           AND ais.table_name NOT IN ('MSG_QUEUE', 'T_ENC', 'TEL_LISTE','T_COLL_SEARCHRESULT', 'IMX_INSTANCE', 'CLI_DOSSIER','CHAINED_ROWS')
           AND ais.stattype_locked IS NULL
            )
        LOOP
        IF C1.tab_created < SYSDATE-8 OR C1.tab_num_rows>0 
          THEN IF C1.r=1 THEN 
               HEAD('--');
               HEAD('Indexes with unlocked stats');
               HEAD('--');
               HEAD(rpad('Table name',30,' ')||' '||rpad('Table Created',30,' ')||' '||rpad('Index_name',30,' '));
               HEAD(rpad('-',30,'-')||' '||rpad('-',30,'-')||' '||rpad('-',30,'-'));
               END IF;
            problem(rpad(C1.table_name,30,' ')||' '||rpad(C1.tab_created,30,' ')||' '||rpad(C1.index_name,30,' '));
          ELSE IF showWarn THEN
               IF C1.r=1 THEN 
               HEAD('--');
               HEAD('Indexes with unlocked stats');
               HEAD('--');
               HEAD(rpad('Table name',30,' ')||' '||rpad('Table Created',30,' ')||' '||rpad('Index_name',30,' '));
               HEAD(rpad('-',30,'-')||' '||rpad('-',30,'-')||' '||rpad('-',30,'-'));
               END IF;
               warn(rpad(C1.table_name,30,' ')||' '||rpad(C1.tab_created,30,' ')||' '||rpad(C1.index_name,30,' '));
               END IF;
        END IF;
        end loop; 
      END IF;
      --
      -- check the presence of histograms
      --
      SELECT NVL(SUM(case when ao.created < SYSDATE - 8 then 1 else 0 end),0), 
             NVL(SUM(case when ao.created >= SYSDATE - 8 then 1 else 0 end),0)
        INTO check_number, check_number_1
        FROM all_tab_col_statistics atcs , 
             all_tables t, 
             all_objects ao,
             all_stat_extensions e
       WHERE atcs.table_name = t.table_name 
         AND atcs.table_name = ao.object_name
         AND t.table_name = ao.object_name
         AND atcs.owner = schema_imx  
         AND t.owner = atcs.owner
         AND ao.owner = t.owner
         AND atcs.column_name = e.extension_name(+)
         AND atcs.table_name = e.table_name(+)
         AND atcs.num_buckets > 1  
         AND t.temporary != 'Y'
         AND atcs.table_name NOT IN ('MSG_QUEUE', 'T_ENC', 'TEL_LISTE','T_COLL_SEARCHRESULT', 'IMX_INSTANCE', 'CLI_DOSSIER','CHAINED_ROWS','BUFF_EH_BATCH_OBJECTIVES')
         AND ( atcs.table_name, nvl(to_char(e.extension),atcs.column_name) ) not in ( ('G_ELEMFI','ACTIF'),
                                                                                      ('G_ELEMFI','FLAG_CTX'),
                                                                                      ('T_ENTMAIL','STEP'),
                                                                                      ('G_ENCAISSEMENT','FLAG_RECONCILIATION'),
                                                                                      ('G_ENCAISSEMENT','TRAITE'),
                                                                                      ('G_ENCAISSEMENT','(NVL("DTENCAISS_DT","DTRECEPTION_DT"))'),
                                                                                      ('F_ENTREL','ER_COM'),
                                                                                      ('G_VENTILENC','ACTIF'),
                                                                                      ('F_DETENR','ACTIF'),
                                                                                      ('F_ENTENR','EE_DOS'),
                                                                                      ('F_ENTENR','EE_MAITRE'),
                                                                                      ('F_ENTENR','(NVL("EE_VALIDE",''X'')||"EE_MAITRE"||"EE_DOS")'),
                                                                                      ('NAM_COLLECTE','ETAT'),
                                                                                      ('STAT_BKG','TYPEETAT'),
                                                                                      ('T_SE_INTERFACE','ACTION'),
                                                                                      ('G_COMMFIN','TYPE'),
                                                                                      ('G_PIECE','TYPPIECE'),
                                                                                      ('T_ENTFAX','CODE_TRAITE'),
                                                                                      ('T_ENTFAX','SENS'),
                                                                                      ('T_INTERVENANTS','REFINDIVIDU'),
                                                                                      ('G_DOSSIER','SOLDEDB'),
                                                                                      ('G_DOSSIER','ANCREFDOSS') );
      --
      IF (check_number + check_number_1) = 0
      THEN if showInfo then line; end if; info('No histogram has been gathered ==> OK');
      ELSE
        if check_number_1 > 0 AND showWarn 
          then line; warn(check_number_1||' histogram/s has/have been gathered (Table DATE cteation >= SYSDATE-8)==> check the reason');
        end if;
        if check_number > 0
          then line; problem(check_number||' histogram/s has/have been gathered (Table DATE cteation < SYSDATE-8)==> check the reason');
        end if;

        fr:=true;
        for C1 in ( SELECT atcs.table_name, 
                           nvl(to_char(e.extension),atcs.column_name) column_name, 
                           atcs.num_buckets, 
                           atcs.histogram, 
                           ao.created tab_created
                      FROM all_tab_col_statistics atcs , 
                           all_tables t, 
                           all_objects ao,
                           all_stat_extensions e
                     WHERE atcs.table_name = t.table_name 
                       AND atcs.table_name = ao.object_name
                       AND t.table_name = ao.object_name
                       AND atcs.owner = schema_imx  
                       AND t.owner = atcs.owner
                       AND ao.owner = t.owner
                       AND atcs.column_name = e.extension_name(+)
                       AND atcs.table_name = e.table_name(+)
                       AND atcs.num_buckets > 1  
                       AND t.temporary != 'Y'
                       AND atcs.table_name NOT IN ('MSG_QUEUE', 'T_ENC', 'TEL_LISTE','T_COLL_SEARCHRESULT', 'IMX_INSTANCE', 'CLI_DOSSIER','CHAINED_ROWS','BUFF_EH_BATCH_OBJECTIVES')
                       AND ( atcs.table_name, nvl(to_char(e.extension),atcs.column_name) ) not in ( ('G_ELEMFI','ACTIF'),
                                                                                                    ('G_ELEMFI','FLAG_CTX'),
                                                                                                    ('T_ENTMAIL','STEP'),
                                                                                                    ('G_ENCAISSEMENT','FLAG_RECONCILIATION'),
                                                                                                    ('G_ENCAISSEMENT','TRAITE'),
                                                                                                    ('G_ENCAISSEMENT','(NVL("DTENCAISS_DT","DTRECEPTION_DT"))'),
                                                                                                    ('F_ENTREL','ER_COM'),
                                                                                                    ('G_VENTILENC','ACTIF'),
                                                                                                    ('F_DETENR','ACTIF'),
                                                                                                    ('F_ENTENR','EE_DOS'),
                                                                                                    ('F_ENTENR','EE_MAITRE'),
                                                                                                    ('F_ENTENR','(NVL("EE_VALIDE",''X'')||"EE_MAITRE"||"EE_DOS")'),
                                                                                                    ('NAM_COLLECTE','ETAT'),
                                                                                                    ('STAT_BKG','TYPEETAT'),
                                                                                                    ('T_SE_INTERFACE','ACTION'),
                                                                                                    ('G_COMMFIN','TYPE'),
                                                                                                    ('G_PIECE','TYPPIECE'),
                                                                                                    ('T_ENTFAX','CODE_TRAITE'),
                                                                                                    ('T_ENTFAX','SENS'),
                                                                                                    ('T_INTERVENANTS','REFINDIVIDU'),
                                                                                                    ('G_DOSSIER','SOLDEDB'),
                                                                                                    ('G_DOSSIER','ANCREFDOSS') ) 
          )
        LOOP
        IF C1.tab_created < SYSDATE - 8 
          THEN 
            if fr then
            HEAD('--');
            HEAD('Table name                    '||' '||'Table created       '||' '||'Column name                   '||' '||'Num. Buckets '||'Type Histogram      ' );
            HEAD('------------------------------'||' '||'--------------------'||' '||'------------------------------'||' '||'------------ '||'--------------------' );
            fr:=false;
            end if;
            problem(rpad(C1.table_name,30,' ')||' '||rpad(C1.tab_created,20,' ')||' '||rpad(C1.column_name,30,' ')||' '||lpad(C1.num_buckets,12,' ')||' '||rpad(C1.histogram,20,' '));
          ELSE IF showWarn THEN 
                 if fr then
                 HEAD('--');
                 HEAD('Table name                    '||' '||'Table created       '||' '||'Column name                   '||' '||'Num. Buckets '||'Type Histogram      ' );
                 HEAD('------------------------------'||' '||'--------------------'||' '||'------------------------------'||' '||'------------ '||'--------------------' );
                 fr:=false;
                 end if;
                 warn(rpad(C1.table_name,30,' ')||' '||rpad(C1.tab_created,20,' ')||' '||rpad(C1.column_name,30,' ')||' '||lpad(C1.num_buckets,12,' ')||' '||rpad(C1.histogram,20,' '));
              END IF;
           END IF;
        end loop;
      END IF;      
      --
      -- check the presence of statistics on MSG_QUEUE
      --
      select count(*) into check_number from all_tables where table_name='MSG_QUEUE' and owner = schema_imx and last_analyzed is null;
      --
      if check_number = 0
      THEN
        line;
        problem('The Table MSG_QUEUE has been analyzed => Delete statisitics, check the reason');
      else
        if showInfo then line; end if;
        info('The Table MSG_QUEUE has not been analyzed ==> OK ');
      end if;
      
      --
      -- check if index PRTY_SEQ on MSG_QUEUE is rebuilded.
      --
      select count(*) into check_number from all_objects where object_name='PRTY_SEQ' and owner = schema_imx and last_ddl_time > SYSDATE-8;
      --
      if check_number = 0
      THEN
        line;
        problem('The Index PRTY_SEQ on table MSG_QUEUE has not been rebuilded => Check the reason why and rebuild it ');
      else
        if showInfo then line; end if;
        info('The Index PRTY_SEQ on table MSG_QUEUE has been rebuilded ==> OK ');
      end if;
      
      --
      -- check if the statistics on tables are STALE
      --
      SELECT count(*) into check_number 
        FROM all_tab_modifications m, all_tables t
       WHERE m.table_name=t.table_name AND m.table_owner = schema_imx AND t.owner = schema_imx AND t.temporary != 'Y'
         AND NOT EXISTS (SELECT 1 FROM all_external_tables WHERE all_external_tables.owner = schema_imx AND m.table_name=all_external_tables.table_name)
         AND (m.table_name NOT LIKE 'DR$%' AND m.table_name NOT LIKE 'SYS%' AND m.table_name NOT LIKE 'BIN$%')
         AND m.table_name NOT IN ('MSG_QUEUE', 'T_ENC', 'TEL_LISTE','T_COLL_SEARCHRESULT','IMX_INSTANCE', 'CLI_DOSSIER','CHAINED_ROWS')
         AND ROUND((m.inserts-m.deletes)/DECODE(NVL(t.num_rows,1),0,1,NVL(t.num_rows,1))*100,2)>50;
      if check_number = 0
      then
        if showInfo then line; end if;
        info('Statistics on Tables are not STALE ==> OK ');
      else
        if showWarn then line; end if;
        if check_number = 1
        then
          warn('One table contains STALE statistics ==> check ');
        else
          warn(check_number||' tables contain STALE statistics ==> check ');
        end if;
        if showWarn then head('--'); end if;          
        --
        fr:=true;
        for C1 in (SELECT m.table_name, ROUND((m.inserts-m.deletes)/DECODE(NVL(t.num_rows,1),0,1,NVL(t.num_rows,1))*100,2) modif_pct 
                     FROM all_tab_modifications m, all_tables t
                    WHERE m.table_name=t.table_name AND m.table_owner = schema_imx AND t.owner = schema_imx AND t.temporary != 'Y'
                      AND NOT EXISTS (SELECT 1 FROM all_external_tables WHERE all_external_tables.owner = schema_imx AND m.table_name=all_external_tables.table_name)
                      AND (m.table_name NOT LIKE 'DR$%' AND m.table_name NOT LIKE 'SYS%' AND m.table_name NOT LIKE 'BIN$%')
                      AND m.table_name NOT IN ('MSG_QUEUE', 'T_ENC', 'TEL_LISTE','T_COLL_SEARCHRESULT','IMX_INSTANCE', 'CLI_DOSSIER','CHAINED_ROWS')
                      AND ROUND((m.inserts-m.deletes)/DECODE(NVL(t.num_rows,1),0,1,NVL(t.num_rows,1))*100,2)>50)
        loop
          if fr and showWarn then
            head('--');
            head('List of tables with stale stats:');
            head('--');
            head('Table name                    '||' '||'Modif % ');
            head('------------------------------'||' '||'----------');
            fr:=false;
          end if;
          warn(rpad(C1.table_name,30,' ')||' '||rpad(C1.modif_pct,10,' '));
        end loop;
      end if;
      --
      -- check the data of gathering.
      --
      for C1 in ( 
        SELECT COUNT(table_name) nber_objects, trunc(last_analyzed) last_analyzed, COUNT(*) over() rcount, row_number() over(ORDER BY 1) r
          FROM all_tables
         WHERE temporary = 'N'
           AND table_name NOT IN ('MSG_QUEUE', 'T_ENC', 'TEL_LISTE','T_COLL_SEARCHRESULT', 'IMX_INSTANCE', 'CLI_DOSSIER','CHAINED_ROWS')
           AND table_name NOT LIKE 'DR$%'
           AND owner = schema_imx
         GROUP BY trunc(last_analyzed)
         ORDER BY 2
      )
      LOOP
        IF C1.rcount>1 THEN 
          IF c1.r=1 and showWarn
          THEN
            line;
            HEAD('-');
            HEAD('Many dates of gathering => check');
            HEAD('-');
            HEAD('permanent tables last_analyzed');
            HEAD('---------------- --------------------');
          END IF;
          warn(rpad(c1.nber_objects,16,' ')||' '||rpad(c1.last_analyzed,20,' '));
        ELSE
          IF c1.r=1 and showInfo
          THEN
            line;
            HEAD('-');
            HEAD('Check the date of gathering');
            HEAD('-');
            HEAD('permanent tables last_analyzed');
            HEAD('---------------- --------------------');
          END IF;
          info(rpad(c1.nber_objects,16,' ')||' '||rpad(c1.last_analyzed,20,' '));
        END IF;
      end loop;
      
      -- chack date of gathering for indexes:
      --
      for C1 in ( 
        SELECT COUNT(index_name) nber_objects, trunc(last_analyzed) last_analyzed, COUNT(*) over() rcount, row_number() over(ORDER BY 1) r
          FROM all_indexes
         WHERE temporary = 'N'
           AND table_name NOT IN ('MSG_QUEUE', 'T_ENC', 'TEL_LISTE','T_COLL_SEARCHRESULT', 'IMX_INSTANCE', 'CLI_DOSSIER','CHAINED_ROWS')
           AND owner = schema_imx
         GROUP BY trunc(last_analyzed)
         ORDER BY 2
      )
      loop
        IF C1.rcount>1 THEN
          IF c1.r=1 and showWarn
          THEN
            line;
            HEAD('-');
            HEAD('check the date of gathering');
            HEAD('-');
            HEAD('      index name last_analyzed');
            HEAD('---------------- --------------------');
          END IF;
          warn(rpad(c1.nber_objects,17,' ')||' '||rpad(c1.last_analyzed,20,' '));
        ELSE
          IF c1.r=1 and showInfo
          THEN 
            line;
            head('-');
            head('check the date of gathering');
            head('-');
            head('      index name last_analyzed');
            head('---------------- --------------------');
          END IF;
          info(rpad(c1.nber_objects,17,' ')||' '||rpad(c1.last_analyzed,20,' '));
        END IF;
      end loop;
      
      --
      -- check the SAMPLING used
      --
      -- When the ESTIMATE_PERCENT parameter is manually specified, the DBMS_STATS
      -- gathering procedures may automatically increase the sampling percentage if the
      -- specified percentage did not produce a large enough sample. This ensures the stability
      -- of the estimated values by reducing fluctuations.
      --
      -- for 10gr2 : the sample 30% must be the minimum size of sample and the maximum numver of objects must be gathered with this sample ( of course with production volumetry)
      -- for 11gR2 : in AUTO_SAMMPLING, with IMX volume, the sample size is in major part egual to 100%.
      --
      -- T_ENC ( agenda) is excluded because it is gathered to 100% by the program.
      --
      fr:=true;
      for C1 in (
        SELECT ROWNUM r, COUNT((CASE
                       WHEN subq.SAMPLE IN (30, 100) OR major_release>='11' THEN
                        NULL
                       ELSE
                        1
                     END)) over() pb_count, subq.*
          FROM (SELECT WIDTH_BUCKET(round((sample_size / num_rows) * 100), 1, 101, 10) * 10 SAMPLE, COUNT(*) number_tables, MIN(num_rows) min_rows, MAX(num_rows) max_rows, MIN(blocks) min_block, MAX(blocks) max_block
                   FROM all_tables
                  WHERE table_name != 'T_ENC'
                    AND num_rows > 1
                    AND temporary = 'N'
                    AND status = 'VALID'
                    AND owner = schema_imx
                  GROUP BY WIDTH_BUCKET(round((sample_size / num_rows) * 100), 1, 101, 10)
                  ORDER BY SAMPLE
                  ) subq
      )
      LOOP
        IF(major_release='10' AND c1.sample<>'30' AND c1.sample<>'100')
        THEN
          if fr then
            line;
            HEAD('-');
            HEAD('Distribution of oracle statistics by  sampling ( divided in buckets of 10%)');
            HEAD('-');
            HEAD('Sample Number_of_tables min_rows   max_rows   min_blocks max_blocs');
            HEAD('------ ---------------- ---------- ---------- ---------- ----------');
            fr:=false;          
          end if;
          --in version 10 we gather on 30% - if it is 100 - then probably OK too - the rest is NOK
          problem(lpad(c1.sample || ' %',6,' ')||' '||lpad(c1.number_tables,16,' ')||' '||lpad(c1.min_rows,10,' ')||' '||lpad(c1.max_rows,10,' ')||' '||lpad(c1.min_block,10,' ')||' '||lpad(c1.max_block,10,' '));
        ELSE
          if fr and showInfo then
            line;
            HEAD('-');
            HEAD('Distribution of oracle statistics by  sampling ( divided in buckets of 10%)');
            HEAD('-');
            HEAD('Sample Number_of_tables min_rows   max_rows   min_blocks max_blocs');
            HEAD('------ ---------------- ---------- ---------- ---------- ----------');
            fr:=false;          
          end if;
          info(lpad(c1.sample || ' %',6,' ')||' '||lpad(c1.number_tables,16,' ')||' '||lpad(c1.min_rows,10,' ')||' '||lpad(c1.max_rows,10,' ')||' '||lpad(c1.min_block,10,' ')||' '||lpad(c1.max_block,10,' '));       
        END IF;        
      end loop;
      
      --check of sample size for indexes      
      fr:=true;
      for C1 in (      
         SELECT ROWNUM r,COUNT((CASE
                        WHEN subq.SAMPLE IN (30, 100)
                             OR major_release >= '11' THEN
                         NULL
                        ELSE
                         1
                      END)) over() pb_count, subq.*
           FROM (SELECT lpad(WIDTH_BUCKET(round((sample_size / num_rows) * 100), 1, 101, 10) * 10, 3, 0) SAMPLE, COUNT(*) number_indexes, MIN(num_rows) min_rows, MAX(num_rows) max_rows, MIN(leaf_blocks) min_block, MAX(leaf_blocks) max_block
                    FROM all_indexes
                   WHERE num_rows > 1
                     AND temporary = 'N'
                     AND status = 'VALID'
                     AND owner = schema_imx
                   GROUP BY WIDTH_BUCKET(round((sample_size / num_rows) * 100), 1, 101, 10)
                   ORDER BY SAMPLE) subq
      )
      LOOP
        IF(major_release='10' AND c1.sample<>'30' AND c1.sample<>'100')
        THEN
          if fr then
            line;
            head('-                                                                                          ');
            head('-                                                                                          ');
            head('Sample Number_of_indexes min_rows   max_rows   min_blocks max_blocs');
            head('------ ----------------- ---------- ---------- ---------- ----------');
            fr:=false;          
          end if;
          --in version 10 we gather on 30% - if it is 100 - then probably OK too - the rest is NOK
          problem(lpad(c1.sample || ' %',6,' ')||' '||lpad(c1.number_indexes,17,' ')||' '||lpad(c1.min_rows,10,' ')||' '||lpad(c1.max_rows,10,' ')||' '||lpad(c1.min_block,10,' ')||' '||lpad(c1.max_block,10,' '));
        ELSE
          if fr and showInfo then
            line;
            head('-                                                                                          ');
            head('-                                                                                          ');
            head('Sample Number_of_indexes min_rows   max_rows   min_blocks max_blocs');
            head('------ ----------------- ---------- ---------- ---------- ----------');
            fr:=false;          
          end if;
          info(lpad(c1.sample || ' %',6,' ')||' '||lpad(c1.number_indexes,17,' ')||' '||lpad(c1.min_rows,10,' ')||' '||lpad(c1.max_rows,10,' ')||' '||lpad(c1.min_block,10,' ')||' '||lpad(c1.max_block,10,' '));
        END IF;        
      end loop;
      --
    end;
    ----------------------------------------------------------------------------------
    -- PROCECURE CHECK_OBJECTS
    ----------------------------------------------------------------------------------
    procedure check_objects
    is
    check_number number;
    dynamic_sql varchar2(1000);
    block_size number;
    chained_status varchar2(10);
    --
    begin
    --
    -- read db_block_size value
    --
    select value into block_size from v$parameter where name='db_block_size';
    --
    -- check INVISIBLE indexes
    --

    if major_release>='11'
    then      
      dynamic_sql := 'select count(*) from all_indexes where  owner = '''||schema_imx||''' and visibility=''INVISIBLE''';
      execute immediate dynamic_sql into check_number;
      if check_number = 0
      then
        if showInfo then HEAD('--'); end if;
        info('all indexes are VISIBLE :  ==> OK');
      else
        HEAD('--');      
        if check_number = 1
        then
          problem('There is '||check_number||' INVISIBLE index : ==> check the reason');
        else
          problem('There are '||check_number||' INVISIBLE indexes : ==> check the reason');
        end if;
        HEAD('--');
      end if;
    end if;
    
    --
    -- check for existence of KILL_SESSION in IMXDB schema
    --

    FOR C1 IN(    
      select owner, object_name, rownum r
      from dba_objects 
      where object_name='KILL_SESSION' and object_type='PROCEDURE' and owner<>'SYS'
      order by 1
    )
    LOOP
      IF(C1.r=1)
      THEN
        HEAD('--');
        HEAD('Procedure KILL_SESSION exists in following schemas:');
        HEAD('--');
        HEAD(rpad('Owner',30)||' '||rpad('Object_name',30,' ') );
        HEAD(rpad('-',30,'-')||' '||rpad('-',30,'-') );
      END IF;
      problem(rpad(C1.owner,30,' ') ||' '|| rpad(C1.object_name,30,' '));   
    END LOOP;
        
    --
    -- list invalid objects
    --
    
    select count(*) into check_number from all_objects where  owner = schema_imx and status != 'VALID';
    
    if check_number = 0
    then
      if showInfo then HEAD('-'); end if;
      info('all objects are VALID : ' || check_number||' ==> OK');
    else
      if showWarn then HEAD('-'); end if;
      if check_number = 1
      then
        warn('There is '||check_number||' non VALID object : ==> check the reason');
      else
        warn('There are '||check_number||' non VALID objects : ==> check the reason');
      end if;
      
      fr:=true;
      for C1 in ( 
      SELECT object_type, COUNT(*) nber_obj
        FROM all_objects
       WHERE owner = schema_imx
         AND status != 'VALID'
       GROUP BY object_type
       ORDER BY object_type
      )
      loop
        if fr and showWarn then
          HEAD('--');
          HEAD('Object type         '||' '||'Number of objects');
          HEAD('--------------------'||' '||'-----------------');
          fr:=false;
        end if;
        warn(rpad(c1.object_type,20,' ')||' '||lpad(c1.nber_obj,17,' '));
      end loop;

      fr:=true;
      for C1 in ( 
      SELECT object_type, object_name
        FROM all_objects
       WHERE owner = schema_imx
         AND status != 'VALID'       
       ORDER BY (case when object_type in ('PACKAGE','PACKAGE BODY','FUNCTION','PROCEDURE', 'TRIGGER') then 2
       else 1 end), object_type, object_name
      )
      loop
      if c1.object_type <> 'MATERIALIZED VIEW' and showWarn then
        if fr then
            HEAD('--');
            HEAD(rpad('Object type',30,' ')||' '||rpad('Object name',30,' '));
            HEAD(rpad('-',30,'-')||' '||rpad('-',30,'-'));
            fr:=false;
          end if;
        warn(rpad(c1.object_type,30,' ')||' '||lpad(c1.object_name,30,' '));
      end if;
      end loop;
    end if; 
   
    --
    -- check for not usable indexes
    --
    FOR C1 IN(
      SELECT a.*, ROWNUM r 
      FROM (
        SELECT table_name, index_name
          FROM all_indexes 
         WHERE owner = schema_imx
           AND status<>'VALID'
         ORDER BY 1,2) a
    )
    LOOP
      IF(C1.r=1)
      THEN
        HEAD('--');
        HEAD('List of UNUSABLE indexes:');
        HEAD('--');
        HEAD(rpad('Table name',30)||' '||rpad('Index name',30,' ') );
        HEAD(rpad('-',30,'-')||' '||rpad('-',30,'-') );
      END IF;
      problem(rpad(C1.table_name,30,' ') ||' '|| rpad(C1.index_name,30,' '));
    end loop;  
    
    --
    -- check if exist indexes: T_ELEM_LIBEL_ACT, ELE_LIBELLE, ELE_TYPACTIF, TEST_GK%, TEST_KV%, TEST_DI%, TEST_IS and TEST_DA%
    --
    select count(*) into check_number from all_indexes 
     where  owner = schema_imx 
      and (    index_name in ('T_ELEM_LIBEL_ACT', 'ELE_LIBELLE', 'ELE_TYPACTIF')
           OR (index_name like 'TEST\_KV%' escape '\') OR (index_name like 'TEST\_GK%' escape '\')
           OR (index_name like 'TEST\_DI%' escape '\') OR (index_name like 'TEST\_IS%' escape '\')
           OR (index_name like 'TEST\_DA%' escape '\')
           );
    IF check_number = 0
      THEN
        if showInfo then line; end if;
        info('Indexes T_ELEM_LIBEL_ACT, ELE_LIBELLE, ELE_TYPACTIF, TEST_GK%, TEST_KV%, TEST_DI%, TEST_IS% and TEST_DA% do not exist ==> OK');
      else 
        if showInfo then line; end if;
        warn('There are indexes that should be drop');
      end if;
    fr:=true;
    FOR C1 IN ( select index_name, table_name, ROWNUM r
                 from all_indexes 
                where  owner = schema_imx 
                  and (    index_name in ('T_ELEM_LIBEL_ACT', 'ELE_LIBELLE', 'ELE_TYPACTIF')
                       OR (index_name like 'TEST\_KV%' escape '\') OR (index_name like 'TEST\_GK%' escape '\')
                       OR (index_name like 'TEST\_DI%' escape '\') OR (index_name like 'TEST\_IS%' escape '\')
                       OR (index_name like 'TEST\_DA%' escape '\')
                      )
          )
    LOOP
      IF fr and showWarn
      THEN 
        HEAD('--');
        HEAD('List of WRONG indexes:');
        HEAD('--');
        HEAD(rpad('Table name',30)||' '||rpad('Index name',30,' ') );
        HEAD(rpad('-',30,'-')||' '||rpad('-',30,'-') );
        fr:=false;
      END IF;
      warn(rpad(C1.table_name,30,' ') ||' '|| rpad(C1.index_name,30,' '));
    end loop;

    --
    -- distribution of objects.
    --
    fr:=true;
    for C1 in ( select segment_type, size_seg/1024/1024 size_seg ,size_all/1024/1024 size_all, trunc(ratio*100) ratio from
    (select distinct segment_type, sum(bytes) over(partition by segment_type) size_seg, sum(bytes) over() size_all,sum(bytes) over(partition by segment_type)/sum(bytes) over()  ratio
    from DBA_segments WHERE owner = schema_imx) order by segment_type)
    loop
      if fr and showInfo then
        HEAD('-');
        HEAD('Distribution of objects in database');
        HEAD('-');
        HEAD('Segment Type'||' '||'Size (MB) of objects'||' '||'Size of all objects (MB)'||' '||'Ratio %');
        HEAD('------------'||' '||'--------------------'||' '||'------------------------'||' '||'-------');
        fr:=false;
      end if;
      info(rpad(c1.segment_type,12  ,' ')||' '||lpad(round(c1.size_seg),20,' ')||' '||lpad(round(c1.size_all),24,' ')||' '||lpad(c1.ratio,6,' ')||'%');
    end loop;

    -- check sizing objects >= 20% of the DB
    --
    fr:=true;
    for C1 in ( select segment_name, segment_type, size_seg/1024/1024 size_seg,size_all/1024/1024 size_all, trunc(ratio*100) ratio from
    ( select segment_name, segment_type,sum(bytes) over(partition by segment_name) size_seg, sum(bytes) over() size_all,sum(bytes) over(partition by segment_name)/sum(bytes) over()  ratio
    from DBA_segments where owner = schema_imx AND segment_type='TABLE') where ratio*100>=20)
    loop
      if fr and showWarn then
        head('-');
        HEAD('Objects with a size > 20% of all objects of the same type');
        HEAD('-');
        fr:=false;
      end if;
      warn(rpad(c1.segment_name,17,' ')||' '||rpad(c1.segment_type,12,' ')||' '||lpad(round(c1.size_seg),20,' ')||' '||lpad(round(c1.size_all),24,' ')||' '||lpad(c1.ratio,6,' ')||'%');
    end loop;
    --
    fr:=true;
    for C1 in ( select segment_name,segment_type, size_seg/1024/1024 size_seg,size_all/1024/1024 size_all, trunc(ratio*100) ratio from
    ( select segment_name, segment_type,sum(bytes) over(partition by segment_name) size_seg, sum(bytes) over() size_all,sum(bytes) over(partition by segment_name)/sum(bytes) over()  ratio
    from dba_segments where segment_type='INDEX' AND owner = schema_imx) where ratio*100>=20)
    loop
      if fr then
        HEAD('-');
        HEAD('Segment Name     '||' '||'Segment Type'||' '||'Size (MB) of objects'||' '||'Size of all objects (MB)'||' '||'Ratio %');
        HEAD('-----------------'||' '||'------------'||' '||'--------------------'||' '||'------------------------'||' '||'-------');
        fr:=false;
      end if;
      problem(rpad(c1.segment_name,17,' ')||' '||rpad(c1.segment_type,12,' ')||' '||lpad(round(c1.size_seg),20,' ')||' '||lpad(round(c1.size_all),24,' ')||' '||lpad(c1.ratio,6,' ')||'%');
    end loop;
    --
    -- CHECK FRAGMENTATION
    --
    fr:=true;
    for C1 in ( 
      SELECT *
        FROM (
              SELECT table_name, trunc((1 - (necessary_space / used_space)) * 100) ratio, used_space, necessary_space, blocks, empty_blocks, num_rows
                FROM (SELECT table_name, ((num_rows * (avg_row_len + 2))) / 1024 / 1024 necessary_space, 
                             blocks * block_size / 1024 / 1024 AS used_space, blocks, empty_blocks, num_rows
                         FROM all_tables
                        WHERE blocks != 0
                          AND owner = schema_imx)
               WHERE trunc((1 - (necessary_space / used_space)) * 100) >= 10
                 AND used_space > 256
               ORDER BY used_space-necessary_space DESC
              )
       WHERE rownum < 11
    )
    loop
      if fr and showWarn then
        head('-');
        head('10 first Objects with a rate of fragmenation >= 10%');
        head('-');
        --
        HEAD('Segment Name     '||' '||'Nber Rows'||' '||'Blocks below HWM'||' '||'Blocks above HWM'||' '||'Ratio       '||' '||'Size (MB) of used space'||' '||'Size (MB) of necessary space');
        HEAD('-----------------'||' '||'---------'||' '||'----------------'||' '||'----------------'||' '||'------------'||' '||'-----------------------'||' '||'----------------------------');
        fr:=false;
      end if;
      warn(rpad(c1.table_name,17,' ')||' '||rpad(c1.num_rows,9,' ')||' '||rpad(c1.blocks,16,' ')||' '||rpad(c1.empty_blocks,16,' ')||' '||rpad(c1.ratio,12,' ')||' '||lpad(round(c1.used_space),24,' ')||' '||lpad(round(c1.necessary_space),28,' '));
    end loop;

    -- CHECK the RATE OF CHAINED ROWS
       rate_chained(output => TRUE, threshold_ok=> null, threshold_ugly => null, p_status => chained_status );

      -- tables with degree>1
      for C1 in ( 
        SELECT TABLE_NAME, DEGREE, ROWNUM r
        FROM all_tables 
        WHERE trim(DEGREE) != '1'
        AND owner = schema_imx        
      )
      loop
        IF(c1.r=1)
        THEN 
          line;
          HEAD('Tables with degree != ''1''');
          linee;
          head(rpad('table name',30,' ')||' '||rpad('degree',13,' '));
          head(rpad('-',30,'-')||' '||rpad('-',10,'-'));          
        END IF;
        problem(rpad(c1.table_name,30,' ')||' '||rpad(c1.degree,13,' '));
      end loop;
      
      -- indexes with degree>1
      for C1 in ( 
        SELECT att.table_name, ai.INDEX_NAME, ai.DEGREE, ROWNUM r
        FROM all_INDEXES ai, all_tables att
        WHERE trim(ai.DEGREE) != '1'
        AND ai.owner = schema_imx
        AND att.owner = schema_imx
        and att.table_name=index_name
      )
      loop
        IF(c1.r=1)
        THEN 
          linee;
          HEAD('Indexes with degree != ''1''');
          linee;
          HEAD(rpad('table name',30,' ')||rpad('index name',30,' ')||rpad('degree',30,' '));
          HEAD(rpad('-',30,'-')||' '||rpad('-',30,'-')||' '||rpad('-',30,'-')||' ');
        END IF;
        problem(rpad(c1.table_name,30,' ')||' '||rpad(c1.index_name,30,' ')||' '||rpad(c1.degree,13,' '));
      end loop;
      
      -- tables which should not be in IMX schema - added by DI
      fr:=true;
      for C1 in (
        SELECT ROWNUM r, t.table_name 
          FROM all_tables t 
         WHERE t.owner = schema_imx
           AND t.table_name in ('EVENT_DATA','AUCTIONITEM','BID','CUSTOMER_DATA','DEMOKIT_DEMOS','DEMOKIT_DEMO_SCRIPTS','DESCRIPTION_DATA','DEST_IMG_DATA','EVT_DEST_PROFILE',
                                'EVT_INSTANCE','IMX_TRAD_RESKEYS','MESSAGE_DATA','ORD','RCL_CLASSIFICATIONS','RCL_COMPONENTS','RCL_COMPONENT_DEPENDANCIES',
                                'RCL_FRAGMENTS','RCL_INSTRUCTIONS','RCL_INSTRUCTIONS_TEXT','TRIP_DATA'))
      loop
       IF c1.r=1 and fr and showWarn
        THEN
          line;
          HEAD('Tables which should not exist in IMX schema');
          linee;
          HEAD(rpad('Table_name',30,' '));
          HEAD(rpad('-',30,'-'));
          fr:=false;
        END IF;
        warn(rpad(c1.table_name,30,' '));
      end loop;

      -- not indexed foreign keys
      -- to do report the list of tables as info
      for C1 in ( 
      SELECT ROWNUM r, table_name, constraint_name, cname1 ||
              nvl2(cname2, ',' || cname2, NULL) ||
              nvl2(cname3, ',' || cname3, NULL) ||
              nvl2(cname4, ',' || cname4, NULL) ||
              nvl2(cname5, ',' || cname5, NULL) ||
              nvl2(cname6, ',' || cname6, NULL) ||
              nvl2(cname7, ',' || cname7, NULL) ||
              nvl2(cname8, ',' || cname8, NULL) columnsl
        FROM (SELECT b.table_name, b.constraint_name, MAX(decode(position, 1, column_name, NULL)) cname1, 
        MAX(decode(position, 2, column_name, NULL)) cname2, MAX(decode(position, 3, column_name, NULL)) cname3, MAX(decode(position, 4, column_name, NULL)) cname4, MAX(decode(position, 5, 
        column_name, NULL)) cname5, MAX(decode(position, 6, column_name, NULL)) cname6, MAX(decode(position, 7, column_name, NULL)) cname7, 
        MAX(decode(position, 8, column_name, NULL)) cname8, COUNT(*) col_cnt
                 FROM (SELECT substr(table_name, 1, 30) table_name, substr(constraint_name, 1, 30) constraint_name, substr(column_name, 1, 30) column_name, position
                          FROM all_cons_columns WHERE owner = schema_imx) a, all_constraints b
                WHERE a.constraint_name = b.constraint_name
                  AND b.constraint_type = 'R'                  
                  AND b.owner = schema_imx
                  AND b.table_name not in ('EVENT_DATA','AUCTIONITEM','BID','CUSTOMER_DATA','DEMOKIT_DEMOS','DEMOKIT_DEMO_SCRIPTS','DESCRIPTION_DATA','DEST_IMG_DATA','EVT_DEST_PROFILE',
                                            'EVT_INSTANCE','IMX_TRAD_RESKEYS','MESSAGE_DATA','ORD','RCL_CLASSIFICATIONS','RCL_COMPONENTS','RCL_COMPONENT_DEPENDANCIES',
                                            'RCL_FRAGMENTS','RCL_INSTRUCTIONS','RCL_INSTRUCTIONS_TEXT','TBRC_COSTS_IN','TBRC_COSTS_LINES','TBRC_OBSERVATIONS','TBRC_PENALTIES',
                                            'TBRC_RECOVERIES_IN','TBRC_RECOVERIES_OUT','TRIP_DATA')
                GROUP BY b.table_name, b.constraint_name) cons
       WHERE col_cnt > ALL
       (SELECT COUNT(*)
                FROM all_ind_columns i
               WHERE i.table_name = cons.table_name
                 AND i.index_owner = schema_imx
                 AND i.column_name IN (cname1, cname2, cname3, cname4, cname5,
                      cname6, cname7, cname8)
                 AND i.column_position <= cons.col_cnt
               GROUP BY i.index_name)
       ORDER BY 1
      )
      loop
        IF(c1.r=1)
        THEN 
          HEAD('-');
          HEAD('Not indexed foreign keys');
          HEAD('-');
          HEAD(rpad('Table_name',30,' ')||' '||rpad('Constraint_name',30,' ')||' '||rpad('Columns',50,' '));
          HEAD(rpad('-',30,'-')||' '||rpad('-',30,'-')||' '||lpad('-',50,'-'));
        END IF;
        problem(rpad(c1.table_name,30,' ')||' '||rpad(c1.constraint_name,30,' ')||' '||rpad(c1.columnsl,50,' '));
      end loop;
    

    --TODO sqls without bind variables from msg_queue - problem
    --TODO sqls without bind variables info

    
    
    end;

    -- procedure instance_wait_class
    --
    procedure instance_wait_class
    is
    begin
    fr:=true;
    for C1 in (WITH HISTORY as (select  min(begin_time), max(end_TIME),  wait_class,
             ROUND((sum(DBTIME_IN_WAIT) / 100),2) SUM_VALUE,
                    ROUND((min(DBTIME_IN_WAIT) / 100),2) MIN_VALUE,
                     ROUND((avg(DBTIME_IN_WAIT) / 100),2) AVG_VALUE,
                     ROUND((max(DBTIME_IN_WAIT) / 100),2) MAX_VALUE
          from    V$WAITCLASSMETRIC_HISTORY, v$event_name where V$WAITCLASSMETRIC_HISTORY.WAIT_CLASS_ID = v$event_name.WAIT_CLASS_ID
          and DBTIME_IN_WAIT>0 group by      wait_class),
         LAST_MINUTE as (select  min(begin_time), max(end_TIME),  wait_class,
              ROUND((sum(DBTIME_IN_WAIT) / 100),2) LAST_MINUTE
          from    V$WAITCLASSMETRIC, v$event_name where V$WAITCLASSMETRIC.WAIT_CLASS_ID = v$event_name.WAIT_CLASS_ID
          and DBTIME_IN_WAIT>0 and   INTSIZE_CSEC between 5900 and 6100 group by      wait_class),
        LAST_15_MINUTES AS (select  min(begin_time), max(end_TIME),  wait_class,
              ROUND((sum(DBTIME_IN_WAIT) / 100),2) LAST_15_MINUTES
          from    V$WAITCLASSMETRIC_HISTORY, v$event_name where V$WAITCLASSMETRIC_HISTORY.WAIT_CLASS_ID = v$event_name.WAIT_CLASS_ID
          and DBTIME_IN_WAIT>0 and   INTSIZE_CSEC between 5900 and 6100
            and begin_time between sysdate-15/(24*60) and sysdate-14/(24*60) group by      wait_class),
        LAST_30_MINUTES AS (select  min(begin_time), max(end_TIME),  wait_class,
              ROUND((sum(DBTIME_IN_WAIT) / 100),2) LAST_30_MINUTES
          from    V$WAITCLASSMETRIC_HISTORY, v$event_name where V$WAITCLASSMETRIC_HISTORY.WAIT_CLASS_ID = v$event_name.WAIT_CLASS_ID
          and DBTIME_IN_WAIT>0 and   INTSIZE_CSEC between 5900 and 6100
            and begin_time between sysdate-30/(24*60) and sysdate-29/(24*60) group by      wait_class),
        LAST_45_MINUTES AS (select  min(begin_time), max(end_TIME),  wait_class,
              ROUND((sum(DBTIME_IN_WAIT) / 100),2) LAST_45_MINUTES
          from    V$WAITCLASSMETRIC_HISTORY, v$event_name where V$WAITCLASSMETRIC_HISTORY.WAIT_CLASS_ID = v$event_name.WAIT_CLASS_ID
          and DBTIME_IN_WAIT>0 and   INTSIZE_CSEC between 5900 and 6100
            and begin_time between sysdate-45/(24*60) and sysdate-44/(24*60) group by      wait_class)
      select c.wait_class wait_class,
      LAST_45_MINUTES,LAST_30_MINUTES,LAST_15_MINUTES, LAST_MINUTE, min_value,avg_value,max_value
      from HISTORY a , LAST_MINUTE b, LAST_45_MINUTES c, LAST_30_MINUTES d,LAST_15_MINUTES e
      where a.wait_class = b.wait_class
        and a.wait_class = c.wait_class
        and a.wait_class = d.wait_class
        and a.wait_class = e.wait_class
      order by 2)
    loop
      if fr and showWarn then
        HEAD('-');
        HEAD('Histrory of wait classes with Database time spent in the wait');
        HEAD('-');
        HEAD('Wait Class Name              '||' '||'45 min.'||' '||'30 min.'||' '||'15 min.'||' '||'Last min.'||' '||'Min val.'||' '||'Avg val.'||' '||'Max val.');
        HEAD('-----------------------------'||' '||'-------'||' '||'-------'||' '||'-------'||' '||'---------'||' '||'--------'||' '||'--------'||' '||'--------');
        fr:=false;
      end if;
      warn(rpad(c1.wait_class,30,' ')||' '||lpad(c1.LAST_45_MINUTES,7,' ')||' '
      ||lpad(c1.LAST_30_MINUTES,7,' ')||' '||lpad(c1.LAST_15_MINUTES,7,' ')
      ||' '||lpad(c1.LAST_MINUTE,9,' ')||' '||lpad(c1.min_value,8,' ')||' '||
      lpad(c1.avg_value,8,' ')||' '||lpad(c1.max_value,8,' '));
    null;
    end loop;
    HEAD('--');
    end;
    --
    -- PROCEDURE INSTANCE_METRICS
    --
    procedure instance_metrics(business varchar2, p_metric_name varchar2,output boolean DEFAULT TRUE,threshold_ok number, threshold_ugly number,  p_status OUT varchar2 )
    is
    snapshot_time varchar2(20);
    threshold_ok_buffer_cache number;
    threshold_ok_transaction number;
    threshold_ok_response_time number;
    threshold_ok_pga_cache number;
    threshold_ok_host_cpu number;
    threshold_ok_shared_pool number;
    --
    threshold_ugly_buffer_cache number;
    threshold_ugly_transaction number;
    threshold_ugly_response_time number;
    threshold_ugly_pga_cache number;
    threshold_ugly_host_cpu number;
    threshold_ugly_shared_pool number;
    avg_current_logon number;
    --
    begin
    --
    if p_metric_name='rate_chained'
    then
      -- sensor behavior
      --
      rate_chained(FALSE, threshold_ok,threshold_ugly,p_status );
    --
    elsif p_metric_name='Executions Per Sec'
    then
      -- backward compatibility
      p_status := 'OK';
    else
    --
    -- treshold definitions
    -- the thresholds can be set only when a specific metric is set
    -- Extraction of AVG current logons in the last 15 minutes
    --
    select  round(avg(value)) into avg_current_logon
      from    v$SYSMETRIC_HISTORY
      where   METRIC_NAME  = 'Current Logons Count'
        and   INTSIZE_CSEC between 5900 and 6100
        and begin_time between sysdate-15/(24*60) and sysdate;
    --
    if p_metric_name = '%' or ( p_metric_name != '%' and threshold_ok is null)  then
    --
    -- define default threshold_ok
    --
    threshold_ok_buffer_cache := 95;
    threshold_ok_transaction := ceil(4.1304*EXP(0.003*avg_current_logon))+4  ;
    if business='debt' then threshold_ok_response_time := 0.6; else threshold_ok_response_time := 0.6; end if;
    threshold_ok_pga_cache := 95;
    threshold_ok_host_cpu  := 75;
    threshold_ok_shared_pool := 8;
    --
    else
      case  p_metric_name
        when 'Buffer Cache Hit Ratio'   then threshold_ok_buffer_cache := threshold_ok;
        when 'PGA Cache Hit %'     then threshold_ok_pga_cache    := threshold_ok;
        when 'User Transaction Per Sec'  then threshold_ok_transaction   := threshold_ok;
        when 'Response Time Per Txn'   then threshold_ok_response_time:= threshold_ok;
        when 'Host CPU Utilization (%)' then threshold_ok_host_cpu     := threshold_ok;
        when 'Shared Pool Free %'   then threshold_ok_shared_pool  := threshold_ok;
      end case;
    end if;
    --
    -- define default threshold_ugly
    --
    if p_metric_name = '%' or ( p_metric_name != '%' and threshold_ugly is null)  then
    --
    threshold_ugly_buffer_cache := 80;
    threshold_ugly_transaction := threshold_ok_transaction*3 ;
    if business='debt' then threshold_ugly_response_time := 1.2; else threshold_ugly_response_time := 1.2; end if;
    threshold_ugly_pga_cache := 80;
    threshold_ugly_host_cpu := 85 ;
    threshold_ugly_shared_pool := 3;
    --
    else
      case  p_metric_name
        when 'Buffer Cache Hit Ratio'   then threshold_ugly_buffer_cache := threshold_ugly;
        when 'PGA Cache Hit %'     then threshold_ugly_pga_cache    := threshold_ugly;
        when 'User Transaction Per Sec'  then threshold_ugly_transaction  := threshold_ugly;
        when 'Response Time Per Txn'   then threshold_ugly_response_time:= threshold_ugly;
        when 'Host CPU Utilization (%)' then threshold_ugly_host_cpu     := threshold_ugly;
        when 'Shared Pool Free %'   then threshold_ugly_shared_pool  := threshold_ugly;
      end case;
    end if;
    --
    fr:=true;
    for C1 in (WITH HISTORY as (select  METRIC_NAME,
                  case  metric_name when 'Response Time Per Txn' then round(min(value)/100,2) else round(min(value)) end min_value,
            case  metric_name when 'Response Time Per Txn' then round(avg(value)/100,2) else round(avg(value)) end avg_value,
            case  metric_name when 'Response Time Per Txn' then round(max(value)/100,2) else round(max(value)) end max_value
      from    v$SYSMETRIC_HISTORY
      where   METRIC_NAME in ('Buffer Cache Hit Ratio',
                            'User Transaction Per Sec',
                            'Response Time Per Txn',
                            'PGA Cache Hit %','Host CPU Utilization (%)',
                            'Shared Pool Free %',
                            'Current Logons Count')
      group by      METRIC_NAME),
       LAST_MINUTE as (select METRIC_NAME,
                  case  metric_name when 'Response Time Per Txn' then round(value/100,2) else round(value) end LAST_MINUTE
      from    v$SYSMETRIC
      where   METRIC_NAME in ('Buffer Cache Hit Ratio',
                            'User Transaction Per Sec',
                            'Response Time Per Txn',
                            'PGA Cache Hit %','Host CPU Utilization (%)',
                            'Shared Pool Free %',
                            'Current Logons Count')
        and   INTSIZE_CSEC between 5900 and 6100),
      LAST_15_MINUTES AS (select METRIC_NAME,
                  case  metric_name when 'Response Time Per Txn' then round(value/100,2) else round(value) end LAST_15_MINUTES
      from    v$SYSMETRIC_HISTORY
      where   METRIC_NAME in ('Buffer Cache Hit Ratio',
                            'User Transaction Per Sec',
                            'Response Time Per Txn',
                            'PGA Cache Hit %','Host CPU Utilization (%)',
                            'Shared Pool Free %',
                            'Current Logons Count')
        and   INTSIZE_CSEC between 5900 and 6100
        and begin_time between sysdate-15/(24*60) and sysdate-14/(24*60)),
      LAST_30_MINUTES AS (select METRIC_NAME,
                  case  metric_name when 'Response Time Per Txn' then round(value/100,2) else round(value) end LAST_30_MINUTES
      from    v$SYSMETRIC_HISTORY
      where   METRIC_NAME in ('Buffer Cache Hit Ratio',
                            'User Transaction Per Sec',
                            'Response Time Per Txn',
                            'PGA Cache Hit %','Host CPU Utilization (%)',
                            'Shared Pool Free %',
                            'Current Logons Count')
        and   INTSIZE_CSEC between 5900 and 6100
        and begin_time between sysdate-30/(24*60) and sysdate-29/(24*60)),
      LAST_45_MINUTES AS (select METRIC_NAME,
                  case  metric_name when 'Response Time Per Txn' then round(value/100,2) else round(value) end LAST_45_MINUTES
      from    v$SYSMETRIC_HISTORY
      where   METRIC_NAME in ('Buffer Cache Hit Ratio',
                            'User Transaction Per Sec',
                            'Response Time Per Txn',
                            'PGA Cache Hit %','Host CPU Utilization (%)',
                            'Shared Pool Free %',
                            'Current Logons Count')
        and   INTSIZE_CSEC between 5900 and 6100
        and begin_time between sysdate-45/(24*60) and sysdate-44/(24*60)),
      SENSOR_LAST_15_MINUTES AS (select METRIC_NAME,
                  case  metric_name when 'Response Time Per Txn' then round(avg(value)/100,2)
                  when 'Current Logons Count' then  null
                  when 'User Transaction Per Sec' then ceil(4.1304*EXP(0.003*avg_current_logon))
                  else round(avg(value)) end SENSOR_LAST_15_MI
      from    v$SYSMETRIC_HISTORY
      where   METRIC_NAME in ('Buffer Cache Hit Ratio',
                            'User Transaction Per Sec',
                            'Response Time Per Txn',
                            'PGA Cache Hit %','Host CPU Utilization (%)',
                            'Shared Pool Free %',
                            'Current Logons Count')
        and   INTSIZE_CSEC between 5900 and 6100
        and begin_time between sysdate-15/(24*60) and sysdate
        group by metric_name)
      select sysdate now,  CASE a.METRIC_NAME WHEN 'Response Time Per Txn' then 'Response Time Per Txn (secs)' ELSE a.METRIC_NAME END METRIC_NAME,
      case    when a.metric_name = 'Buffer Cache Hit Ratio'  and SENSOR_LAST_15_MI > threshold_ok_buffer_cache  then 'OK'
        when a.metric_name = 'Buffer Cache Hit Ratio'  and SENSOR_LAST_15_MI between threshold_ugly_buffer_cache and  threshold_ok_buffer_cache  then 'ATTENTION'
             when a.metric_name = 'Buffer Cache Hit Ratio'  and SENSOR_LAST_15_MI  < threshold_ugly_buffer_cache then 'UGLY'
             --
             when a.metric_name = 'PGA Cache Hit %' and SENSOR_LAST_15_MI > threshold_ok_pga_cache then 'OK'
        when a.metric_name = 'PGA Cache Hit %' and SENSOR_LAST_15_MI between threshold_ugly_pga_cache and  threshold_ok_pga_cache then 'ATTENTION'
             when a.metric_name = 'PGA Cache Hit %' and SENSOR_LAST_15_MI < threshold_ugly_pga_cache  then 'UGLY'
             --
             when a.metric_name = 'Host CPU Utilization (%)' and SENSOR_LAST_15_MI < threshold_ok_host_cpu then 'OK'
             when a.metric_name = 'Host CPU Utilization (%)' and SENSOR_LAST_15_MI between threshold_ok_host_cpu and  threshold_ugly_host_cpu then 'ATTENTION'
             when a.metric_name = 'Host CPU Utilization (%)' and SENSOR_LAST_15_MI > threshold_ugly_host_cpu  then 'UGLY'
         --
         when a.metric_name = 'Shared Pool Free %' and SENSOR_LAST_15_MI > threshold_ok_shared_pool  then 'OK'
        when a.metric_name = 'Shared Pool Free %' and SENSOR_LAST_15_MI between threshold_ugly_shared_pool and  threshold_ok_shared_pool then 'ATTENTION'
             when a.metric_name = 'Shared Pool Free %' and SENSOR_LAST_15_MI < threshold_ugly_shared_pool then 'UGLY'
             --
         when a.metric_name = 'Response Time Per Txn' and SENSOR_LAST_15_MI < threshold_ok_response_time then 'OK'
         when a.metric_name = 'Response Time Per Txn' and SENSOR_LAST_15_MI between  threshold_ok_response_time and threshold_ugly_response_time  then 'ATTENTION'
         when a.metric_name = 'Response Time Per Txn' and SENSOR_LAST_15_MI > threshold_ugly_response_time  then 'UGLY'
        --
        when a.metric_name = 'User Transaction Per Sec' and SENSOR_LAST_15_MI <= threshold_ok_transaction then 'OK'
        when a.metric_name = 'User Transaction Per Sec' and SENSOR_LAST_15_MI between threshold_ok_transaction and threshold_ugly_transaction   then 'ATTENTION'
             when a.metric_name = 'User Transaction Per Sec' and SENSOR_LAST_15_MI > threshold_ugly_transaction then 'UGLY'
             --
             when a.metric_name = 'Current Logons Count' then 'N/A'
      end  STATUS,
      LAST_45_MINUTES ,
      LAST_30_MINUTES,
      LAST_15_MINUTES,
      LAST_MINUTE,
      min_value,
      avg_value,
      max_value,
      SENSOR_LAST_15_MI
      from HISTORY a , LAST_MINUTE b, LAST_45_MINUTES c, LAST_30_MINUTES d,LAST_15_MINUTES e , SENSOR_LAST_15_MINUTES f
      where a.metric_name = b.metric_name
        and a.metric_name = c.metric_name
        and a.metric_name = d.metric_name
        and a.metric_name = e.metric_name
        and a.metric_name = f.metric_name
         and lower(a.metric_name) like lower(p_metric_name)
      order by 2)
    loop
      if output = TRUE
      then
        if fr and showWarn then 
          select to_char(sysdate,'dd/mm/yyyy hh24:mi') into snapshot_time from dual;
          HEAD('-');
          HEAD('Timestamp of the snapshot : '||snapshot_time);
          HEAD('-');
          HEAD('Metric Name                  '||' '||'Status   '||' '||'45 min.'||' '||'30 min.'||' '||'15 min.'||' '||'Last min.'||' '||'Min val.'||' '||'Avg val.'||' '||'Max val.'||' '||'Sensor Value');
          HEAD('-----------------------------'||' '||'---------'||' '||'-------'||' '||'-------'||' '||'-------'||' '||'---------'||' '||'--------'||' '||'--------'||' '||'--------'||' '||'------------');
          fr:=false;
        end if;
        warn(rpad(c1.metric_name,29,' ')||' '||rpad(c1.status,9,' ')||' '||
        lpad(c1.LAST_45_MINUTES,7,' ')||' '||lpad(c1.LAST_30_MINUTES,7,' ')||' '||
        lpad(c1.LAST_15_MINUTES,7,' ')||' '||lpad(c1.LAST_MINUTE,9,' ')||' '||
        lpad(c1.min_value,8,' ')||' '||lpad(c1.avg_value,8,' ')||' '||
        lpad(c1.max_value,8,' ')||' '||lpad(c1.SENSOR_LAST_15_MI,12,' '));
      end if;
      p_status := C1.status;
    end loop;
    --
    fr:=false;
    for C1 in (WITH HISTORY as (select  min(begin_time), max(end_TIME), METRIC_NAME,
                  ROUND(min(VALUE)) MIN_VALUE,
                   ROUND(avg(VALUE)) AVG_VALUE,
                   ROUND(max(VALUE)) MAX_VALUE
      from    v$SYSMETRIC_HISTORY
      where   METRIC_NAME in (
                            'Logical Reads Per Sec',
                            'Physical Reads Per Sec')
      group by      METRIC_NAME),
       LAST_MINUTE as (select  min(begin_time), max(end_TIME), METRIC_NAME,
                  ROUND(sum(value)) LAST_MINUTE
      from    v$SYSMETRIC
      where   METRIC_NAME in (
                            'Logical Reads Per Sec',
                            'Physical Reads Per Sec')
        and   INTSIZE_CSEC between 5900 and 6100
        group by      METRIC_NAME),
      LAST_15_MINUTES AS (select  min(begin_time), max(end_TIME), METRIC_NAME,
                  ROUND(sum(value)) LAST_15_MINUTES
      from    v$SYSMETRIC_HISTORY
      where   METRIC_NAME in (
                            'Logical Reads Per Sec',
                            'Physical Reads Per Sec')
        and   INTSIZE_CSEC between 5900 and 6100
        and begin_time between sysdate-15/(24*60) and sysdate-14/(24*60)
        group by      METRIC_NAME),
      LAST_30_MINUTES AS (select  min(begin_time), max(end_TIME), METRIC_NAME,
                  ROUND(sum(value)) LAST_30_MINUTES
      from    v$SYSMETRIC_HISTORY
      where   METRIC_NAME in (
                            'Logical Reads Per Sec',
                            'Physical Reads Per Sec')
        and   INTSIZE_CSEC between 5900 and 6100
        and begin_time between sysdate-30/(24*60) and sysdate-29/(24*60)
        group by      METRIC_NAME),
      LAST_45_MINUTES AS (select  min(begin_time), max(end_TIME), METRIC_NAME,
                  ROUND(sum(value)) LAST_45_MINUTES
      from    v$SYSMETRIC_HISTORY
      where   METRIC_NAME in (
                            'Logical Reads Per Sec',
                            'Physical Reads Per Sec')
        and   INTSIZE_CSEC between 5900 and 6100
        and begin_time between sysdate-45/(24*60) and sysdate-44/(24*60)
        group by      METRIC_NAME)
      select sysdate now, c.metric_name, ' ' status,
      LAST_45_MINUTES,LAST_30_MINUTES,LAST_15_MINUTES, LAST_MINUTE, min_value,avg_value,max_value
      from HISTORY a , LAST_MINUTE b, LAST_45_MINUTES c, LAST_30_MINUTES d,LAST_15_MINUTES e
      where a.metric_name = b.metric_name
        and a.metric_name = c.metric_name
        and a.metric_name = d.metric_name
        and a.metric_name = e.metric_name
      order by 2)
    loop
      if output = TRUE
      then
        if fr and showWarn then HEAD('--'); fr:=false; end if;
        warn(rpad(c1.metric_name,30,' ')||' '||rpad(c1.status,9,' ')||' '||
        lpad(c1.LAST_45_MINUTES,7,' ')||' '||lpad(c1.LAST_30_MINUTES,7,' ')||' '||
        lpad(c1.LAST_15_MINUTES,7,' ')||' '||lpad(c1.LAST_MINUTE,9,' ')||' '||lpad(c1.min_value,8,' ')||' '||
        lpad(c1.avg_value,8,' ')||' '||lpad(c1.max_value,8,' '));
      end if;
    end loop;
    --
    end if ; -- chained_rows.
    end instance_metrics;
    --
    -- procedure instance_enabled_traces
    --
    PROCEDURE instance_enabled_traces  IS
    nEnableTrace  NUMBER;
    check_number  NUMBER;
    DYNAMIC_SQL   varchar2(1000);
    BEGIN
      SELECT count(*) INTO nEnableTrace FROM dba_enabled_traces;
      IF nEnableTrace > 0
        THEN    
          for C1 in ( SELECT trace_type, PRIMARY_ID service, QUALIFIER_ID1 as module, rownum r FROM dba_enabled_traces ) loop
           IF(c1.r=1) THEN 
              HEAD('');
              HEAD('Enabled module traces');
              HEAD('-');
              HEAD(rpad('Trace_type',30,' ')||' '||rpad('Service',30,' ')||' '||rpad('Module',50,' '));
              HEAD(rpad('-',30,'-')||' '||rpad('-',30,'-')||' '||lpad('-',50,'-'));
           END IF;
           problem(rpad(c1.trace_type,30,' ')||' '||rpad(c1.service,30,' ')||' '||rpad(c1.module,50,' '));
           end loop;
      ELSE IF showInfo THEN line; END IF;
              info('There is not enabled traces on the instance ==> OK ');
      END IF;
    
      --
      -- at this moment, to CODIX, we don't use outlines. 
      -- check if some preferences have been created
      --
      dynamic_sql := 'select count(*) from dba_outlines where owner = '''||schema_imx||'''';
      execute immediate dynamic_sql into check_number;
      --
      if check_number = 0
      then
        if showInfo then line; end if;
        info('Number of created outlines : ' || check_number||' ==> OK');
      else
        line; 
        problem('Number of created outlines : ' || check_number||' ==> Check these created outlines');
      end if;

      --
      -- at this moment, to CODIX, we don't use profiles. 
      -- check if some preferences have been created
      --
      dynamic_sql := 'select count(*) from DBA_SQL_PROFILES';
      execute immediate dynamic_sql into check_number;
      --
      if check_number = 0
      then
        if showInfo then line; end if;
        info('Number of created profiles : ' || check_number||' ==> OK');
      else
        line; 
        problem('Number of created profiles : ' || check_number||' ==> Check these created profiles');
      end if;

      --
      -- at this moment, to CODIX, we don't use plan baselines. 
      -- check if some preferences have been created
      --
      dynamic_sql := 'select count(*) from dba_sql_plan_baselines';
      execute immediate dynamic_sql into check_number;
      --
      if check_number = 0
      then
        if showInfo then line; end if;
        info('Number of created plan baselines : ' || check_number||' ==> OK');
      else
        line; 
        problem('Number of created plan baselines : ' || check_number||' ==> Check these created plan baselines');
      end if;

      --
      -- at this moment, to CODIX, we don't use sql patches. 
      -- check if some preferences have been created
      --
      dynamic_sql := 'select count(*) from DBA_SQL_PATCHES';
      execute immediate dynamic_sql into check_number;
      --
      if check_number = 0
      then
        if showInfo then line; end if;
        info('Number of created sql patches : ' || check_number||' ==> OK');
      else
        line; 
        problem('Number of created sql patches : ' || check_number||' ==> Check these created sql patches');
      end if;

    
    END instance_enabled_traces;
    
    --
    -- procedure imx sessions statistics
    --
    PROCEDURE imx_statistics
    IS
    nResponseTime NUMBER;
    nCountSessions NUMBER;
    BEGIN
      --
      -- When the ESTIMATE_PERCENT parameter is manually specified, the DBMS_STATS
      -- gathering procedures may automatically increase the sampling percentage if the
      -- specified percentage did not produce a large enough sample. This ensures the stability
      -- of the estimated values by reducing fluctuations.
      --
      -- for 10gr2 : the sample 30% must be the minimum size of sample and the maximum numver of objects must be gathered with this sample ( of course with production volumetry)
      -- for 11gR2 : in AUTO_SAMMPLING, with IMX volume, the sample size is in major part egual to 100%.
      --
      -- T_ENC ( agenda) is excluded because it is gathered to 100% by the program.
      --
      BEGIN
        --response time for imx module
        WITH T_S AS
        (
        SELECT COUNT(*) c_sessions, n.NAME, SUM(stat.VALUE) v
          FROM v$sesstat stat, v$statname n, v$session ses
         WHERE (ses.program LIKE 'frm%' OR ses.module LIKE 'iapx%')
           AND stat.sid = ses.sid
           AND stat.STATISTIC# = n.STATISTIC#
           AND n.NAME IN ('DB time', 'user commits', 'user rollbacks')
         GROUP BY n.NAME
        )
        SELECT dt.v / (case (uc.v + ur.v) when 0 then 1 else (uc.v + ur.v) end) / 100 sec, dt.c_sessions
          INTO nResponseTime, nCountSessions
          FROM t_s dt, t_s uc, t_s ur
         WHERE dt.NAME = 'DB time'
           AND uc.NAME = 'user commits'
           AND ur.NAME = 'user rollbacks';

--TODO cursor_sharing=EXACT
        IF nResponseTime>0.7 and showWarn THEN 
          HEAD('-');
          HEAD('Response time for imx sessions');
          HEAD('-');
          HEAD(rpad('Response_time',20)||' '||rpad('Sessions_count',20));
          HEAD(rpad('-',20,'-')||' '||rpad('-',20,'-'));
          warn(rpad(nResponseTime,20)||' '||rpad(nCountSessions,20));
        ELSE
          if showInfo then
            head('-');
            HEAD('Response time for imx sessions');
            head('-');
            head(rpad('Response_time',20)||' '||rpad('Sessions_count',20));
            head(rpad('-',20,'-')||' '||rpad('-',20,'-'));
          end if;
          info(rpad(nResponseTime,20)||' '||rpad(nCountSessions,20));
        END IF;
      EXCEPTION WHEN no_data_found THEN
        info('No iMX forms sessions logged currently');
      END;
    END imx_statistics;
    --
    -- procedure instance_session
    --
    procedure instance_session
    is
    begin
    --
    -- longest SQL
    --
    fr:=true;
    for C1 in (select s.serial# serial , s.sid sid , to_char(start_time,'dd/mm/yyyy HH24:MI:SS') Debut,
    (to_number(to_char(sysdate,'SSSSS'))-to_number(to_char(start_time,'SSSSS')))
    +86399*(to_number(to_char(sysdate,'j'))-to_number(to_char(start_time,'j'))) temps,
    to_number(to_char(sysdate,'j'))-to_number(to_char(start_time,'j')) Jours,
    substr(S.program,1,30)  prog ,S.process process
    from v$session_longops L, v$session S
    where L.sid=S.sid    
    AND L.serial#=S.serial#
    AND L.SOFAR < L.TOTALWORK    
    and S.program not like 'oracle%'
    order by 4 desc)
    loop
      if fr=true and showWarn then
        head('--');
        head('Sessions with longops operations:');
        head('--');
        head('Serial'||' '||'Sid '||' '||'Start Time         '||' '||'Temps (s)'||' '||'Jours'||' '||'Program                       '||' '||'Process');
        head('------'||' '||'----'||' '||'-------------------'||' '||'---------'||' '||'-----'||' '||'------------------------------'||' '||'-------');
        fr:=false;
      end if;
      warn(rpad(c1.serial,6,' ')||' '||rpad(c1.sid,4,' ')||' '||rpad(c1.debut,19,' ')||' '||rpad(c1.temps,9,' ')||' '||rpad(c1.jours,5,' ')||' '||rpad(c1.prog,30,' ')||' '||rpad(c1.process,7,' '));
    end loop;    
    
    -- 
    -- AD Clock session must be one
    --

    FOR C1 IN (    
      select inst_id, count(*) c
        from gv$session s
       where s.sql_id = 'dn08pgc4bkf71' 
       group by inst_id
      having count(*)>1
       order by inst_id
    )
    LOOP
      IF(C1.inst_id=1)
      THEN
        HEAD('--');
        HEAD('Check why there are more than one AD clock sessions on the following instances:');
        HEAD('--');
        HEAD(rpad('INST_ID',30)||' '||rpad('COUNT',30,' ') );
        HEAD(rpad('-',30,'-')||' '||rpad('-',30,'-') );
      END IF;
      problem(rpad(C1.inst_id,30,' ') ||' '|| rpad(C1.c,30,' '));   
    END LOOP;
    
    
    fr:=true;
    for C1 in (sELECT s.sid sid , s.serial# serial , p.spid as spid,s.username username, substr(s.module,1,30) module, st.value/100 temps
    FROM v$sesstat st, v$statname sn, v$session s, v$process p
    WHERE sn.name = 'CPU used by this session' -- CPU
    AND st.statistic# = sn.statistic#
    AND st.sid = s.sid
    AND s.paddr = p.addr
    AND s.last_call_et < 1800 -- active within last 1/2 hour
    --AND s.logon_time > (SYSDATE - 240/1440) -- sessions logged on within 4 hours
    and rownum < 6
    ORDER BY st.value desc)
    loop
      if fr=true and showInfo then
        head('--');
        head('Sessions with highest CPU consumption');
        head('--');
        head('Serial'||' '||'Sid '||' '||'OS PID '||' '||'Username '||' '||'Program                       '||' '||'Temps (s)');
        head('------'||' '||'----'||' '||'-------'||' '||'---------'||' '||'------------------------------'||' '||'---------');
        fr:=false;
      end if;
      info(rpad(c1.serial,6,' ')||' '||rpad(c1.sid,4,' ')||' '||rpad(c1.spid,7,' ')||' '||rpad(c1.username,10,' ')||' '||rpad(c1.module,30,' ')||' '||rpad(c1.temps,9,' '));
    end loop;

    fr:=true;
    for C1 in (sELECT s.sid sid , s.serial# serial , p.spid as spid,s.username username, substr(s.module,1,30) module, 10*se.time_waited temps
    FROM v$session_event se, v$session s, v$process p
    WHERE lower(se.event) like 'buffer busy waits'
    AND s.last_call_et < 1800 -- active within last 1/2 hour
    --AND s.logon_time > (SYSDATE - 240/1440) -- sessions logged on within 4 hours
    AND se.sid = s.sid
    AND s.paddr = p.addr
    and se.time_waited > 0
    and rownum < 6
    ORDER BY se.time_waited desc)
    loop
      if fr=true and showInfo then
        head('--');
        head('with the highest time for the wait "buffer busy waits"');
        head('--');
        head('Serial'||' '||'Sid '||' '||'OS PID '||' '||'Username '||' '||'Program                       '||' '||'Temps (ms)');
        head('------'||' '||'----'||' '||'-------'||' '||'---------'||' '||'------------------------------'||' '||'----------');
        fr:=false;
      end if;
      info(rpad(c1.serial,6,' ')||' '||rpad(c1.sid,4,' ')||' '||rpad(c1.spid,7,' ')||' '||rpad(c1.username,10,' ')||' '||rpad(c1.module,30,' ')||' '||rpad(c1.temps,10,' '));
    end loop;
    end;

    --
    -- PROCEDURE INSTANCE_SGA
    --
    procedure instance_sga(business varchar2)
    is
    snapshot_time varchar2(20);
    sga number;
    pga number;
    size_db number;
    BEGIN 
      if major_release<>'10' then
        execute immediate 'select current_size/1024/1024 sga from v$memory_dynamic_components where component=''SGA Target''' 
          into sga;
      end if;

      if sga<1 or sga is null then
        select sum(value)/1024/1024 into sga from v$sga;
      end if;  
      select value/1024/1024 into pga from v$pgastat where name='aggregate PGA target parameter';
--      select sum(bytes)/1024/1024 into size_db from v$datafile where status='ONLINE';
      SELECT (SUM(df.total_space)-SUM(fs.free_space))/1024/1024 used_space
        into size_db 
        FROM (SELECT tablespace_name, SUM(bytes) TOTAL_SPACE, ROUND(SUM(bytes) /
                             1048576) TOTAL_SPACE_MB
                 FROM dba_data_files
--                  AND owner = schema_imx
                GROUP BY tablespace_name) df, (SELECT tablespace_name, SUM(bytes) FREE_SPACE, ROUND(SUM(bytes) /
                             1048576) FREE_SPACE_MB
                 FROM dba_free_space
--                  AND owner = schema_imx
                GROUP BY tablespace_name) fs
       WHERE df.tablespace_name = fs.tablespace_name(+)
       ORDER BY fs.tablespace_name;

      if business = 'debt'
      then
        if round((sga+pga)/size_db*100,2) >=2.5
        then
          if showInfo then
            head('-');
            head('Ratio of the SGA+PGA compared to the size of the database');
            head('-');
          end if;
          info('Size of SGA : '||sga||' Mb       Size of PGA : '||pga||' Mb       Size of DB : '||size_db||' Mb     Ratio (SGA+PGA)/DB : '||round((sga+pga)/size_db*100,2)||'%');
          info(' ==> OK');
        elsif round((sga+pga)/size_db*100,2) <2.5
        then
          if showWarn then
            HEAD('-');
            HEAD('Ratio of the SGA+PGA compared to the size of the database');
            HEAD('-');
          end if;
          WARN('Size of SGA : '||sga||' Mb       Size of PGA : '||pga||' Mb       Size of DB : '||size_db||' Mb     Ratio (SGA+PGA)/DB : '||round((sga+pga)/size_db*100,2)||'%');
          WARN(' ==> Too low');
        end if;
      else
        if round((sga+pga)/size_db*100,2) >=10
        THEN
          if showInfo then
            head('-');
            head('Ratio of the SGA+PGA compared to the size of the database');
            head('-');
            info('Size of SGA : '||sga||' Mb       Size of PGA : '||pga||' Mb       Size of DB : '||size_db||' Mb     Ratio (SGA+PGA)/DB : '||round((sga+pga)/size_db*100,2)||'%');
            info(' ==> OK');
          end if;
        elsif round((sga+pga)/size_db*100,2) < 10
        then
          if showWarn then
          HEAD('-');
          HEAD('Ratio of the SGA+PGA compared to the size of the database');
          HEAD('-');
          WARN('Size of SGA : '||sga||' Mb       Size of PGA : '||pga||' Mb       Size of DB : '||size_db||' Mb     Ratio (SGA+PGA)/DB : '||round((sga+pga)/size_db*100,2)||'%');
          WARN(' ==> Too low');
          end if;
        end if;
      end if;

    end;
    --
    -- procedure instance_parameter
    --
    PROCEDURE instance_parameter IS
      vClCode   VARCHAR2(20);
    BEGIN 
      /* If memory_targget or sga_target is set to a value larger than 0, 
         then AMM/ASMM is enabled, which might cause oracle error 04031 or shared pool contentions.
         The parameters optimizer_adaptive_features, optimizer_adaptive_plans or optimizer_adaptive_statistics should be switched off on system level.
         It causes increased parse times, mainly because of sql directives usage. */
      IF to_number(major_release) >= 12 THEN
        fr := true;
        for c in ( select p.name, 
                          p.value
                     from v$parameter p
                    where p.name in ( 'memory_target',
                                      'sga_target',
                                      'optimizer_adaptive_features',
                                      'optimizer_adaptive_plans',
                                      'optimizer_adaptive_statistics' )
                      and case when p.name in ('memory_target','sga_target')
                               then to_number(p.value)
                               when p.name = 'optimizer_adaptive_features'
                                and upper(p.value) <> 'FALSE'
                               then 1
                               when p.name = 'optimizer_adaptive_statistics' 
                                and upper(p.value) <> 'FALSE'
                               then 1
                               when p.name = 'optimizer_adaptive_plans' 
                                and upper(p.value) <> 'FALSE'
                               then 1
                               else 0
                           end > 0 )
        loop
          if fr then
            HEAD('-');
            HEAD('Problematic parameters in Oracle 12+');
            HEAD('-');
            HEAD('Name                                    '||' '||'Value                                   ');
            HEAD('----------------------------------------'||' '||'----------------------------------------');
            fr := false;
          end if;
          problem(rpad(c.name,40,' ')||' '||rpad(c.value,40,' ')); 
        end loop;
      END IF;     
     
      /* Setting _optimizer_unnest_scalar_sq to false is a workaround for Oracle Bugs 17633803 and 20927642. */
      -- Setting _use_single_log_writer to true is a workaround for problem with LGW described in Oracle Doc ID 2174075.1
      -- Setting _fix_control to 17376322:OFF is a workaround for problem in ORCALE 12.1 described in Oracle DocID 1951689.1
      -- Setting _fix_control to 19509982:OFF is a workaround for problem in ORCALE 12.1 described in Oracle Bug 19509982 - Di-
      --   sable raising of ORA-1792 by default (Doc ID 19509982.8). The patch conflicts with Because it conflicts with 
      --   PSU 12.1.0.2.170117. Info received from Ivan Sapundjiev       
      Select getdcli INTO vClCode FROM g_etude;
      -- list of non default init parameters. The parameters '%dest%' and 'control_files' are discarded.
      --
     
      IF output_level > 1 THEN
      -- Only for 12.2 we will use column DEFAULT_VALUE
        fr := true;
        FOR C1 IN ( SELECT ROWNUM r, 
                           COUNT(pb) over() pb_count, 
                           subq.*
                      FROM ( SELECT p.*,/*NAME, VALUE,*/
                                    CASE WHEN name = 'optimizer_index_cost_adj' 
                                          AND VALUE <> 1 
                                         THEN CASE WHEN VALUE = 100 
                                                    AND vClCode = 'C208' 
                                                   THEN 2 
                                                   ELSE 1 
                                               END
                                         WHEN name = 'cursor_sharing' 
                                          AND VALUE <> 'EXACT' 
                                         THEN 1
                                         WHEN name IN ('_optimizer_unnest_scalar_sq', '_use_single_log_writer', '_fix_control')
                                         THEN CASE WHEN name = '_fix_control' 
                                                    AND VALUE = '17376322:OFF' 
                                                    AND detailed_release = '12.1' 
                                                   THEN 2
                                                   WHEN name = '_fix_control' 
                                                    AND VALUE = '19509982:OFF' 
                                                    AND detailed_release = '12.1' 
                                                   THEN NULL
                                                   WHEN name = '_fix_control' 
                                                    AND VALUE = '19509982:OFF' 
                                                    AND detailed_release = '12.2'
                                                   THEN 2 
                                                   WHEN name = '_fix_control' 
                                                    AND VALUE = '27466597:1' 
                                                    AND detailed_release like '18%'
                                                   THEN 2 -- In relation with COFAWEB-2330
                                                   WHEN name = '_fix_control' 
                                                    AND VALUE IN ('20107874:off','20107874:OFF') 
                                                    AND detailed_release like '19%'
                                                   THEN NULL -- PT-20
                                                   WHEN name = '_use_single_log_writer' 
                                                    AND detailed_release like '19%'
                                                   THEN 2 -- PT-20
                                                   WHEN detailed_release = '12.1' 
                                                    AND name != '_fix_control' 
                                                   THEN 2 
                                                   ELSE 1 
                                               END  
                                         ELSE NULL
                                     END pb
                     FROM v$parameter p
                    WHERE (     name NOT LIKE '%dest' 
                            AND name != 'control_files' 
                            AND isdefault = 'FALSE' )
                       OR ( name = 'optimizer_index_cost_adj' )
                       OR ( name = 'cursor_sharing' )
                    ORDER BY pb, 
                             name ) subq )
        LOOP
          -- Defailt_value column exists from 12.1.0.2, but is not always OK in that version.
          $IF NOT DBMS_DB_VERSION.VER_LE_11_2 $THEN
          IF substr(C1.value,1,60) <> substr(C1.default_value,1,60) THEN
          $END
            IF c1.pb is not null THEN
              IF c1.pb = 1
                THEN IF fr then
                       HEAD('-');
                       HEAD('List of non default init parameters. The parameters ''cursor_sharing'', ''optimizer_index_cost_adj'',''_optimizer_unnest_scalar_sq'', ''_use_single_log_writer'', ''_fix_control'' are only involved in the list');
                       HEAD('-');
                       HEAD('Name                                    '||' '||'Value                                   ');
                       HEAD('----------------------------------------'||' '||'----------------------------------------');
                       fr:=false;
                     END IF;
                     problem(rpad(C1.name,40,' ')||' '||rpad(C1.value,40,' '));
                ELSE IF fr and showWarn then
                        HEAD('-');
                        HEAD('List of non default init parameters. The parameters ''cursor_sharing'', ''optimizer_index_cost_adj'',''_optimizer_unnest_scalar_sq'', ''_use_single_log_writer'', ''_fix_control'' are only involved in the list');
                        HEAD('-');
                        HEAD('Name                                    '||' '||'Value                                   ');
                        HEAD('----------------------------------------'||' '||'----------------------------------------');
                        fr:=false;
                     END IF;
                     warn(rpad(C1.name,40,' ')||' '||rpad(C1.value,40,' '));
              END IF;
            ELSE IF fr and showInfo then
                   HEAD('-');
                   HEAD('List of non default init parameters. The parameters ''cursor_sharing'', ''optimizer_index_cost_adj'',''_optimizer_unnest_scalar_sq'', ''_use_single_log_writer'', ''_fix_control'' are only involved in the list');
                   HEAD('-');
                   HEAD('Name                                    '||' '||'Value                                   ');
                   HEAD('----------------------------------------'||' '||'----------------------------------------');
                   fr:=false;
                 END IF;
                 info(rpad(C1.name,40,' ')||' '||rpad(C1.value,40,' '));
            END IF;
          $IF NOT DBMS_DB_VERSION.VER_LE_11_2 $THEN
          END IF;
          $END
        END LOOP;
      END IF;
    END instance_parameter;
    --
    -- long SQL procedure
    --
    procedure sql_statements
    is
    begin
    --
    -- Segments with a rate of disks I/O >= 60% compared to all disks I/O.
    --
    fr:=true;
    for C1 in (select object_name, object_type , io_phy_by_seg, io_phy_all_seg, trunc(io_phy_by_seg/io_phy_all_seg*100) rate
    from
      (
        SELECT object_name, object_type, SUM(VALUE) over(PARTITION BY object_name) io_phy_by_seg, SUM(VALUE) over() io_phy_all_seg
          FROM v$segstat, all_objects
         WHERE object_id = dataobj#
           AND STATISTIC_NAME = 'physical reads'
           AND owner = schema_imx
      )
      where io_phy_by_seg/io_phy_all_seg >= 0.6 order by 4 desc)
    loop
      if fr and showWarn then
        head('--');
        head('Segment with a rate of disk I/O >= 60% compared to all disk I/O' );
        head('--');
        head('Segment Name        '||' '||'Segment Type'||' '||'Disk I/O  '||' '||'Total Global disk I/O  '||' '||'Rate');
        head('--------------------'||' '||'------------'||' '||'----------'||' '||'-----------------------'||' '||'----');
        fr:=false;
      end if;
      warn(rpad(c1.object_name,20,' ')||' '||rpad(c1.object_type,12,' ')||' '||rpad(c1.io_phy_by_seg,10,' ')||' '||rpad(c1.io_phy_all_seg,23,' ')||' '||rpad(c1.rate,5,' '));
    end loop;
    --
    -- Segments with a rate of logical I/O >= 60% compared to all logical I/O.
    --
    fr:=true;
    for C1 in (select object_name, object_type , io_log_by_seg, io_log_all_seg, trunc(io_log_by_seg/io_log_all_seg*100) rate
    from
      (
        select object_name, object_type, sum(VALUE)   over (partition by object_name)  io_log_by_seg, sum(VALUE) over() io_log_all_seg from v$segstat
        , all_objects where object_id=dataobj# and STATISTIC_NAME='logical reads' AND owner = schema_imx
      )
      where io_log_by_seg/io_log_all_seg >= 0.6 order by 4 desc)
    loop
      if fr and showWarn then
        head('--');
        head('Segment with a rate of logical I/O >= 60% compared to all logical I/O' );
        head('--');
        head('Segment Name        '||' '||'Segment Type'||' '||'Logical I/O  '||' '||'Total Global Logical I/O  '||' '||'Rate');
        head('--------------------'||' '||'------------'||' '||'-------------'||' '||'--------------------------'||' '||'----');
        fr:=false;
      end if;
      warn(rpad(c1.object_name,20,' ')||' '||rpad(c1.object_type,12,' ')||' '||rpad(c1.io_log_by_seg,13,' ')||' '||rpad(c1.io_log_all_seg,26,' ')||' '||rpad(c1.rate,5,' '));
    end loop;
    --
    -- SQL_ID with a rate of executions >= 60% compared to all executions.
    --
    fr:=true;
    for C1 in (select sql_id,exec_by_sql,all_exec , trunc(exec_by_sql/all_exec*100) rate from
    (select distinct sql_id, sum(executions) over (partition by sql_id) exec_by_sql, sum(executions)  over() all_exec from v$sql)
    where exec_by_sql/all_exec >= 0.6 order by 4 desc)
    loop
      if fr and showWarn then
        head('--');
        head('SQL_ID with a rate of executions >= 60% compared to all executions' );
        head('--');
        head('SQL_ID       '||' '||'Executions'||' '||'Total Global Executions'||' '||'Rate');
        head('-------------'||' '||'----------'||' '||'-----------------------'||' '||'----');
        fr:=false;
      end if;
      warn(rpad(c1.sql_id,13,' ')||' '||rpad(c1.exec_by_sql,10,' ')||' '||rpad(c1.all_exec,23,' ')||' '||rpad(c1.rate,5,' '));
    end loop;
    --
    -- SQL_ID with a rate of gets I/O >= 60% compared to all gets I/O.
    --
    fr:=true;
    for C1 in (select sql_id,gets_by_sql,all_gets , trunc(gets_by_sql/all_gets*100) rate from
    (select distinct sql_id, sum(buffer_gets) over (partition by sql_id) gets_by_sql, sum(buffer_gets)  over() all_gets from v$sql)
    where gets_by_sql/all_gets >= 0.6 order by 4 desc)
    loop
      if fr and showWarn then
        head('--');
        head('SQL_ID with a rate of gets I/O >= 60% compared to all gets I/O ' );
        head('--');
        head('SQL_ID       '||' '||'Gets I/O  '||' '||'Total Global Gets  I/O '||' '||'Rate');
        head('-------------'||' '||'----------'||' '||'-----------------------'||' '||'----');
        fr:=false;
      end if;
      warn(rpad(c1.sql_id,13,' ')||' '||rpad(c1.gets_by_sql,10,' ')||' '||rpad(c1.all_gets,23,' ')||' '||rpad(c1.rate,5,' '));
    end loop;
    --
    -- SQL_ID with a rate of disks I/O >= 60% compared to all disks I/O.
    --
    fr:=true;
    for C1 in (select sql_id,disks_by_sql,all_disks , trunc(disks_by_sql/all_disks*100) rate from
    (select distinct sql_id, sum(disk_reads) over (partition by sql_id) disks_by_sql, sum(disk_reads)  over() all_disks from v$sql)
    where disks_by_sql/all_disks >= 0.6 order by 4 desc)
    loop
      if fr and showWarn then
        head('--');
        head('SQL_ID with a rate of disk I/O >= 60% compared to all disk I/O' );
        head('--');
        head('SQL_ID       '||' '||'Disk I/O  '||' '||'Total Global disk I/O  '||' '||'Rate');
        head('-------------'||' '||'----------'||' '||'-----------------------'||' '||'----');
        fr:=false;
      end if;
      warn(rpad(c1.sql_id,13,' ')||' '||rpad(c1.disks_by_sql,10,' ')||' '||rpad(c1.all_disks,23,' ')||' '||rpad(c1.rate,5,' '));
    end loop;
    --
    -- SQL_ID performing a FULL SCAN TABLE on segments > 10000 blocks
    --
    fr:=true;
    for C1 in (
      SELECT COUNT(sql_id) nber, object_name, blocks
        FROM v$sql_plan, dba_segments
       WHERE options = 'FULL'
         AND segment_name = object_name
         AND blocks > 5000
         AND owner = schema_imx
       GROUP BY object_name, object_type, blocks
    )
    loop
      if fr and showWarn then
        head('--');
        head('SQL_ID performing a FULL SCAN TABLE on segments > 10000 blocks' );
        head('--');
        head('Number of FST'||' '||'Object Name            '||' '||'Oracle Blocks'||' '||'SQL_ID       '||' '||rpad('Module',20,' '));
        head('-------------'||' '||'-----------------------'||' '||'-------------'||' '||'-------------'||' '||rpad('-',20,'-'));
        fr:=false;
      end if;

      warn(rpad(c1.nber,13,' ')||' '||rpad(c1.object_name,23,' ')||' '||rpad(c1.blocks,13,' '));
      --
      for C2 in ( 
        SELECT DISTINCT sp.sql_id, sa.module
          FROM v$sql_plan sp, v$sqlarea sa
         WHERE sp.object_owner = schema_imx
           AND sp.object_name = c1.object_name
           AND sp.options = 'FULL'
           AND sp.sql_id=sa.sql_id
           AND sa.BUFFER_GETS/greatest(sa.executions,1)>5000      
      )
      loop
        warn(rpad('-',13,' ')||' '||rpad('-',23,' ')||' '||rpad('-',13,' ')||' '||rpad(c2.sql_id,13,' ')||' '||rpad(c2.module,20,' '));
        --problem('-'||lpad(c2.sql_id,64,' '));
      end loop;
    end loop;
    end;
    -- RATE_CHAINED
    --
    procedure rate_chained(output boolean DEFAULT TRUE,threshold_ok number, threshold_ugly number,  p_status OUT varchar2 ) is
    fetch_continued_rows    number;
    fetch_rowid             number;
    rate                    number;
    threshold_default_ok    number;
    threshold_default_ugly  number;
    db_startup_date         DATE;
    BEGIN
    if threshold_ok is null then threshold_default_ok := 5; else threshold_default_ok := threshold_ok; end if;
    if threshold_ugly is null  then threshold_default_ugly := 15; else threshold_default_ugly := threshold_ugly; end if;
    SELECT value into fetch_continued_rows   FROM v$sysstat  WHERE name = 'table fetch continued row';
    SELECT value into fetch_rowid   FROM v$sysstat  WHERE name = 'table fetch by rowid';
    SELECT startup_time INTO db_startup_date FROM v$instance;
    rate := round(100*fetch_continued_rows/fetch_rowid);
    
    if rate <= threshold_default_ok
      then p_status := 'OK';
    elsif rate >= threshold_default_ugly
      then p_status := 'UGLY';
    else
      p_status := 'ATTENTION';
    end if;
    
    if output = TRUE
    then
      IF rate < threshold_default_ok then
        if showInfo then
          HEAD('-');
          HEAD('RATE OF CHAINED/MIGRATED ROWS SINCE THE STRATUP OF THE DATABASE at '||to_char(db_startup_date, 'yyyy-mm-dd hh24:mi:ss'));
          HEAD('-');
        end if;
        info(' The rate is = '||rate||' %');
        if showinfo then
          HEAD(' --- rate = (fetch_continued_rows = '||fetch_continued_rows||' / fetch_rowid= '||fetch_rowid||')');
          HEAD('if this rate is superior to 5%, then start to analyze the tables G_PIECE, G_INDIVIDU and G_DOSSIER');
        end if;       
       else
        HEAD('-');
        HEAD('RATE OF CHAINED/MIGRATED ROWS SINCE THE STRATUP OF THE DATABASE at '||to_char(db_startup_date, 'yyyy-mm-dd hh24:mi:ss'));
        HEAD('-');
        problem(' The rate is = '||rate||' %');
        HEAD(' --- rate = (fetch_continued_rows = '||fetch_continued_rows||' / fetch_rowid= '||fetch_rowid||')');
        HEAD('if this rate is superior to 5%, then start to analyze the tables G_PIECE, G_INDIVIDU and G_DOSSIER');
      end if;
    end if;

    END;

    -- MAIN PROCEDURE
    --
    procedure main(v_business varchar2,steps number DEFAULT 0, wait boolean DEFAULT FALSE, poutput_level IN NUMBER DEFAULT 10)
    is
    status varchar2(10);
    BEGIN
    dbms_output.enable(NULL);    
    output_level:=poutput_level;
    HEAD('################################################################################');
    HEAD(' System check report : DB Performance Tuning; '||vScriptVersion);
    HEAD('################################################################################');
    HEAD(' ');
    check_oracle_release;
    detect_imx_schema;
    --
    if steps = 0 or steps=2
    then
    HEAD(' ');
    HEAD('################################################################################');
    HEAD(' TOP-DOWN METHOD : LAYER 2 : INSTANCE REVIEW');
    HEAD('################################################################################');
    HEAD(' ');
    instance_sga (v_business);
    instance_parameter;
    instance_enabled_traces;
    --
    -- parameters ;
    -- v_business = debt or factoring
    -- metric_name = 'Buffer Cache Hit Ratio' or 'Executions Per Sec' or 'Response Time Per Txn (secs)' or 'PGA Cache Hit %' or 'Host CPU Utilization (%)' or 'Shared Pool Free %'
    -- output = FALSE or TRUE ==> active or desactive the output of DBMS_OUTPUT PCK. Useful only for SENSOR
    -- status = status OK , ATTENTION or UGLY returned by this procedure.
    --
    instance_metrics(business => v_business,p_metric_name => '%',output => TRUE,p_status => status);
    if wait = TRUE
    then
      instance_wait_class;
    end if;
    imx_statistics;
    end if;
    --
    if steps = 0 or steps=3
    then
    HEAD(' ');
    HEAD('################################################################################');
    HEAD(' TOP-DOWN METHOD : LAYER 3 : TUNE INSTANCE');
    HEAD('################################################################################');
    HEAD(' ');
    check_oracle_statistics;
    instance_session;
    end if;
    --
    if steps = 0 or steps=4
      then
      HEAD(' ');
      HEAD('################################################################################');
      HEAD(' TOP-DOWN METHOD : LAYER 4 : TUNE OBJECTS');
      HEAD('################################################################################');
      HEAD(' ');
      check_objects;
    end if;

    --
    if steps = 0 or steps=5
    then
      HEAD(' ');
      HEAD('################################################################################');
      HEAD(' TOP-DOWN METHOD : LAYER 5 : TUNE SQL');
      HEAD('################################################################################');
      HEAD(' ');
      sql_statements;
    end if;
    HEAD(' ');
    HEAD('================== The report generated at '||to_char(SYSDATE,'yyyy-mm-dd hh24:mi:ss')||' =================');
    HEAD(' ');
    end;
--
  function getActivite return varchar2 is
  res varchar2(30);
  begin
    begin
      select activite 
        into res 
       from g_etude;    
    exception when ETableNotExist 
      then problem('G_ETUDE NOT EXIST');  
      res:='FACTORING';
    end;
    --change in the way it is used in the script:
    if res='FACTORING'
    then
      res:='factoring';
    else
      res:='debt';
    end if;      
    return res;
  end getActivite;
--  
BEGIN
  mark_problems:=nvl('&mark_problems',1);  
  --
  vcActivite:=getActivite;
  MAIN(vcActivite,0, FALSE,nvl('&log_level', 10));  
  EXECUTE IMMEDIATE 'ALTER SESSION SET CURRENT_SCHEMA='||:bv_schema_name_begin;
end;
/
SET serverout OFF;

-- $Date: 2021/11/24 07:54:09 $
-- $Revision: 1.50 $
