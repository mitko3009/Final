/*
**********************************************************************
**
**   File: sql_undef.sql                                                         
**   $Date: 2014/04/24 06:17:16 $                                                                     
**   $Revision: 1.2 $                                                                 
**   Description: Undefine sql_id defined previously via "@@".
**
**********************************************************************
*/

undef sql_id
undef begin_snap
undef end_snap
undef days_back