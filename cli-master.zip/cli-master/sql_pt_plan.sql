/*
**********************************************************************
**
**   File: sql_pt_plan.sql                                                         
**   $Date: 2016/02/11 09:30:10 $                                                                     
**   $Revision: 1.3 $                                                                 
**   Description: Display the execution plan for a particular SQL stored by iPT. The code is copy pasted from $H/perf/cli/pt_report.sql
**
**********************************************************************
*/
SET serverout ON;

DECLARE
	vPlanLastTime       DATE;
  
	PROCEDURE proc_print_plan (pSqlId           VARCHAR2,
	                           pPlanHashValue   NUMBER,
	                           pPlanDate        DATE
	                           ) IS
	  CURSOR c_xplan IS
	  SELECT *
	    FROM table(dbms_xplan.display('pt_sql_plan',
	                                  NULL,
	                                  'TYPICAL',
	                                  'sql_id='''||pSqlId||''' and plan_hash_value='||pPlanHashValue
	                                               ||' and sample_time=to_date('''||to_char(pPlanDate,'yyyy-mm-dd hh24:mi:ss')||''',''yyyy-mm-dd hh24:mi:ss'')'
	                                  )
	              )
	   WHERE PLAN_TABLE_OUTPUT NOT LIKE '%''PT_SQL_PLAN''%is old version%';
	  BEGIN
	    FOR curr_plan IN c_xplan 
	     LOOP
	      dbms_output.put_line(curr_plan.plan_table_output);
	    END LOOP;
	END proc_print_plan;

BEGIN
  DBMS_OUTPUT.ENABLE(NULL);
  FOR all_plans in (select distinct sql_id, plan_hash_value from pt_sql_plan where sql_id = '&&sql_id')
  LOOP 
    dbms_output.put_line('======================================');
    dbms_output.put_line('SQL ID           : '||all_plans.sql_id);
    dbms_output.put_line('PLAN HASH VALUE  : '||all_plans.plan_hash_value);
    
    IF all_plans.plan_hash_value IS NOT NULL
      THEN
        --take max snap time for the plan before end of set period
        SELECT MAX(sample_time)
          INTO vPlanLastTime
          FROM pt_sql_plan p
         WHERE p.sql_id=all_plans.sql_id
           AND p.plan_hash_value=all_plans.plan_hash_value;
           
         proc_print_plan(all_plans.sql_id,
                         all_plans.plan_hash_value,
                         vPlanLastTime
                        );
      ELSE
        dbms_output.put_line('The explain plan is missing in the snapshots history');
    END IF;                  
 END LOOP;
END;
/

SET serverout OFF;
