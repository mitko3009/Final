/*
**********************************************************************
**
**   File: sql_text.sql                                                         
**   $Date: 2018/04/16 13:17:18 $                                                                     
**   $Revision: 1.9 $                                                                 
**   Description: Show the full sql_text of a particular cursor from v$sql.
**
**********************************************************************
*/

set head off
set lines 32676

column sql_text format a32676

SELECT sql_fulltext||';' sql_text, upper('sql_text_end') FROM gv$sqlarea WHERE sql_id = '&&sql_id'
;

set head on
