/*
**********************************************************************
**
**   File: ses_info.sql                                                         
**   $Date: 2020/03/24 16:36:00 $                                                                     
**   $Revision: 1.15 $                                                                 
**   Description: List sessions info from v$session and v$process. The sessions could be filtered out by several criteria.
**
**********************************************************************
*/
undef module
undef pid
undef spid
col sid format 999999
col serial# format 999999
col event format a40 truncate
col pid format a11
col spid format a10
col module format a20 truncate
col logon_time format a10
col client_id format a12
col client_info format a16 truncate
col sql_trace format a9
col machine format a10 truncate
col action format a25 truncate
col status format a17 truncate

select * from 
  (  
    select * from 
      (
      SELECT /*+ use_hash(q) */ 
             to_char(s.inst_id) inst_id,
             s.sid,                                   
             s.serial#,                               
             case
               when s.process = '1234' and (s.module = 'JDBC Thin Client' or s.module is null)
               then nvl(substr(s.client_info,1,instr(s.client_info,'@')-1),s.process)
               else s.process 
             end pid,
             p.spid,
             nvl(substr(s.module,1,instr(s.module,'@')-1),s.module) module,
             case 
               when s.status = 'ACTIVE' and s.wait_time=0 and s.wait_class <> 'Idle' then  s.event 
               when s.status = 'ACTIVE' and s.wait_time=0 and s.wait_class = 'Idle' then 'idle-'||s.event
               when s.status = 'ACTIVE' and s.wait_time>0 then  'on cpu' 
               when s.status = 'ACTIVE' and s.wait_time=-1 then 'on cpu' -- whaited short time
               when s.status = 'ACTIVE' and s.wait_time=-2 then 'on cpu'  -- WAITED UNKNOWN TIME
               when s.status = 'ACTIVE' then 'wt:'||s.wait_time||' wc:'||s.wait_class||' ev:'||s.event
               when s.status = 'INACTIVE' then 'idle-'||s.event
               else s.status
             end event,       
             status ||'-'|| last_call_et ||' sec.' status,     
             s.sql_id,    
             q.plan_hash_value,        
             s.client_identifier client_id,
             case 
               when s.program like 'frmweb%' then s.client_info 
               when s.process = '1234' and (s.module = 'JDBC Thin Client' or s.module is null)
               then nvl(substr(s.client_info,instr(s.client_info,'@')+1,instr(s.client_info,'@',1,2)-instr(s.client_info,'@')-1),s.client_info)
               else s.client_info
             end client_info,
             case 
               when trunc(s.logon_time) = trunc(sysdate) 
               then to_char(s.logon_time, 'hh24:mi:ss')
               else to_char(s.logon_time, 'dd/mm/yy')
             end logon_time,
             case 
               when s.machine not like sys_context('userenv','host')||'%' 
               then s.machine 
             end machine,
             case when s.module = 'EXTRANET' 
                  then substr( s.action, instr(s.action,'.',-1) + 1 ) 
                  else s.action
              end action
        FROM (select /*+ NO_MERGE cardinality(100)*/* from gv$session) s, 
             (select /*+ NO_MERGE cardinality(100)*/ inst_id, addr, spid from gv$process) p, 
             (select /*+ NO_MERGE cardinality(100)*/ inst_id, sql_id, child_number, plan_hash_value from gv$sql) q
       WHERE s.type != 'BACKGROUND'
         AND p.addr = s.paddr
         AND p.inst_id = s.inst_id
         AND (
               '&&module' is null 
               	OR 
               	upper(s.module) LIKE upper('%&module%') ESCAPE '\' 
               	OR 
               	upper(s.program) LIKE upper('%&module%') ESCAPE '\'
             )
         AND ('&&pid' is null OR s.process = '&pid')
         AND ('&&sid' is null OR s.sid = '&sid')
         AND ('&&spid' is null OR p.spid = '&spid')
         AND ('&&client_id' is null OR s.client_identifier = '&client_id')
         AND ( nvl('&&inst_id','ALL') = 'ALL' OR to_char(s.inst_id) = '&&inst_id' )
         AND sid != userenv('sid')
         and not exists ( select 1
                            from gv$px_session px
                           where px.qcinst_id = SYS_CONTEXT('USERENV', 'INSTANCE')
                             and px.qcsid = SYS_CONTEXT('USERENV', 'SID')
                             and px.saddr = s.saddr )
         and s.sql_id=q.sql_id(+)
         and s.sql_child_number=q.child_number(+)  
         and s.inst_id = q.inst_id(+) 
      ) s    
    ORDER BY (case when substr(status,1,1)='A' AND event not like 'idl%' then 1 when substr(status,1,1)='A' then 2 else 3 end), inst_id, instr(event,'idle'), case when event like  '%on cpu%' then 1 else 3 end, event, sid, serial#      
  )
WHERE rownum <= to_number(nvl('&&rownum','30'))
;

undef module pid spid
