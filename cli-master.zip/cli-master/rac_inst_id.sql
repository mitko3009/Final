/*
**********************************************************************
**
**   File: rac_inst_id.sql                                                         
**   $Date: 2017/11/29 15:10:02 $                                                                     
**   $Revision: 1.2 $                                                                 
**   Description: Sets the current RAC instance to be analyzed. 
                  The default behavior is to show data for all instances.
                  Entering non-existent instances will result in the default behavior (ALL).
                  Entering a specific instance on a non-RAC environment will result in the default behavior (ALL).
**
**********************************************************************
*/
select to_char(inst_id) inst_id, instance_name, host_name, status from gv$instance;

undef choose_inst_id
column chosen_inst_id for a15 new_value inst_id

select nvl(max(inst_id),'ALL') chosen_inst_id
  from ( select '&choose_inst_id' inst_id
           from dual ) d
 where exists ( select 1
                  from gv$instance i
                 where to_char(i.inst_id) = to_char(d.inst_id) )
   and exists ( select 1
                  from v$parameter 
                 where name = 'cluster_database'
                   and value = 'TRUE' )
;