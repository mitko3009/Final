/*
**********************************************************************
**
**   File: ses_longops.sql                                                         
**   $Date: 2015/09/28 14:16:39 $                                                                     
**   $Revision: 1.2 $                                                                 
**   Description: Show session long operations from v$session_longops.
**
**********************************************************************
*/


select sql_id, message from v$session_longops where sid = nvl('&&sid',sid) and totalwork > sofar;