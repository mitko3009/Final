#!/usr/bin/env ksh
#@##############################################################################
#@#
#@#   File: install.sh
#@#   $Date: 2015/03/06 12:49:32 $
#@#   $Revision: 1.2 $
#@#   Description: Dump a script for creation of all pt scripts.
#@#
#@##############################################################################

for f in `ls $1| grep -v all.sql | grep -v CVS | grep -v sql_expl`
do
 echo "\ncat > $f  <<EOF\n"
 cat $f | sed -e 's/[]\$^[]/\\&/g'
 echo "\nEOF\n"
done
