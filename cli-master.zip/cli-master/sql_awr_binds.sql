/*
**********************************************************************
**
**   File: sql_awr_binds.sql                                                         
**   $Date: 2019/05/13 15:24:48 $                                                                     
**   $Revision: 1.8 $                                                                 
**   Description: Dump N sql bind variables sets from a range of AWR snapshots.
**
**********************************************************************
*/

set serverout on;

declare
  nbPrintSnaps number := nvl('&nb_bind_sets','1');
  nbPrevSnap number := 0;
  nbPrevInstance number := -1;
  
begin
  dbms_output.enable(null);
  
  for b in (
    SELECT snap_id curr_snap,
           begin_interval_time,
           INSTANCE_NUMBER,
           'var '||substr(name,2)||' '||replace(replace(
             case 
               when datatype_string like 'CHAR%' 
               then 'VARCHAR2'||substr(datatype_string,5) 
               else datatype_string
             end
           ,'2000','1000'),'4000','1000')||';' var_decl,
           'exec '||name||' := '''||value_string||''';' var_init
      FROM (
            SELECT distinct
                   s.snap_id,
                   dense_rank() over (order by s.snap_id, s.instance_number) dense_rank,
                   s.begin_interval_time,s.INSTANCE_NUMBER,
                   case 
                     when REGEXP_COUNT(b.name, '[[:digit:]]', 2) >= 1 and REGEXP_INSTR(b.name, '[[:alpha:]]', 2) = 0
                     then replace(b.name,':',':B')
                     else name
                   end name,
                   decode(value_string,'NULL',null,value_string) value_string,
                   datatype_string
              FROM dba_hist_sqlbind b, dba_hist_snapshot s
             WHERE b.sql_id = '&&sql_id'
               AND b.snap_id = s.snap_id
               AND s.snap_id between :v_begin_snap and :v_end_snap
             ORDER BY snap_id, instance_number, length(name), name
           )
     WHERE dense_rank <= nbPrintSnaps
  )
  loop
    if nbPrevSnap != b.curr_snap or nbPrevInstance<>b.instance_number then
      dbms_output.put_line('');
      dbms_output.put_line(to_char(b.curr_snap)||', '||b.begin_interval_time||', instance:'||b.instance_number);
      dbms_output.put_line('--------------------------------');
      nbPrevSnap := b.curr_snap;
      nbPrevInstance := b.instance_number;
    end if;
    
    dbms_output.put_line(b.var_decl);
    dbms_output.put_line(b.var_init);
  end loop;
end;
/

set serverout off;
