/*
**********************************************************************
**
**   File: ses_event.sql                                                         
**   $Date: 2017/11/30 07:04:34 $                                                                     
**   $Revision: 1.8 $                                                                 
**   Description: List session wait events and CPU usage. It could work on a group of sessions defined by their module.
**
**********************************************************************
*/
col time_waited_sec for 99999999999
col average_wait_ms for 9999999999
col max_wait_ms for 9999999999
col event for a50
SELECT trunc(t.time_waited_sec/SUM(t.time_waited_sec) over(partition by t.inst_id)*100) perc, t.*
  FROM (
        SELECT decode(COUNT(DISTINCT ses.inst_id), 1, to_char(MAX(ses.inst_id)), 'ALL') inst_id, 
        	     ev.event, sum(total_waits) total_waits, sum(total_timeouts) total_timeouts,
               sum(time_waited)/100 time_waited_sec, (sum(time_waited)*10/sum(total_waits)) average_wait_ms, max(max_wait)*10 max_wait_ms, count(ses.sid) sessions
          FROM gv$session_event ev, gv$session ses
         WHERE (
				         '&&module' is null 
				         	OR 
				         	upper(ses.module) LIKE upper('%&module%') ESCAPE '\' 
				         	OR 
				         	upper(ses.program) LIKE upper('%&module%') ESCAPE '\'
				         	OR
				         	upper('&&module') = 'NULL' and ses.module IS NULL
				       )
				   AND (  (upper(nvl('&&idle_events','TRUE')) != 'TRUE' and upper(ev.wait_class) != 'IDLE')
				   	      OR
				   	      upper(nvl('&idle_events','TRUE')) = 'TRUE'
				   	   )
				   AND ('&&sid' is null OR ses.sid = '&sid')
				   AND ( nvl('&&inst_id','ALL') = 'ALL' OR to_char(ses.inst_id) = '&&inst_id' )
         	 AND ev.sid = ses.sid
         	 AND ev.inst_id = ses.inst_id
         GROUP BY ses.inst_id, ev.event
         UNION ALL
        SELECT decode(COUNT(DISTINCT ses.inst_id), 1, to_char(MAX(ses.inst_id)), 'ALL') inst_id, 
        	     n.name, null, null, sum(st.value)/100, null, null, count(ses.sid) sessions
          FROM gv$sesstat st, gv$statname n, gv$session ses
         WHERE (
				         '&&module' is null 
				         	OR 
				         	upper(ses.module) LIKE upper('%&module%') ESCAPE '\' 
				         	OR 
				         	upper(ses.program) LIKE upper('%&module%') ESCAPE '\'
				         	OR
				         	upper('&&module') = 'NULL' and ses.module IS NULL
				       )
				   AND ('&&sid' is null OR ses.sid = '&sid')
				   AND ( nvl('&&inst_id','ALL') = 'ALL' OR to_char(ses.inst_id) = '&&inst_id' )
           AND st.sid = ses.sid
           AND st.inst_id = ses.inst_id
           AND st.statistic# = n.statistic#
           AND st.inst_id = n.inst_id
           AND n.name = 'CPU used by this session'
         GROUP BY ses.inst_id, n.name
       ) t
 ORDER BY t.inst_id, t.time_waited_sec DESC
;