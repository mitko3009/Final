/*
**********************************************************************
**
**   File: opt_pack_sql.sql                                                         
**   $Date: 2017/07/26 08:27:34 $                                                                     
**   $Revision: 1.1 $                                                                 
**   Description: Get everything necessary for creation of an optimization file: get binds, get SQL and output all as an optimization file. Final goal is to automate creation of an optimization file.
**
**********************************************************************
*/

SET serverout ON
set lines 300
DECLARE
  lineLen      number:=250;
  vcHostName varchar2(200);
  PROCEDURE p(p_string IN VARCHAR2) IS
    l_string varchar2(32767) DEFAULT p_string;
  BEGIN
    LOOP
      EXIT WHEN l_string IS NULL;
      dbms_output.put_line(substr(l_string, 1, lineLen));
      l_string := substr(l_string, lineLen+1);
    END LOOP;
  END;
  procedure setLen is 
    ver varchar2(30);
  begin
    select substr(version,1,2) into ver from v$instance;
    if ver='10' then 
      lineLen:=250;--765;
    else
      lineLen:=32767/2;
    end if;
  end;
BEGIN
  --make output buffer large
  dbms_output.enable(NULL);
  setLen;
  
  SELECT instance_name||' '||host_name INTO vcHostName FROM v$instance;


  dbms_output.put_line('/********************************************************************************');
  dbms_output.put_line('*********       E-mail subject: ');
  dbms_output.put_line('*********             Instance: ' || vcHostName);
  dbms_output.put_line('*********          Description: ');
  dbms_output.put_line('Problem: ');
  dbms_output.put_line('Slowness has been experienced in ');
  dbms_output.put_line(chr(10));
  dbms_output.put_line('Analysis:');
  dbms_output.put_line('SQL from ');
  dbms_output.put_line(chr(10));
  dbms_output.put_line('Suggestions:');
  dbms_output.put_line(chr(10));  
  dbms_output.put_line('*********               SQL_ID: ');
  dbms_output.put_line('*********      Program/Package:  Line: ');
  dbms_output.put_line('*********              Request: ');
  dbms_output.put_line('*********               Author: ');
  dbms_output.put_line('********* Received e-mail date: ' ||
                       to_char(SYSDATE, 'dd-mm-yyyy'));
  dbms_output.put_line('*********      Resolution date: ' ||
                       to_char(SYSDATE, 'dd-mm-yyyy'));
  dbms_output.put_line('***********************************************************************************/');
  dbms_output.put(chr(10));
  dbms_output.put_line('/********************************OLD SQL*******************************************/');
  dbms_output.put(chr(10));

 
  dbms_output.put_line(chr(10));
  dbms_output.put_line('set lines 300');
  dbms_output.put_line(chr(10));
  dbms_output.put_line(chr(10));

  --write statement to output the plan  
  dbms_output.put_line('SELECT * FROM table(dbms_xplan.display_cursor(NULL, NULL ,''RUNSTATS_LAST +peeked_binds +cost +outline''));');
  dbms_output.put_line(chr(10));

  dbms_output.put_line(chr(10));

  dbms_output.put_line('/********************************OLD SQL*******************************************/');

  dbms_output.put_line('/********************************OLD Metrics***************************************/');
  dbms_output.put_line('/*');
  dbms_output.put_line(chr(10));
  dbms_output.put_line('*/');
  dbms_output.put_line('/********************************OLD Metrics***************************************/');

  dbms_output.put_line('/********************************New SQL*******************************************/');

  dbms_output.put_line(';');
  dbms_output.put_line(chr(10));
  dbms_output.put_line('SELECT * FROM table(dbms_xplan.display_cursor(NULL, NULL ,''RUNSTATS_LAST +peeked_binds +cost +outline ''));');
  dbms_output.put_line(chr(10));
  dbms_output.put_line('/********************************New SQL*******************************************/');
  dbms_output.put_line('/********************************New Metrics***************************************/');
  dbms_output.put_line('/*');
  dbms_output.put_line('');  
  dbms_output.put_line('*/');
  dbms_output.put_line('/********************************New Metrics***************************************/');
  dbms_output.put_line('/********************************Index statistics**********************************/');
  dbms_output.put_line('/*');
  dbms_output.put_line('*/');
  dbms_output.put_line('/********************************Index statistics**********************************/');
  dbms_output.put_line('/********************************Other SQLs****************************************/');
  dbms_output.put_line('/*');
  dbms_output.put_line('*/ ');
  dbms_output.put_line('/********************************Other SQLs****************************************/');
END;
/
SET serverout OFF;
