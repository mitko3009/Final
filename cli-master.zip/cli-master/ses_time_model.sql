/*
**********************************************************************
**
**   File: ses_stat.sql                                                         
**   $Date: 2017/11/30 07:13:53 $                                                                     
**   $Revision: 1.5 $                                                                 
**   Description: Show session time distribution from v$sess_time_model. The output is formatted as per the parent-child relationships and ordered by elapsed time.
**
**********************************************************************
*/

col stat_name format a50

select t.inst_id, t.stat_name_prefix||t.stat_name stat_name, round(t.value/1000000) "time(s)", round(t.value/db_time.value*100) "perc(%)"
  from ( select decode(COUNT(DISTINCT ses.inst_id), 1, to_char(MAX(ses.inst_id)), 'ALL') inst_id,
               case m.stat_name
                when 'DB time'                                          then '1. '
                when 'DB CPU'                                           then ' 1.1. '
                when 'connection management call elapsed time'          then ' 1.2. '
                when 'sequence load elapsed time'                       then ' 1.3. '
                when 'sql execute elapsed time'                         then ' 1.4. '
                when 'parse time elapsed'                               then ' 1.5. '
                when 'hard parse elapsed time'                          then '  1.5.1. '
                when 'hard parse (sharing criteria) elapsed time'       then '   1.5.1.1. '
                when 'hard parse (bind mismatch) elapsed time'          then '    1.5.1.1.1. '
                when 'failed parse elapsed time'                        then '  1.5.2. '
                when 'failed parse (out of shared memory) elapsed time' then '   1.5.2.1. '
                when 'PL/SQL execution elapsed time'                    then ' 1.6. '
                when 'inbound PL/SQL rpc elapsed time'                  then ' 1.7. '
                when 'PL/SQL compilation elapsed time'                  then ' 1.8. '
                when 'Java execution elapsed time'                      then ' 1.9. '
                when 'repeated bind elapsed time'                       then ' 1.9. '
                when 'background elapsed time'                          then '2. '
                when 'background cpu time'                              then ' 2.1. '
                when 'RMAN cpu time (backup/restore)'                   then '  2.1.1. '
               end stat_name_prefix,
               m.stat_name,
               sum(m.value) value
          from gv$sess_time_model m, gv$session ses
         where (
				         '&&module' is null 
				         	OR 
				         	upper(ses.module) LIKE upper('%&module%') ESCAPE '\' 
				         	OR 
				         	upper(ses.program) LIKE upper('%&module%') ESCAPE '\'
				         	OR
				         	upper('&&module') = 'NULL' and ses.module IS NULL
				       )
				   and ('&&sid' is null OR ses.sid = '&sid')
				   and ( nvl('&&inst_id','ALL') = 'ALL' OR to_char(ses.inst_id) = '&&inst_id' )
           and m.sid = ses.sid
           and m.inst_id = ses.inst_id
         group by ses.inst_id, m.stat_name ) t,
       ( select decode(COUNT(DISTINCT ses.inst_id), 1, to_char(MAX(ses.inst_id)), 'ALL') inst_id, 
               sum(m.value) value
          from gv$sess_time_model m, gv$session ses
         where (
				         '&&module' is null 
				         	OR 
				         	upper(ses.module) LIKE upper('%&module%') ESCAPE '\' 
				         	OR 
				         	upper(ses.program) LIKE upper('%&module%') ESCAPE '\'
				         	OR
				         	upper('&&module') = 'NULL' and ses.module IS NULL
				       )
           and ('&&sid' is null OR ses.sid = '&sid')
           and ( nvl('&&inst_id','ALL') = 'ALL' OR to_char(ses.inst_id) = '&&inst_id' )
           and m.sid = ses.sid
           and m.inst_id = ses.inst_id
           and m.stat_name = 'DB time'
         group by ses.inst_id ) db_time
 where round(t.value/db_time.value*100) > 3
   and t.inst_id = db_time.inst_id
 order by t.inst_id, t.value desc;