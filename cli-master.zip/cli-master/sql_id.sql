/*
**********************************************************************
**
**   File: sql_id.sql                                                         
**   $Date: 2019/05/13 15:28:57 $                                                                     
**   $Revision: 1.3 $                                                                 
**   Description: Display all cursors from v$sql that match the search criteria (sql_text).
**
**********************************************************************
*/

COL SQL_ID FORMAT A20
column sql_text format a165
select distinct sql_id, sql_text
  from v$sql 
 where upper(sql_text) like upper('%&sql_text%') and upper(sql_text) not like '%V$SQL%'
;