/*  
**********************************************************************
**
**   File: sql_pack.sql                                                         
**   $Date: 2016/01/20 07:42:09 $                                                                     
**   $Revision: 1.5 $                                                                 
**   Description: Gathers all the needed info for an SQL cursor from the shared pool. It appends the output of other scripts.
**
**********************************************************************
*/

set verify off
set feedback off

column dtcreat new_value dtcreat
column host_name format a30
column instance_name format a20 new_value instance_name
column imx_version format a20 new_value imx_version
column module new_value module
-- accept input without generating useless output
declare
  strDummy varchar2(400):= '&&sql_id'||'&&client'||'&&mail_subject'||'&&yourname';
begin
	null;
end;
/
set termout off
select to_char(sysdate,'dd-mm-yyyy') dtcreat from dual;
select value instance_name from imx_instance where key='INSTANCE_NAME' and rownum=1;
select value imx_version from imx_instance where key='INSTANCE_VERSION' and rownum=1;
select nvl(substr(module,1,instr(module,'@')-1),module) module from v$sql where sql_id='&sql_id' and rownum=1;
set termout on

prompt 
prompt /***********************************************************************************
prompt *********    Optimization file: &&client-&instance_name-V&imx_version-&module-&sql_id-&dtcreat..sql
prompt *********       E-mail subject: &&mail_subject
prompt *********              Problem: 
prompt *********             Analysis: 
prompt *********           Suggestion: 
prompt *********               Module: &module
prompt *********               sql_id: &sql_id
prompt *********               Author: &&yourname
prompt *********        Creation date: &dtcreat
prompt ***********************************************************************************/
prompt
prompt /******************************* Old SQL ******************************************/
@sql_binds.sql
@sql_text.sql
prompt /******************************* Old SQL ******************************************/
prompt /***************************** Old Metrics ****************************************/
prompt /*
define sql_text='' 
define module=''
define rownum=''
@sql_stats.sql
define prev='n'
define mode=''
@sql_plan.sql
undef prev
undef mod
prompt */
prompt /***************************** Old Metrics ****************************************/
prompt /******************************* New SQL ******************************************/
prompt 
prompt /******************************* New SQL ******************************************/
prompt /***************************** New Metrics ****************************************/
prompt /*
prompt
prompt */
prompt /***************************** New Metrics ****************************************/
prompt /*************************** Index statistics *************************************/
prompt /*
set termout off
set serveroutput on
set trimspool on
spool /tmp/exec_tab_ind_stats.sql
BEGIN
  FOR t IN
  (
    SELECT DISTINCT nvl(i.table_name, p.object_name) table_name
      FROM v$sql_plan p, all_indexes i
     WHERE p.sql_id = '&sql_id'
       AND p.object_type IN ('TABLE', 'INDEX')
       AND i.index_name(+) = p.object_name
  )
  LOOP
    dbms_output.put_line('define table_name='''||t.table_name||'''');
    dbms_output.put_line('@tab_ind_stats');
    dbms_output.put_line('undef table_name');
  END LOOP;
END;
/
spool off;
set serverout off;
set termout on;
@/tmp/exec_tab_ind_stats.sql
prompt */
prompt /*************************** Index statistics *************************************/
prompt /****************************** Other SQLs ****************************************/
prompt -- other SQLs with the same problem
prompt /****************************** Other SQLs ****************************************/

set verify on
set feedback on; 
