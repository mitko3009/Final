/*
**********************************************************************
**
**   File: sp.sql                                                         
**   $Date: 2014/09/22 14:10:29 $                                                                     
**   $Revision: 1.1 $                                                                 
**   Description: Execute the standard script for STATSPACK report generation
**
**********************************************************************
*/

@$RDBMS_HOME/rdbms/admin/spreport.sql
