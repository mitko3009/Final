sql
set lines 9999 pages 9999 long 9999 longchunksize 9999
column global_name new_value gname
set termout off head off
define gname=idle
column global_name new_value gname
select lower(user) || '@' || substr( global_name, 1, decode( dot, 0, length(global_name), dot-1) )||'@'|
|userenv('sid') global_name from (select global_name, instr(global_name,'.') dot from global_name );
set sqlprompt '&gname> '
set termout on head on
alter session set statistics_level=all;
select sid, serial#, process pid from v$session where sid=userenv('sid');
exec dbms_application_info.set_client_info('pt');



/*
**********************************************************************
**
**   File: app_ad_loads.sql                                                         
**   $Date: 2014/07/07 06:40:22 $                                                                     
**   $Revision: 1.3 $                                                                 
**   Description: List the last "N" AD loads.
**
**********************************************************************
*/

col load_from format a20
col load_to format a20
col load_begin format a20
col load_end format a20
col load_mode format a20
col load_status format a20
SELECT *                                                                       
  FROM (SELECT  id,                                                            
                to_char(load_from, 'dd/mm/yyyy hh24:mi:ss') load_from,         
                to_char(load_to, 'dd/mm/yyyy hh24:mi:ss') load_to,             
                to_char(load_begin, 'dd/mm/yyyy hh24:mi:ss') load_begin,       
                to_char(load_end, 'dd/mm/yyyy hh24:mi:ss') load_end, load_mode,
                load_status                                                    
           FROM ad_loads                                                       
          ORDER BY ID DESC)                                                    
 WHERE ROWNUM <= &ROWNUM                                                      
 ORDER BY ID
;/*
**********************************************************************
**
**   File: app_ad_objects.sql                                                         
**   $Date: 2014/07/07 06:40:22 $                                                                     
**   $Revision: 1.3 $                                                                 
**   Description: List AD objects information for a particular ETL run.
**
**********************************************************************
*/

 SELECT lo_object_name,
        to_char(lo_load_begin,'dd/mm/yyyy hh24:mi:ss') load_begin,
        to_char(lo_load_end,'dd/mm/yyyy hh24:mi:ss') load_end,
        lo_load_status
   FROM ad_load_objects
  WHERE lo_load_id = &load_id
  ORDER BY lo_load_number
;-- Execution time by object for given period
-- Parameters: 
--         FROM      - varchar2, begin of the period, format date 'DD/MM/YYYY'
--         TO        - varchar2, end of the period, format date 'DD/MM/YYYY'
--        PROC_NAME  - varchar2, the name of the procedure, package, base table name, mview name

COLUMN lo_object_name     FORMAT A30   HEADING "Object Name";
COLUMN load_begin         FORMAT A20   HEADING "Load Begin";
COLUMN load_end           FORMAT A20   HEADING "Load End";
COLUMN elapsed_time       FORMAT A9    HEADING "Elapsed";
COLUMN lo_load_status     FORMAT A20   HEADING "Load Status";

SELECT lo_object_name,lo_load_begin,lo_load_end, elapsed_time ,lo_load_status
  FROM (SELECT f.lo_object_name,
               f.lo_load_begin,
               f.lo_load_end,
               LPAD(f.elapsed_time_h, 2, '0') || ':' ||
               LPAD(f.elapsed_time_m, 2, '0') || ':' ||
               LPAD(elapsed_time_s, 2, '0')              AS elapsed_time,
               f.lo_load_status
          FROM (SELECT d.lo_object_name,
                       d.lo_load_begin,
                       d.lo_load_end,
                       CASE
                         WHEN FLOOR(elapsed_time_m) > 0 THEN
                          ROUND(elapsed_time_s, 0) -
                          FLOOR(elapsed_time_m) * 60
                         ELSE
                          ROUND(elapsed_time_s, 0)
                       END AS elapsed_time_s,
                       CASE
                         WHEN FLOOR(elapsed_time_h) > 0 THEN
                          FLOOR(elapsed_time_m) - floor(elapsed_time_h) * 60
                         ELSE
                          FLOOR(elapsed_time_m)
                       END AS elapsed_time_m,
                       FLOOR(elapsed_time_h) AS elapsed_time_h,
                       d.lo_load_status
                  FROM (SELECT SUBSTR(p.load_begin, 1, 10)                       AS load_begin,
                               SUBSTR(nvl(p.load_end, SYSDATE), 1, 10)           AS load_end,
                               lo.lo_object_name                                 AS lo_object_name,
                               TO_CHAR(lo.lo_load_begin,
                                       'DD/MM/YYYY HH24:MI:SS')                  AS lo_load_begin,
                               TO_CHAR(lo.lo_load_end, 'DD/MM/YYYY HH24:MI:SS')  AS lo_load_end,
                               (NVL(lo.lo_load_end, SYSDATE) -
                               lo.lo_load_begin) * 60 * 60 * 24                  AS elapsed_time_s,
                               (NVL(lo.lo_load_end, SYSDATE) -
                               lo.lo_load_begin) * 60 * 24                       AS elapsed_time_m,
                               (NVL(lo.lo_load_end, SYSDATE) -
                               lo.lo_load_begin) * 24                            AS elapsed_time_h,
                               lo.lo_load_status                                 AS lo_load_status
                          FROM ad_loads p,
                               ad_load_objects lo,
                               (SELECT d.id
                                  FROM (SELECT l.id,
                                               l.load_mode,
                                               l.load_begin,
                                               row_number() over(ORDER BY l.id DESC) AS rnk
                                          FROM ad_loads l
                                         WHERE l.load_mode LIKE 'COMPLETE%') d
                                 WHERE trunc(d.load_begin) BETWEEN trunc(NVL(to_date('&FROM', 'dd/mm/yyyy'), SYSDATE)) AND trunc(NVL(to_date('&TO', 'dd/mm/yyyy'), SYSDATE))) f
                         WHERE 1 = 1
                           AND p.id = lo.lo_load_id(+)
                           AND p.load_mode LIKE 'COMPLETE%'
                           AND p.id = f.id
                         ORDER BY lo.lo_load_number) d) f
         WHERE UPPER(f.lo_object_name) = UPPER('&object_name')
         ORDER BY to_date(f.lo_load_begin,'dd/mm/yyyy hh24:mi:ss') DESC);
/*
**********************************************************************
**
**   File: ash.sql                                                         
**   $Date: 2014/07/07 06:40:22 $                                                                     
**   $Revision: 1.3 $                                                                 
**   Description: Execute the extended script for ASH report generation that applies a number of filters.
**
**********************************************************************
*/

@$RDBMS_HOME/rdbms/admin/ashrpti.sql
/*
**********************************************************************
**
**   File: ash_awr_view.sql                                                         
**   $Date: 2014/07/07 06:40:22 $
**   $Revision: 1.3 $
**   Description: Query the historized session activity (dba_hist_active_ses_history). Filter by different criteria. Uses a user defined group by clause.
**
**********************************************************************
*/
column snap_id     format 99999990 heading 'Snap Id';
column snapdat     format a18  heading 'Snap Started' just c;
column startup_time format a18  heading 'Instance Startup';
column begin_time format a20 new_value v_begin_time noprint;
column end_time format a20 new_value v_end_time noprint;

select to_char(s.startup_time,'dd Mon "at" HH24:mi:ss')  startup_time
		 , s.snap_id                                         snap_id
     , to_char(s.end_interval_time,'dd Mon YYYY HH24:mi') snapdat
  from dba_hist_snapshot s
 where trunc(s.end_interval_time) = trunc(sysdate) - to_number(nvl('&days_back',0))
 order by s.startup_time, s.snap_id
/*1*/;

var v_begin_snap number;
var v_end_snap number;
var v_begin_time varchar2(20);
var v_end_time varchar2(20);

BEGIN
  SELECT nvl('&&begin_snap', MIN(snap_id)), nvl('&&end_snap', MAX(snap_id))
    INTO :v_begin_snap, :v_end_snap
    FROM dba_hist_snapshot
  ;
  SELECT to_char(end_interval_time,'dd Mon YYYY HH24:mi') into :v_begin_time from dba_hist_snapshot where snap_id = :v_begin_snap;
  SELECT to_char(end_interval_time,'dd Mon YYYY HH24:mi') into :v_end_time from dba_hist_snapshot where snap_id = :v_end_snap;
END;
/

TTITLE center "Analyzed from '" v_begin_time "' to '" v_end_time "'" SKIP 1 center ''

col "FROM" format a30
col "TO" format a30
col blocking format 99999999
col event format a50
col MODULE format a17
col perc format a4
SELECT *
  FROM (
				SELECT decode(COUNT(DISTINCT ash.module), 1, MAX(nvl(substr(ash.module,1,instr(ash.module,'@')-1),ash.module))) MODULE,
				       decode(COUNT(DISTINCT ash.sql_id), 1, MAX(ash.sql_id)) sql_id,
				       decode(COUNT(DISTINCT ash.session_id), 1, MAX(ash.session_id)) sid,
				       decode(COUNT(DISTINCT nvl(ash.event, ash.session_state)), 1, MAX(nvl(ash.event, ash.session_state))) event,
				       MIN(ash.sample_time) "FROM",
				       MAX(ash.sample_time) "TO",
				       10*COUNT(*) ACTIVE,
				       to_char(round(COUNT(*)/SUM(COUNT(*)) over()*100))||'%' perc,
				       decode(COUNT(DISTINCT o.object_name), 1, MAX(o.object_name)) object
				    --,max(ash.blocking_session) blocking
				  FROM dba_hist_active_sess_history ash -- v$active_session_history ash
				  		,all_objects o
				 WHERE ash.snap_id BETWEEN :v_begin_snap+1 AND :v_end_snap
				   AND (
				         '&&module' is null 
				         	OR 
				         	upper(ash.module) LIKE upper('%&module%') ESCAPE '\' 
				         	OR 
				         	upper(ash.program) LIKE upper('%&module%') ESCAPE '\'
				       )
				   AND ('&&sql_id' IS NULL OR ash.sql_id = '&sql_id')
				   AND ('&&sid' IS NULL OR ash.session_id = '&sid')
				   AND ('&&event' IS NULL OR upper(nvl(ash.event, ash.session_state)) LIKE upper('%&event%') ESCAPE '\')
				   AND o.object_id(+) = ash.current_obj#
				 GROUP BY &group_by
				 ORDER BY COUNT(*) DESC
			 )
 WHERE rownum <= 30
; /*
**********************************************************************
**
**   File: ash_user_act.sql                                                         
**   $Date: 2014/07/07 06:40:22 $
**   $Revision: 1.3 $
**   Description: Show user session history for the current day based on ASH repository.
**
**********************************************************************
*/

undef hh

SELECT ash.sample_time, decode(ash.session_state, 'WAITING', ash.event, ash.session_state) state, ash.sql_id, blocker.sid blocker
  FROM dba_hist_active_sess_history ash, v$session ses, t_env u, v$session blocker
 WHERE ash.sample_time BETWEEN trunc(SYSDATE)+to_number('&&hh')/24 AND trunc(SYSDATE)+(to_number('&hh')+1)/24
   AND ash.program LIKE 'frmweb%'
   AND ses.sid = ash.session_id
   AND u.pid = ses.process
   AND u.logname = '&login'
   AND blocker.sid(+) = ash.blocking_session
 ORDER BY ash.sample_time
;

undef hh/*
**********************************************************************
**
**   File: ash_view.sql                                                         
**   $Date: 2014/07/07 06:40:22 $
**   $Revision: 1.3 $
**   Description: Query the session activity (v$active_session_history). Filter by different criteria. Uses a user defined group by clause.
**
**********************************************************************
*/

col "FROM" format a30
col "TO" format a30
col blocking format 99999999
col event format a50
col MODULE format a17
col perc format a4
SELECT decode(COUNT(DISTINCT ash.module), 1, MAX(nvl(substr(ash.module,1,instr(ash.module,'@')-1),ash.module))) MODULE,
       decode(COUNT(DISTINCT ash.sql_id), 1, MAX(ash.sql_id)) sql_id,
       decode(COUNT(DISTINCT ash.session_id), 1, MAX(ash.session_id)) sid,
       decode(COUNT(DISTINCT nvl(ash.event, ash.session_state)), 1, MAX(nvl(ash.event, ash.session_state))) event,
       MIN(ash.sample_time) "FROM",
       MAX(ash.sample_time) "TO",
       COUNT(*) cnt,
       to_char(round(COUNT(*)/SUM(COUNT(*)) over()*100))||'%' perc,
       decode(COUNT(DISTINCT o.object_name), 1, MAX(o.object_name)) object
    --,decode(COUNT(DISTINCT ash.blocking_session), 1, MAX(ash.blocking_session), 0, null, 'multiple') blocking
  FROM v$active_session_history ash
  		,all_objects o
 WHERE to_char(ash.sample_time, 'hh24mi') between nvl('&&from_hhmi','0000') and nvl('&&to_hhmi','2359')
   AND (
         '&&module' is null 
         	OR 
         	upper(ash.module) LIKE upper('%&module%') ESCAPE '\' 
         	OR 
         	upper(ash.program) LIKE upper('%&module%') ESCAPE '\'
       )
   AND ('&&sql_id' IS NULL OR ash.sql_id = '&sql_id')
   AND ('&&sid' IS NULL OR ash.session_id = '&sid')
   AND ('&&event' IS NULL OR upper(nvl(ash.event, ash.session_state)) LIKE upper('%&event%') ESCAPE '\')
   AND o.object_id(+) = ash.current_obj#
 GROUP BY &group_by
 ORDER BY COUNT(*) DESC
; /*
**********************************************************************
**
**   File: awr.sql                                                         
**   $Date: 2014/07/07 06:40:22 $                                                                     
**   $Revision: 1.3 $                                                                 
**   Description: Execute the standard script for AWR generation
**
**********************************************************************
*/

@$RDBMS_HOME/rdbms/admin/awrrpt.sql
/*
**********************************************************************
**
**   File: awr_diff.sql                                                         
**   $Date: 2014/07/07 06:40:22 $                                                                     
**   $Revision: 1.3 $                                                                 
**   Description: Execute the standard script for AWR report that compares 2 periods.
**
**********************************************************************
*/

@$RDBMS_HOME/rdbms/admin/awrddrpt.sql/*
**********************************************************************
**
**   File: awr_snapshots.sql                                                         
**   $Date: 2014/07/07 06:40:22 $                                                                     
**   $Revision: 1.3 $                                                                 
**   Description: List the AWR snapshots in a format similar to the standard AWR script.
**
**********************************************************************
*/

column snap_id     format 99999990 heading 'Snap Id';
column snapdat     format a18  heading 'Snap Started' just c;
column startup_time format a18  heading 'Instance Startup';
column lvl         format 99   heading 'Snap|Level';

select to_char(s.startup_time,'dd Mon "at" HH24:mi:ss')  startup_time
		 , s.snap_id                                         snap_id
     , to_char(s.end_interval_time,'dd Mon YYYY HH24:mi') snapdat
  from dba_hist_snapshot s
 where trunc(s.end_interval_time) = trunc(sysdate) - to_number(nvl('&days_back',0))
 order by s.startup_time, s.snap_id
 ;/*
**********************************************************************
** 
**   File: sys_unind_fk.sql                                                         
**   $Date: 2014/07/07 06:40:22 $                                                                     
**   $Revision: 1.3 $                                                                 
**   Description: List the unindexed foreign keys. Those FKs are dangerous as they cause locks on whole tables. No data found means "OK".
**
**********************************************************************
*/

col COLUMNS format a50
break on table_name SKIP 1

select table_name, constraint_name,
     cname1 || nvl2(cname2,','||cname2,null) ||
     nvl2(cname3,','||cname3,null) || nvl2(cname4,','||cname4,null) ||
     nvl2(cname5,','||cname5,null) || nvl2(cname6,','||cname6,null) ||
     nvl2(cname7,','||cname7,null) || nvl2(cname8,','||cname8,null) COLUMNS    
  from ( select b.table_name,
                b.constraint_name,
                max(decode( position, 1, column_name, null )) cname1,
                max(decode( position, 2, column_name, null )) cname2,
                max(decode( position, 3, column_name, null )) cname3,
                max(decode( position, 4, column_name, null )) cname4,
                max(decode( position, 5, column_name, null )) cname5,
                max(decode( position, 6, column_name, null )) cname6,
                max(decode( position, 7, column_name, null )) cname7,
                max(decode( position, 8, column_name, null )) cname8,
                count(*) col_cnt
           from (select substr(table_name,1,30) table_name,
                        substr(constraint_name,1,30) constraint_name,
                        substr(column_name,1,30) column_name,
                        position
                   from user_cons_columns ) a,
                user_constraints b
          where a.constraint_name = b.constraint_name
            and b.constraint_type = 'R'
          group by b.table_name, b.constraint_name
       ) cons
 where col_cnt > ALL
         ( select count(*)
             from user_ind_columns i
            where i.table_name = cons.table_name
              and i.column_name in (cname1, cname2, cname3, cname4,
                                    cname5, cname6, cname7, cname8 )
              and i.column_position <= cons.col_cnt
              -- imagine the following indexes don't exist
              -- AND i.index_name NOT IN ('T_INDICES$TYPE_VIN_PLUS')
            group by i.index_name
         )
 order by 1,2,3
;/*
**********************************************************************
**
**   File: ind_analyze.sql                                                         
**   $Date: 2014/07/07 06:40:22 $                                                                     
**   $Revision: 1.3 $                                                                 
**   Description: Analyze index and show the results.
**
**********************************************************************
*/

undef INDEX_NAME;
ANALYZE INDEX &&INDEX_NAME VALIDATE STRUCTURE;
SELECT lf_blks, del_lf_rows FROM Index_Stats WHERE name='&INDEX_NAME';
undef INDEX_NAME;/*
**********************************************************************
**
**   File: ind_create.sql                                                         
**   $Date: 2014/07/07 06:40:22 $                                                                     
**   $Revision: 1.3 $                                                                 
**   Description: Create a test index with "test_pt_" prefix.
**
**********************************************************************
*/

SET TIMING ON;
SET serverout ON;
DECLARE
  l_prefix VARCHAR2(10) := 'TEST_'||'&&yourname'||'_';
  l_table_name VARCHAR2(30) := upper('&table_name');
  l_index_name VARCHAR2(30) := upper(l_prefix||'&index_name');
  l_fields_cvs VARCHAR2(99) := upper('&fields_csv');
  l_parallel VARCHAR2(2) := '&parallel';
  l_create_index VARCHAR2(200) := 'CREATE INDEX '||l_index_name||' ON '||l_table_name||'('||l_fields_cvs||') UNUSABLE';
  l_unlock_stats VARCHAR2(200) := 'BEGIN DBMS_STATS.UNLOCK_TABLE_STATS(USER,'''||l_table_name||'''); END;';
  l_alter_index_rebuild VARCHAR2(200) := 'ALTER INDEX '||l_index_name||' REBUILD COMPUTE STATISTICS NOLOGGING PARALLEL '||l_parallel;
  l_alter_index_logging VARCHAR2(200) := 'ALTER INDEX '||l_index_name||' LOGGING NOPARALLEL';
  l_lock_stats VARCHAR2(200) := 'BEGIN DBMS_STATS.LOCK_TABLE_STATS(USER,'''||l_table_name||'''); END;';
BEGIN
  EXECUTE IMMEDIATE l_create_index;
  EXECUTE IMMEDIATE l_unlock_stats;
  EXECUTE IMMEDIATE l_alter_index_rebuild;
  EXECUTE IMMEDIATE l_alter_index_logging;
  EXECUTE IMMEDIATE l_lock_stats;
  dbms_output.put_line(l_create_index||';');
  dbms_output.put_line(l_unlock_stats);
  dbms_output.put_line(l_alter_index_rebuild||';');
  dbms_output.put_line(l_alter_index_logging||';');
  dbms_output.put_line(l_lock_stats);    
END;
/
SET serverout OFF;
SET TIMING OFF;/*
**********************************************************************
**
**   File: ind_gather_stats.sql                                                         
**   $Date: 2014/07/07 06:40:22 $                                                                     
**   $Revision: 1.3 $                                                                 
**   Description: Gather the statistics of a table index.
**
**********************************************************************
*/

DECLARE 
vcIMXDB VARCHAR2(30); 
vcTABLE_NAME VARCHAR2(30); 
vcVersion varchar2(100);
vcindname VARCHAR2(30):=upper('&INDEX_NAME'); 
lSampleSize VARCHAR2(30) := '&sample_size';
BEGIN
  SELECT version
    INTO vcVersion
    FROM v$instance;
  SELECT owner, TABLE_name INTO vcIMXDB, vcTable_name FROM all_Indexes WHERE index_name=vcIndname;
  dbms_stats.unlock_table_stats(ownname => vcIMXDB,tabname => vcTABLE_NAME); 
  DBMS_STATS.GATHER_INDEX_STATS(ownname => vcIMXDB, indname => vcindname ,
  ESTIMATE_PERCENT => 
    case 
    when lSampleSize is NULL AND vcVersion LIKE '11%' then 
    dbms_stats.auto_sample_size
    when lSampleSize is NULL then 30
    else to_number(lSampleSize) END 
  , degree => dbms_stats.default_degree);  
  dbms_stats.lock_table_stats(ownname => vcIMXDB,tabname => vcTABLE_NAME); 
end; 
/ 
set lines 9999 pages 9999 long 99999 longchunksize 99999
column global_name new_value gname
set termout off head off
define gname=idle
column global_name new_value gname
select lower(user) || '@' || substr( global_name, 1, decode( dot, 0, length(global_name), dot-1) )||'@'||userenv('sid') global_name from (select global_name, instr(global_name,'.') dot from global_name );
set sqlprompt '&gname> '
set termout on head on
alter session set statistics_level=all;
select sid, serial#, process pid from v$session where sid=userenv('sid');
exec dbms_application_info.set_client_info('pt');
var vcOwner varchar2(30);
exec :vcOwner:=USER;
/*
**********************************************************************
**
**   File: opt_pack_sql.sql                                                         
**   $Date: 2014/07/07 06:40:22 $                                                                     
**   $Revision: 1.3 $                                                                 
**   Description: Get everything necessary for creation of an optimization file: get binds, get SQL and output all as an optimization file. Final goal is to automate creation of an optimization file.
**
**********************************************************************
*/

SET serverout ON
set lines 300
DECLARE
  vcSqlText    VARCHAR2(4000);
  vcHostName   VARCHAR2(100);
  vcSourceName VARCHAR2(100);
  nSourceLine NUMBER;
  vcModule VARCHAR2(100);
  vcTypeWait VARCHAR2(30);
  nElapsedTime NUMBER;
  nTypedWaitTime NUMBER;
  nTypeWaitTime NUMBER;
  nbgets NUMBER;
  nExecutions NUMBER;
  -- Local variables here
  --SQL ID of the sql before optimization
  vcOldSqlId VARCHAR2(30) := '&old_sql_id';
  --SQL ID of the sql after optimization
  vcNewSqlId VARCHAR2(30) := '&new_sql_id';  
  --print function used for strings longer than 255 characters
  PROCEDURE p(p_string IN VARCHAR2) IS
    l_string LONG DEFAULT p_string;
  BEGIN
    LOOP
      EXIT WHEN l_string IS NULL;
      dbms_output.put_line(substr(l_string, 1, 250));
      l_string := substr(l_string, 251);
    END LOOP;
  END;
BEGIN
  --make output buffer large
  dbms_output.enable(NULL);

  SELECT instance_name||' '||host_name INTO vcHostName FROM v$instance;

  SELECT ao.object_name,
         vsql.PROGRAM_LINE#,
         vsql.MODULE,         
         vsql.EXECUTIONS,
         vsql.ELAPSED_TIME,
         vsql.BUFFER_GETS,         
         round(greatest(application_wait_time, concurrency_wait_time, cluster_wait_time, user_io_wait_time, plsql_exec_time, java_exec_time, cpu_time)),   
       CASE
          greatest(application_wait_time, concurrency_wait_time, cluster_wait_time, user_io_wait_time, plsql_exec_time, java_exec_time, cpu_time)
           WHEN application_wait_time THEN
            0
           WHEN concurrency_wait_time THEN
            1
           WHEN cluster_wait_time THEN
            2
           WHEN user_io_wait_time THEN
            3
           WHEN plsql_exec_time THEN
            4
           WHEN java_exec_time THEN
            5
           WHEN cpu_time THEN
            6
         END max_wait
    INTO vcSourceName,
         nSourceLine,
         vcModule,
         nExecutions,
         nElapsedTime,
         nbgets,         
         nTypedWaitTime,
         nTypeWaitTime
    FROM v$sql vsql, all_objects ao
   WHERE vsql.sql_id = '&&sql_id'
     AND ao.object_id (+) = vsql.program_id
     AND ROWNUM = 1;

  -- Test statements here
  dbms_output.put_line('/********************************************************************************');
  dbms_output.put_line('*********       E-mail subject: ');
  dbms_output.put_line('*********             Instance: ' || vcHostName);
  dbms_output.put_line('*********          Description: ');
  dbms_output.put_line('Problem: ');
  dbms_output.put_line('Slowness has been experienced in '|| vcModule||' module.');
  dbms_output.put_line('Analysis:');
  dbms_output.put_line('SQL &&sql_id from '||vcSourceName||' is one of the top statements in '||vcModule ||' module.');
  dbms_output.put_line('Execution of SQL &&sql_id is problematic due to its '
  ||(case when nExecutions>10000 then 'high number of executions: '|| nEXECUTIONS
  when nTypeWaitTime=3 then 'high IO wait time: '||nTypedWaitTime
  when nTypeWaitTime=6 then 'high CPU time: '||nTypedWaitTime
  when nbgets>100000 then 'high number of logical reads: ' ||nbgets END));
  dbms_output.put_line('Suggestions:');
  IF nExecutions>10000 THEN dbms_output.put_line('Could you please check if it is possible to decrease number of executions of the statement?'); 
  END IF;
  
  dbms_output.put_line('*********               SQL_ID: &&sql_id');
  dbms_output.put_line('*********      Program/Package: ' || vcSourceName || ' Line: ' || nSourceLine);
  dbms_output.put_line('*********              Request: ');
  dbms_output.put_line('*********               Author: ');
  dbms_output.put_line('********* Received e-mail date: ' ||
                       to_char(SYSDATE, 'dd-mm-yyyy'));
  dbms_output.put_line('*********      Resolution date: ' ||
                       to_char(SYSDATE, 'dd-mm-yyyy'));
  dbms_output.put_line('***********************************************************************************/');
  dbms_output.put(chr(10));
  dbms_output.put_line('/********************************OLD SQL*******************************************/');
  dbms_output.put(chr(10));

 
  dbms_output.put_line(chr(10));
  dbms_output.put_line('set lines 300');
  dbms_output.put_line(chr(10));
  --get bind data for the SQL
  FOR s IN (SELECT last_captured || CHR(10) ||
                   '--------------------------------' last_captured,
                   'var ' || substr(NAME, 2) || ' ' || (CASE
                     WHEN datatype_string LIKE 'VARCHAR%' THEN
                      'VARCHAR2(50)'
                     ELSE
                      datatype_string
                   END) || ';' || CHR(10) || 'exec ' || NAME || ' := ''' ||
                   value_string || ''';' decl
              FROM (SELECT b.last_captured,
                           b.position,
                           decode(NAME, ':1', ':B' || rownum, NAME) NAME,
                           decode(value_string, 'NULL', NULL, value_string) value_string,
                           datatype_string
                      FROM v$sql_bind_capture b
                     WHERE b.sql_id = '&&sql_id'
                       AND last_captured > SYSDATE - 12 / 24
                     ORDER BY last_captured, position))
  LOOP
--    dbms_output.put_line(replace(replace(s.decl,'''',''''''),chr(10), ' '));
    dbms_output.put_line(s.decl);
  END LOOP;
  dbms_output.put_line(chr(10));

  --get sql text
  SELECT dbms_lob.substr(sql_fulltext, 4000, 1)
    INTO vcSqlText
    FROM v$sql
   WHERE sql_id = '&&sql_id'
     AND rownum = 1;

  p(vcSqlText);
  dbms_output.put_line(';');


  dbms_output.put_line(chr(10));

  dbms_output.put_line('/********************************OLD SQL*******************************************/');

  dbms_output.put_line('/********************************OLD Metrics***************************************/');
  --write statement to output the plan  
  dbms_output.put_line('SELECT * FROM table(dbms_xplan.display_cursor(NULL, NULL ,''RUNSTATS_LAST''));');
  dbms_output.put_line(chr(10));
  dbms_output.put_line('/*');
  IF vcOldSqlId IS NOT NULL
  THEN
    -- print metrics of the reproduced version of the old SQL
    FOR s IN (SELECT *
                FROM TABLE(DBMS_XPLAN.display_cursor(vcOldSqlId, NULL, 'RUNSTATS_LAST')))
    LOOP
      dbms_output.put_line(s.plan_table_output);
    END LOOP;
  END IF;  
  dbms_output.put_line('');  
  dbms_output.put_line('*/');
  dbms_output.put_line('/********************************OLD Metrics***************************************/');

  dbms_output.put_line('/********************************New SQL*******************************************/');
  IF vcNewSqlId IS NOT NULL
  THEN
    --get sql text
    SELECT dbms_lob.substr(sql_fulltext, 4000, 1) || ';'
      INTO vcSqlText
      FROM v$sql
     WHERE sql_id = vcNewSqlId
       AND rownum = 1;
  END IF;
--  dbms_output.put_line(vcSqlText);
  p(vcSqlText);

  dbms_output.put_line('');
  dbms_output.put_line('/********************************New SQL*******************************************/');
  dbms_output.put_line('/********************************New Metrics***************************************/');
  dbms_output.put_line('/*');
  IF vcNewSqlId IS NOT NULL
  THEN
    -- print metrics of the proposed version of the old SQL
    FOR s IN (SELECT *
                FROM TABLE(DBMS_XPLAN.display_cursor(vcNewSqlId, NULL, 'RUNSTATS_LAST')))
    LOOP
      dbms_output.put_line(s.plan_table_output);
    END LOOP;
  END IF;
  dbms_output.put_line('');  
  dbms_output.put_line('*/');
  dbms_output.put_line('/********************************New Metrics***************************************/');
  dbms_output.put_line('/********************************Index statistics**********************************/');
  dbms_output.put_line('/*');
  dbms_output.put_line('*/');
  dbms_output.put_line('/********************************Index statistics**********************************/');
  dbms_output.put_line('/********************************Other SQLs****************************************/');
  dbms_output.put_line('/*');
  dbms_output.put_line('*/ ');
  dbms_output.put_line('/********************************Other SQLs****************************************/');
END;
/
SET serverout OFF;
/*
**********************************************************************
**
**   File: opt_pack_sql_awr.sql                                                         
**   $Date: 2014/07/07 06:40:22 $                                                                     
**   $Revision: 1.3 $                                                                 
**   Description: Get everything necessary for creation of an optimization file: get binds, get SQL and output all as an optimization file. Final goal is to automate creation of an optimization file.
**
**********************************************************************
*/

SET serverout ON
set lines 300
DECLARE
  vcSqlText    VARCHAR2(4000);
  vcHostName   VARCHAR2(100);
  vcSourceName VARCHAR2(100);
  nSourceLine NUMBER;
  vcModule VARCHAR2(40);
  vcTypeWait VARCHAR2(30);
  nElapsedTime NUMBER;
  nTypedWaitTime NUMBER;
  nTypeWaitTime NUMBER;
  nbgets NUMBER;
  nExecutions NUMBER;  
  nPlanHash NUMBER;  
  nReads NUMBER;
  nRows NUMBER;
  nSnapMin NUMBER:=to_number('&begin_snap');
  nSnapMax NUMBER:=to_number('&end_snap');
  vcSqlId VARCHAR2(50):= '&sql_id';
  --SQL ID of the sql before optimization
  vcOldSqlId VARCHAR2(30) := '&old_sql_id';
  --SQL ID of the sql after optimization
  vcNewSqlId VARCHAR2(30) := '&new_sql_id';  
  --print function used for strings longer than 255 characters
  PROCEDURE p(p_string IN VARCHAR2) IS
    l_string LONG DEFAULT p_string;
  BEGIN
    LOOP
      EXIT WHEN l_string IS NULL;
      dbms_output.put_line(substr(l_string, 1, 250));
      l_string := substr(l_string, 251);
    END LOOP;
  END;
BEGIN
  --make output buffer large
  dbms_output.enable(NULL);
  SELECT instance_name||' '||host_name INTO vcHostName FROM v$instance; 
  SELECT instance_name||' - '||vcHostName INTO vcHostName FROM g_etude;
  --get min and max snapshots on the instance if user has not entered some
  IF nSnapMin IS NULL THEN
    SELECT MIN(snap_id)
      INTO nSnapMin
      FROM dba_hist_snapshot;      
  END IF;
  IF nSnapMax IS NULL THEN
    SELECT MAX(snap_id)
      INTO nSnapMax
      FROM dba_hist_snapshot;      
  END IF;
  
--get SQL details
  SELECT MODULE, elapsed, EXEC, wt, max_wait, gets, pl, sreads, sROWS
    INTO vcModule,
         nElapsedTime,       
         nExecutions,
         nTypedWaitTime,
         nTypeWaitTime,
         nbgets,         
         nPlanHash,
         nReads,
         nRows                    
    FROM (
          SELECT --s.sql_id,
                 min(substr(s.module,1,12)) module,
                 round(sum(s.elapsed_time_delta)/1000000,2) elapsed,
                 sum(s.executions_delta) EXEC,            
                 round(greatest(sum(s.apwait_delta), sum(s.ccwait_delta), sum(s.clwait_delta), sum(s.iowait_delta), sum(s.plsexec_time_delta), sum(s.javexec_time_delta), sum(s.cpu_time_delta))) wt,
                 CASE greatest(sum(s.apwait_delta), sum(s.ccwait_delta), sum(s.clwait_delta), sum(s.iowait_delta), sum(s.plsexec_time_delta), sum(s.javexec_time_delta), sum(s.cpu_time_delta)) 
             WHEN sum(s.apwait_delta) THEN
              0
             WHEN sum(s.ccwait_delta) THEN
              1
             WHEN sum(s.clwait_delta) THEN
              2
             WHEN sum(s.iowait_delta) THEN
              3
             WHEN sum(s.plsexec_time_delta) THEN
              4
             WHEN sum(s.javexec_time_delta) THEN
              5
             WHEN sum(s.cpu_time_delta) THEN
              6
                 END max_wait,
                  sum(s.buffer_gets_delta) gets,
                min(s.plan_hash_value) pl,                  
                  sum(s.disk_reads_delta) sreads,
                  sum(s.rows_processed_delta) sROWS
/*                  round(sum(s.elapsed_time_delta)/1000000/greatest(sum(s.executions_delta),1),2) "ELAP/EXEC",
                  round(sum(s.buffer_gets_delta)/greatest(sum(s.executions_delta),1), 2) "GETS/EXEC",
                  round(sum(s.disk_reads_delta)/greatest(sum(s.executions_delta),1), 2) "READS/EXEC",
                  round(sum(s.rows_processed_delta)/greatest(sum(s.executions_delta),1), 2) "ROWS/EXEC",
    */
             FROM dba_hist_sqlstat s, dba_hist_sqltext t
            WHERE t.sql_id = s.sql_id
              AND s.snap_id BETWEEN nSnapMin AND nSnapMax
              AND s.sql_id = vcSqlId
            GROUP BY s.sql_id
                      )
   WHERE rownum <= 1;
  dbms_output.put_line('/********************************************************************************');
  dbms_output.put_line('*********       E-mail subject: ');
  dbms_output.put_line('*********             Instance: ' || vcHostName);
  dbms_output.put_line('*********          Description: ');
  dbms_output.put_line('Problem: ');
  dbms_output.put_line('Slowness has been experienced in '|| vcModule||' module.');
  dbms_output.put_line('Analysis:');
  dbms_output.put_line('SQL '||vcSqlId||' from '||vcSourceName||' is one of the top statements in '||vcModule ||' module.');
  dbms_output.put_line('Execution of SQL '||vcSqlId||' is problematic due to its '
  ||(case when nExecutions>10000 then 'high number of executions: '|| nEXECUTIONS
  when nTypeWaitTime=3 then 'high IO wait time: '||nTypedWaitTime
  when nTypeWaitTime=6 then 'high CPU time: '||nTypedWaitTime
  when nbgets>100000 then 'high number of logical reads: ' ||nbgets END));
  dbms_output.put_line('Suggestions:');
  IF nExecutions>10000 THEN dbms_output.put_line('Could you please check if it is possible to decrease number of executions of the statement?'); 
  END IF;
  
  dbms_output.put_line('*********               SQL_ID: '||vcSqlId);
  dbms_output.put_line('*********      Program/Package: ' || vcSourceName || ' Line: ' || nSourceLine);
  dbms_output.put_line('*********              Request: ');
  dbms_output.put_line('*********               Author: ');
  dbms_output.put_line('********* Received e-mail date: ' ||
                       to_char(SYSDATE, 'dd-mm-yyyy'));
  dbms_output.put_line('*********      Resolution date: ' ||
                       to_char(SYSDATE, 'dd-mm-yyyy'));
  dbms_output.put_line('***********************************************************************************/');
  dbms_output.put(chr(10));
  dbms_output.put_line('/********************************OLD SQL*******************************************/');
  dbms_output.put(chr(10));

 
  dbms_output.put_line(chr(10));
  dbms_output.put_line('set lines 300');
  dbms_output.put_line(chr(10));
  --get bind data for the SQL
  FOR s IN (
SELECT snap_id||', '||begin_interval_time||CHR(10)||'--------------------------------' snap_info,
       'var '||substr(name,2)||' '||datatype_string||';'||CHR(10)||
       'exec '||name||' := '''||value_string||''';' decl
  FROM (
        SELECT s.snap_id,
               s.begin_interval_time,
               b.position,
               decode(name,':1',':B'||rownum, name) name,
               decode(value_string,'NULL',null,value_string) value_string,
               datatype_string
          FROM dba_hist_sqlbind b, dba_hist_snapshot s
         WHERE b.sql_id = vcSqlId
           AND b.snap_id = s.snap_id
           AND s.snap_id BETWEEN nSnapMin AND nSnapMax           
         ORDER BY snap_id, position
       )
 WHERE ROWNUM < 100
                     )
  LOOP
--    dbms_output.put_line(replace(replace(s.decl,'''',''''''),chr(10), ' '));
    dbms_output.put_line(s.snap_info);
    dbms_output.put_line(s.decl);
  END LOOP;
  dbms_output.put_line(chr(10));

  --get sql text
  select dbms_lob.substr(sql_text,4000,1) 
    INTO vcSqlText
    from dba_hist_sqltext
   where sql_id = vcSqlId
     AND rownum = 1;   

  p(vcSqlText);
  dbms_output.put_line(';');

  dbms_output.put_line(chr(10));

  dbms_output.put_line('/********************************OLD SQL*******************************************/');

  dbms_output.put_line('/********************************OLD Metrics***************************************/');
  --write statement ot output the plan  
  dbms_output.put_line('SELECT * FROM table(dbms_xplan.display_cursor(NULL, NULL ,''RUNSTATS_LAST''));');
  dbms_output.put_line(chr(10));

  dbms_output.put_line('/*');
  dbms_output.put_line(chr(10));
  --write awr metrics for the SQL
  dbms_output.put_line('AWR Metrics:');  
  dbms_output.put_line(
  'SQL_ID        MODULE             ELAPSED     MAX_WAIT         GETS      READS       ROWS    ELAP/EXEC    GETS/EXEC READS/EXEC  ROWS/EXEC      EXEC PLAN_HASH_VALUE');
  dbms_output.put_line(
  '------------- --------------- ---------- ------------ ------------ ---------- ---------- ------------ ------------ ---------- ---------- --------- ---------------'
  );
  dbms_output.put_line(
  vcSqlId||' '||rpad(vcModule,15)||' '||lpad(nElapsedTime,10)||' '||lpad(nTypedWaitTime,12)||' '|| lpad(nbgets,12)||' '||lpad(nReads,10)||' '||lpad(nRows,10)||' '
  ||lpad(round(nElapsedTime/greatest(nExecutions,1),2),12)||' '||lpad(round(nbgets/greatest(nExecutions,1),2),12)
  ||' '||lpad(round(nReads/greatest(nExecutions,1),2),10)||' '
  ||lpad(round(nRows/greatest(nExecutions,1),2),10)||' '||lpad(nExecutions,10)||' '||nPlanHash
  );
  dbms_output.put_line('');
  
  IF vcOldSqlId IS NOT NULL
  THEN
    -- print metrics of the reproduced version of the old SQL
    FOR s IN (SELECT *
                FROM TABLE(DBMS_XPLAN.display_cursor(vcOldSqlId, NULL, 'RUNSTATS_LAST')))
    LOOP
      dbms_output.put_line(s.plan_table_output);
    END LOOP;
  END IF;  
  dbms_output.put_line('');  
  dbms_output.put_line('*/');
  dbms_output.put_line('/********************************OLD Metrics***************************************/');

  dbms_output.put_line('/********************************New SQL*******************************************/');
  IF vcNewSqlId IS NOT NULL
  THEN
    --get sql text
    SELECT dbms_lob.substr(sql_fulltext, 4000, 1)
      INTO vcSqlText
      FROM v$sql
     WHERE sql_id = vcNewSqlId
       AND rownum = 1;
  END IF;
--  dbms_output.put_line(vcSqlText);
  p(vcSqlText);
  dbms_output.put_line(';');

  dbms_output.put_line('');
  dbms_output.put_line('/********************************New SQL*******************************************/');
  dbms_output.put_line('/********************************New Metrics***************************************/');
  dbms_output.put_line('/*');
  IF vcNewSqlId IS NOT NULL
  THEN
    -- print metrics of the proposed version of the old SQL
    FOR s IN (SELECT *
                FROM TABLE(DBMS_XPLAN.display_cursor(vcNewSqlId, NULL, 'RUNSTATS_LAST')))
    LOOP
      dbms_output.put_line(s.plan_table_output);
    END LOOP;
  END IF;
  dbms_output.put_line('');  
  dbms_output.put_line('*/');
  dbms_output.put_line('/********************************New Metrics***************************************/');
  dbms_output.put_line('/********************************Index statistics**********************************/');
  dbms_output.put_line('/*');
  dbms_output.put_line('*/');
  dbms_output.put_line('/********************************Index statistics**********************************/');
  dbms_output.put_line('/********************************Other SQLs****************************************/');
  dbms_output.put_line('/*');
  dbms_output.put_line('*/ ');
  dbms_output.put_line('/********************************Other SQLs****************************************/');
END;
/
SET serverout OFF;
/*
**********************************************************************
**
**   File: par_changes.sql                                                         
**   $Date: 2014/07/07 06:40:22 $                                                                     
**   $Revision: 1.3 $                                                                 
**   Description: Shows all parameters (including hidden) that have been modified. It uses AWR data.
**
**********************************************************************
*/
-- parm_mods.sql
--
-- Shows all parameters (including hidden) that have been modified.
-- Uses the lag function so that a single record is returned for each change.
-- It uses AWR data - so only snapshots still in the database will be included.
--
-- The script prompts for a parameter name (which can be wild carded).
-- Leaving the parameter name blank matches any parameter (i.e. it will show all changes).
-- Calculated hidden parameters (those that start with two underscores like "__shared_pool_size")
-- will not be displayed unless requested with a Y.
--
-- Kerry Osborne
--
-- Note: I got this idea from Jeff White.
--
col time for a15
col parameter_name format a50
col old_value format a30
col new_value format a30
break on instance skip 3
select instance_number instance, snap_id, time, parameter_name, old_value, new_value from (
select a.snap_id,to_char(end_interval_time,'DD-MON-YY HH24:MI') TIME, a.instance_number, parameter_name, value new_value,
lag(parameter_name,1) over (partition by parameter_name, a.instance_number order by a.snap_id) old_pname,
lag(value,1) over (partition by parameter_name, a.instance_number order by a.snap_id) old_value ,
decode(substr(parameter_name,1,2),'__',2,1) calc_flag
from dba_hist_parameter a, dba_Hist_snapshot b , v$instance v
where a.snap_id=b.snap_id
and a.instance_number=b.instance_number
and parameter_name like nvl('&parameter_name',parameter_name)
and a.instance_number like nvl('&instance_number',v.instance_number)
)
where
new_value != old_value
and calc_flag not in (decode('&show_calculated','Y',3,2))
order by 1,2
/
/*
**********************************************************************
**
**   File: ses_event.sql                                                         
**   $Date: 2014/07/07 06:40:22 $                                                                     
**   $Revision: 1.3 $                                                                 
**   Description: List session wait events and CPU usage. It could work on a group of sessions defined by their module.
**
**********************************************************************
*/

SELECT trunc(t.time_waited/SUM(t.time_waited) over()*100) perc, t.*
  FROM (
        SELECT ev.event, sum(total_waits) total_waits, sum(total_timeouts) total_timeouts,
               sum(time_waited) time_waited, sum(average_wait) average_wait, sum(max_wait) max_wait
          FROM v$session_event ev, v$session s
         WHERE s.sid = nvl('&&sid', userenv('sid'))
         	 AND ev.sid = s.sid
         GROUP BY ev.event
         UNION ALL
        SELECT n.name, null, null, sum(st.value), null, null
          FROM v$sesstat st, v$statname n, v$session s
         WHERE s.sid = nvl('&&sid', userenv('sid')) 
           AND st.sid = s.sid
           AND st.statistic# = n.statistic#
           AND n.name = 'CPU used by this session'
         GROUP BY n.name
       ) t
 ORDER BY t.time_waited DESC
;/*
**********************************************************************
**
**   File: ses_info.sql                                                         
**   $Date: 2014/07/07 06:40:22 $                                                                     
**   $Revision: 1.3 $                                                                 
**   Description: List sessions info from v$session and v$process. The sessions could be filtered out by several criteria.
**
**********************************************************************
*/

undef module
undef pid
undef spid
col sid format 999999
col serial# format 999999
col status format a7
col event format a30
col pid format a10
col spid format a10
col module format a20
col logon_time format a10
col client_id format a10
col client_info format a11
col sql_trace format a9

SELECT s.sid,                                   
       s.serial#,                               
       case
         when s.process = '1234' and (s.module = 'JDBC Thin Client' or s.module is null)
         then nvl(substr(s.client_info,1,instr(s.client_info,'@')-1),s.process)
         else s.process 
       end pid,
       p.spid,
       nvl(substr(s.module,1,instr(s.module,'@')-1),s.module) module,
       replace(s.status,'INACTIVE','') status,
       s.sql_id,
       s.event,
       s.client_identifier client_id,
       case when s.program like 'frmweb%' then s.client_info end client_info,
       case 
         when trunc(s.logon_time) = trunc(sysdate) 
         then to_char(s.logon_time, 'hh24:mi:ss')
         else to_char(s.logon_time, 'dd/mm/yy')
       end logon_time
  FROM v$session s, v$process p                 
 WHERE s.type != 'BACKGROUND'             
   AND p.addr = s.paddr
   AND (
         '&&module' is null 
         	OR 
         	upper(s.module) LIKE upper('%&module%') ESCAPE '\' 
         	OR 
         	upper(s.program) LIKE upper('%&module%') ESCAPE '\'
       )
   AND ('&&pid' is null OR s.process = '&pid')
   AND ('&&sid' is null OR s.sid = '&sid')
   AND ('&&spid' is null OR p.spid = '&spid')
 ORDER BY s.status, s.module                              
;

undef module
undef pid
undef spid/*
**********************************************************************
**
**   File: ses_kill.sql                                                         
**   $Date: 2014/07/07 06:40:22 $                                                                     
**   $Revision: 1.3 $                                                                 
**   Description: Kill a session identified by (sid, serial#)
**
**********************************************************************
*/

undef sid
undef serial#
ALTER SYSTEM KILL SESSION '&sid,&serial';/*
**********************************************************************
**
**   File: ses_longops.sql                                                         
**   $Date: 2014/07/07 06:40:22 $                                                                     
**   $Revision: 1.3 $                                                                 
**   Description: Show session long operations from v$session_longops.
**
**********************************************************************
*/


select sql_id, message from v$session_longops where sid = '&&sid' and totalwork > sofar;/*
**********************************************************************
**
**   File: ses_stat.sql                                                         
**   $Date: 2014/07/07 06:40:22 $                                                                     
**   $Revision: 1.3 $                                                                 
**   Description: Show session statistics from v$sesstat ordered by statistic name. The output could be filtered by statistic name.
**
**********************************************************************
*/

undef module

SELECT ses.module, count(ses.sid) sessions, n.name, sum(s.value) VALUE
  FROM v$sesstat s, v$statname n, v$session ses
 WHERE ('&&module' is null OR upper(ses.module) LIKE upper('%&module%') ESCAPE '\')
   AND ('&&sid' is null OR s.sid = '&sid')
   AND ses.sid = s.sid
   AND upper(n.name) like upper('%&stat_name%')
   AND s.statistic# = n.statistic#
   AND s.value != 0
 GROUP BY ses.module, n.name
 ORDER BY sum(s.value) desc
;

undef module/*
**********************************************************************
**
**   File: ses_stat.sql                                                         
**   $Date: 2014/07/07 06:40:22 $                                                                     
**   $Revision: 1.3 $                                                                 
**   Description: Show session time distribution from v$sess_time_model. The output is formatted as per the parent-child relationships and ordered by elapsed time.
**
**********************************************************************
*/


select t.stat_name_prefix||t.stat_name stat_name, round(t.value/1000000) "time(s)", round(t.value/db_time.value*100) "perc(%)"
  from (
        select case stat_name
                when 'DB time'                                          then '1. '
                when 'DB CPU'                                           then ' 1.1. '
                when 'connection management call elapsed time'          then ' 1.2. '
                when 'sequence load elapsed time'                       then ' 1.3. '
                when 'sql execute elapsed time'                         then ' 1.4. '
                when 'parse time elapsed'                               then ' 1.5. '
                when 'hard parse elapsed time'                          then '  1.5.1. '
                when 'hard parse (sharing criteria) elapsed time'       then '   1.5.1.1. '
                when 'hard parse (bind mismatch) elapsed time'          then '    1.5.1.1.1. '
                when 'failed parse elapsed time'                        then '  1.5.2. '
                when 'failed parse (out of shared memory) elapsed time' then '   1.5.2.1. '
                when 'PL/SQL execution elapsed time'                    then ' 1.6. '
                when 'inbound PL/SQL rpc elapsed time'                  then ' 1.7. '
                when 'PL/SQL compilation elapsed time'                  then ' 1.8. '
                when 'Java execution elapsed time'                      then ' 1.9. '
                when 'repeated bind elapsed time'                       then ' 1.9. '
                when 'background elapsed time'                          then '2. '
                when 'background cpu time'                              then ' 2.1. '
                when 'RMAN cpu time (backup/restore)'                   then '  2.1.1. '
               end stat_name_prefix,
               stat_name,
               value
          from v$sess_time_model 
         where sid = nvl('&&sid', userenv('sid'))
       ) t,
       (
         select value
           from v$sess_time_model 
          where sid = nvl('&&sid', userenv('sid'))
            and stat_name = 'DB time'
       ) db_time
 where round(t.value/1000000) > 0
 order by t.value desc;/*
**********************************************************************
**
**   File: ses_undef.sql                                                         
**   $Date: 2014/07/07 06:40:22 $                                                                     
**   $Revision: 1.3 $                                                                 
**   Description: Undefine session id (SID) defined previously via "@@".
**
**********************************************************************
*/

undef sid/*
**********************************************************************
**
**   File: sql_awr_binds.sql                                                         
**   $Date: 2014/07/07 06:40:22 $                                                                     
**   $Revision: 1.3 $                                                                 
**   Description: Dump SQL AWR bind variables declarations for the last N days.
**
**********************************************************************
*/

column snap_info format a179
break on snap_info
SELECT snap_id||', '||begin_interval_time||CHR(10)||'--------------------------------' snap_info,
       'var '||substr(name,2)||' '||replace(datatype_string,'2000','1333')||';'||CHR(10)||
       'exec '||name||' := '''||value_string||''';' decl
  FROM (
        SELECT distinct
        			 s.snap_id,
               s.begin_interval_time,
               decode(name,':1',':B'||rownum, name) name,
               decode(value_string,'NULL',null,value_string) value_string,
               datatype_string
          FROM dba_hist_sqlbind b, dba_hist_snapshot s
         WHERE b.sql_id = '&&sql_id'
           AND b.snap_id = s.snap_id
           AND s.begin_interval_time >= trunc(sysdate) - to_number(nvl('&num_days','0'))
         ORDER BY snap_id, name
       )
 WHERE ROWNUM < 100
;/*
**********************************************************************
**
**   File: sql_awr_id.sql                                                         
**   $Date: 2014/07/07 06:40:22 $                                                                     
**   $Revision: 1.3 $                                                                 
**   Description: Display all cursors from dba_hist_sqltext that match the search criteria (sql_text).
**
**********************************************************************
*/

column sql_text format a165
select sql_id, sql_text
  from dba_hist_sqltext
 where upper(sql_text) like upper('%&sql_text%')
;/*
**********************************************************************
**
**   File: sql_awr_info.sql                                                         
**   $Date: 2014/07/07 06:40:22 $                                                                     
**   $Revision: 1.3 $                                                                 
**   Description: List cursors info from dba_hist_sqlstat by several criteria (sql_id, module, text).
**
**********************************************************************
*/

var nSnapMin NUMBER;
var nSnapMax NUMBER;

BEGIN
  SELECT MIN(snap_id), MAX(snap_id)
    INTO :nSnapMin, :nSnapMax
    FROM dba_hist_snapshot
  ;
END;
/

undef snapshot1
undef snapshot2
undef module
undef sql_text
col module format a13
col max_wait format a9

SELECT *
  FROM (
        SELECT s.sql_id,
               substr(s.module,1,12) module,
               round(sum(s.elapsed_time_delta)/1000000,2) elapsed,
               round(greatest(sum(s.apwait_delta), sum(s.ccwait_delta), sum(s.clwait_delta), sum(s.iowait_delta), sum(s.plsexec_time_delta), sum(s.javexec_time_delta), sum(s.cpu_time_delta))/sum(s.elapsed_time_delta)*100)||'% '||
               CASE greatest(sum(s.apwait_delta), sum(s.ccwait_delta), sum(s.clwait_delta), sum(s.iowait_delta), sum(s.plsexec_time_delta), sum(s.javexec_time_delta), sum(s.cpu_time_delta))
                 WHEN sum(s.apwait_delta) THEN 'app'
                 WHEN sum(s.ccwait_delta) THEN 'conc'
                 WHEN sum(s.clwait_delta) THEN 'clust'
                 WHEN sum(s.iowait_delta) THEN 'io'
                 WHEN sum(s.plsexec_time_delta) THEN 'plsql'
                 WHEN sum(s.javexec_time_delta) THEN 'java'
                 WHEN sum(s.cpu_time_delta) THEN 'cpu'
               END max_wait,
                sum(s.buffer_gets_delta) gets,
                sum(s.disk_reads_delta) reads,
                sum(s.rows_processed_delta) "ROWS",
                round(sum(s.elapsed_time_delta)/1000000/greatest(sum(s.executions_delta),1),2) "ELAP/EXEC",
                round(sum(s.buffer_gets_delta)/greatest(sum(s.executions_delta),1), 2) "GETS/EXEC",
                round(sum(s.disk_reads_delta)/greatest(sum(s.executions_delta),1), 2) "READS/EXEC",
                round(sum(s.rows_processed_delta)/greatest(sum(s.executions_delta),1), 2) "ROWS/EXEC",
                sum(s.executions_delta) EXEC,
                s.plan_hash_value
           FROM dba_hist_sqlstat s, dba_hist_sqltext t
          WHERE t.sql_id = s.sql_id
            AND s.snap_id BETWEEN decode('&&snapshot1', NULL, :nSnapMin, '&snapshot1')
                              AND decode('&&snapshot2', NULL, :nSnapMax, '&snapshot2')
            AND ('&&sql_id' is null OR s.sql_id = '&sql_id')
            AND ('&&sql_text' is null OR upper(t.sql_text) LIKE upper('%&sql_text%') ESCAPE '\')
            AND ('&&module' is null OR upper(s.module) LIKE upper('%&module%') ESCAPE '\')
          GROUP BY s.sql_id, s.module, s.plan_hash_value
         HAVING sum(s.elapsed_time_delta) > 0
          ORDER BY sum(s.elapsed_time_delta) DESC
                    )
 WHERE rownum <= 10
;

undef snapshot1
undef snapshot2
undef module
undef sql_text/*
**********************************************************************
**
**   File: sql_awr_plans.sql                                                         
**   $Date: 2014/07/07 06:40:22 $                                                                     
**   $Revision: 1.3 $                                                                 
**   Description: Display all execution plans for a particular SQL in the workload repository.
**
**********************************************************************
*/

SELECT tf.*
  FROM dba_hist_sqltext ht,
  		 TABLE(dbms_xplan.display_awr(ht.sql_id,NULL,NULL, 'ALL')) tf
 WHERE ht.sql_id = '&sql_id'
;
/*
**********************************************************************
**
**   File: sql_awr_stats.sql                                                         
**   $Date: 2014/07/07 06:40:22 $                                                                     
**   $Revision: 1.3 $                                                                 
**   Description: Display SQL statistics based on AWR data. Support filtring and grouping by different criteria.
**
**********************************************************************
*/

undef module
undef sql_text
undef group_by
col module format a17
col sql_id format a19;
col max_wait format a9;
col period format a11;
col "ELAP/EXEC" format 9999999.99

column snap_id     format 99999990 heading 'Snap Id';
column snapdat     format a18  heading 'Snap Started' just c;
column startup_time format a18  heading 'Instance Startup';
column lvl         format 99   heading 'Snap|Level';
column begin_time format a20 new_value v_begin_time noprint;
column end_time format a20 new_value v_end_time noprint;

select to_char(s.startup_time,'dd Mon "at" HH24:mi:ss')  startup_time
		 , s.snap_id                                         snap_id
     , to_char(s.end_interval_time,'dd Mon YYYY HH24:mi') snapdat
  from dba_hist_snapshot s
 where trunc(s.end_interval_time) = trunc(sysdate) - to_number(nvl('&&days_back',0))
 order by s.startup_time, s.snap_id
/*1*/;

var v_begin_snap number;
var v_end_snap number;
var v_begin_time varchar2(20);
var v_end_time varchar2(20);

BEGIN
  SELECT nvl('&&begin_snap', MIN(snap_id)), nvl('&&end_snap', MAX(snap_id))
    INTO :v_begin_snap, :v_end_snap
    FROM dba_hist_snapshot
  ;
  SELECT to_char(end_interval_time,'dd Mon YYYY HH24:mi') into :v_begin_time from dba_hist_snapshot where snap_id = :v_begin_snap;
  SELECT to_char(end_interval_time,'dd Mon YYYY HH24:mi') into :v_end_time from dba_hist_snapshot where snap_id = :v_end_snap;
END;
/

TTITLE center "Analyzed from '" v_begin_time "' to '" v_end_time "'" SKIP 1 center ''

accept group_by varchar2(1) prompt 'Group by (s-snap, h-hour, d-date, w-week, n-null, default-plan): '

SELECT *
  FROM (
        SELECT replace(max(s.sql_id)||'('||count(DISTINCT s.sql_id)||')','(1)','') sql_id,
               replace(max(nvl(substr(s.module,1,instr(s.module,'@')-1),s.module))||'('||greatest(COUNT(DISTINCT MODULE),1)||')','(1)','') module,
               round(sum(s.elapsed_time_delta)/1000000) elapsed,
               round(greatest(sum(s.apwait_delta), sum(s.ccwait_delta), sum(s.clwait_delta), sum(s.iowait_delta), sum(s.plsexec_time_delta), sum(s.javexec_time_delta), sum(s.cpu_time_delta))/sum(s.elapsed_time_delta)*100)||'% '||
               CASE greatest(sum(s.apwait_delta), sum(s.ccwait_delta), sum(s.clwait_delta), sum(s.iowait_delta), sum(s.plsexec_time_delta), sum(s.javexec_time_delta), sum(s.cpu_time_delta))
                 WHEN sum(s.apwait_delta) THEN 'app'
                 WHEN sum(s.ccwait_delta) THEN 'conc'
                 WHEN sum(s.clwait_delta) THEN 'clust'
                 WHEN sum(s.iowait_delta) THEN 'io'
                 WHEN sum(s.plsexec_time_delta) THEN 'plsql'
                 WHEN sum(s.javexec_time_delta) THEN 'java'
                 WHEN sum(s.cpu_time_delta) THEN 'cpu'
               END max_wait,
               sum(s.buffer_gets_delta) gets,
               sum(s.disk_reads_delta) reads,
               sum(s.rows_processed_delta) "ROWS",
               round(sum(s.elapsed_time_delta)/1000000/greatest(sum(s.executions_delta),1),2) "ELAP/EXEC",
               round(sum(s.buffer_gets_delta)/greatest(sum(s.executions_delta),1)) "GETS/EXEC",
               round(sum(s.disk_reads_delta)/greatest(sum(s.executions_delta),1)) "READS/EXEC",
               round(sum(s.rows_processed_delta)/greatest(sum(s.executions_delta),1)) "ROWS/EXEC",
               sum(s.executions_delta) EXEC,
               min(s.plan_hash_value) plan_hash_value,
               :v_begin_time begin_time,
               :v_end_time end_time,
        			 decode('&&group_by',
                 's', to_char(snap.snap_id),
                 'h', to_char(snap.begin_interval_time,'hh24:mi'),
                 'd', to_char(snap.begin_interval_time,'yyyy/mm/dd'),
                 'w', to_char(snap.begin_interval_time,'ww')
               ) period
           FROM dba_hist_sqlstat s, dba_hist_sqltext t, dba_hist_snapshot snap
          WHERE t.sql_id = s.sql_id
            AND s.snap_id BETWEEN :v_begin_snap AND :v_end_snap
            AND ('&&sql_id' is null OR s.sql_id = '&sql_id')
            AND ('&&sql_text' is null OR upper(t.sql_text) LIKE upper('%&sql_text%') ESCAPE '\')
            AND ('&&module' is null OR upper(s.module) LIKE upper('%&module%') ESCAPE '\')
            AND snap.snap_id = s.snap_id
          GROUP BY decode('&group_by',
                     's', to_char(snap.snap_id),
                     'h', to_char(snap.begin_interval_time,'hh24:mi'),
                     'd', to_char(snap.begin_interval_time,'yyyy/mm/dd'),
                     'w', to_char(snap.begin_interval_time,'ww'),
                     'n', null,
                     decode(s.plan_hash_value, 0, s.sql_id, 1546270724, s.sql_id, s.plan_hash_value)
                   ),
                   decode('&group_by',
		                 's', to_char(snap.snap_id),
		                 'h', to_char(snap.begin_interval_time,'hh24:mi'),
		                 'd', to_char(snap.begin_interval_time,'yyyy/mm/dd'),
		                 'w', to_char(snap.begin_interval_time,'ww')
		               )
         HAVING sum(s.elapsed_time_delta) > 0
          ORDER BY decode('&group_by', '', sum(s.elapsed_time_delta), MAX(s.snap_id)) desc
        )
 WHERE rownum <= 30
;

undef module
undef sql_text
undef group_by
ttitle off/*
**********************************************************************
**
**   File: sql_awr_text.sql                                                         
**   $Date: 2014/07/07 06:40:22 $                                                                     
**   $Revision: 1.3 $                                                                 
**   Description: Display the AWR text of a particular SQL.
**
**********************************************************************
*/

set head off

select dbms_lob.substr(sql_text,4000,1),
       dbms_lob.substr(sql_text,4000,4001),
       dbms_lob.substr(sql_text,4000,8001),
       dbms_lob.substr(sql_text,4000,12001),
       upper('sql_text_end')
  from dba_hist_sqltext
 where sql_id = '&&sql_id' 
;

set head on/*
**********************************************************************
**
**   File: sql_undef.sql                                                         
**   $Date: 2014/07/07 06:40:22 $                                                                     
**   $Revision: 1.3 $                                                                 
**   Description: Undefine sql_id defined previously via "@@".
**
**********************************************************************
*/

undef sql_id
undef begin_snap
undef end_snap
undef days_back/*
**********************************************************************
**
**   File: sql_binds.sql                                                         
**   $Date: 2014/07/07 06:40:22 $                                                                     
**   $Revision: 1.3 $                                                                 
**   Description: Dump SQL shared pool bind variables declarations for the last 12 hours.
**
**********************************************************************
*/

column last_captured format a179
break on last_captured
alter session set NLS_DATE_FORMAT='yyyy/mm/dd hh24:mi:ss';
SELECT last_captured||CHR(10)||'--------------------------------' last_captured,
       'var '||substr(name,2)||' '||datatype_string||';'||CHR(10)||
       'exec '||name||' := '''||value_string||''';' decl
  FROM (
        SELECT b.last_captured,
               b.position,
               decode(name,':1',':B'||rownum, name) name,
               decode(value_string,'NULL',null,value_string) value_string,
               datatype_string
          FROM v$sql_bind_capture b
         WHERE b.sql_id = '&&sql_id'
           AND last_captured > SYSDATE - 12/24
         ORDER BY last_captured, position
       )
;/*
**********************************************************************
**
**   File: sql_id.sql                                                         
**   $Date: 2014/07/07 06:40:22 $                                                                     
**   $Revision: 1.3 $                                                                 
**   Description: Display all cursors from v$sql that match the search criteria (sql_text).
**
**********************************************************************
*/

column sql_text format a165
select distinct sql_id, sql_text 
  from v$sql 
 where upper(sql_text) like upper('%&sql_text%')
;/*
**********************************************************************
**
**   File: sql_info.sql                                                         
**   $Date: 2014/07/07 06:40:22 $                                                                     
**   $Revision: 1.3 $                                                                 
**   Description: List cursors info from v$sql by several criteria (sql_id, module, text).
**
**********************************************************************
*/

undef module
undef sql_text
col module format a13
col "sql_id(child#)" format a17
col command format a7
col max_wait format a9
SELECT * 
  FROM (
				SELECT s.sql_id||'('||s.child_number||')' "sql_id(child#)",
				       substr(s.module,1,12) module,
				       round(s.elapsed_time/1000000,2) elapsed_time,
				       round(greatest(application_wait_time, concurrency_wait_time, cluster_wait_time, user_io_wait_time, plsql_exec_time, java_exec_time, cpu_time)/elapsed_time*100)||'% '||
               CASE greatest(application_wait_time, concurrency_wait_time, cluster_wait_time, user_io_wait_time, plsql_exec_time, java_exec_time, cpu_time)
                 WHEN application_wait_time THEN 'app'
                 WHEN concurrency_wait_time THEN 'conc'
                 WHEN cluster_wait_time THEN 'clust'
                 WHEN user_io_wait_time THEN 'io'
                 WHEN plsql_exec_time THEN 'plsql'
                 WHEN java_exec_time THEN 'java'
                 WHEN cpu_time THEN 'cpu'
               END max_wait,
               s.buffer_gets,
				       s.disk_reads,
				       s.rows_processed,
				       round(elapsed_time/1000000/greatest(executions,1),2) "elap/exec",
				       round(buffer_gets/greatest(executions,1), 2) "gets/exec",
				       round(disk_reads/greatest(executions,1), 2) "reads/exec",
				       round(rows_processed/greatest(executions,1), 2) "rows/exec",
				       s.executions,
				       s.plan_hash_value
				  FROM v$sql s
				 WHERE ('&&sql_id' is null OR sql_id = '&sql_id')
				   AND ('&&sql_text' is null OR upper(s.sql_text) LIKE upper('%&sql_text%') ESCAPE '\')
				   AND ('&&module' is null OR upper(s.module) LIKE upper('%&module%') ESCAPE '\')
				   AND s.elapsed_time > 0
				 ORDER BY s.elapsed_time DESC
			 )
 WHERE rownum <= 10
;

undef module
undef sql_text/*
**********************************************************************
**
**   File: sql_monitor.sql                                                         
**   $Date: 2014/07/07 06:40:22 $
**   $Revision: 1.3 $
**   Description: Show report generated by SQL Monitor (11g and beyond).
**
**********************************************************************
*/
set long 100000
SELECT dbms_sqltune.report_sql_monitor(sql_id => '&&sql_id') FROM dual;/*
**********************************************************************
**
**   File: sql_plan.sql                                                         
**   $Date: 2014/07/07 06:40:22 $                                                                     
**   $Revision: 1.3 $                                                                 
**   Description: Display the cursor cache execution plan for a particular SQL. By default it displays the RUNSTATS of the last executed SQL.
**
**********************************************************************
*/

SELECT * FROM TABLE(DBMS_XPLAN.display_cursor(
  case 
    when '&prev' is null then null
    else '&sql_id'
  end,
  null,
  case 
    when '&mode' is null then 'RUNSTATS_LAST'
  	else 'ALL ALLSTATS LAST alias +PEEKED_BINDS +outline'
  end
));
/*
**********************************************************************
**
**   File: sql_stats.sql                                                         
**   $Date: 2014/07/07 06:40:22 $                                                                     
**   $Revision: 1.3 $                                                                 
**   Description: TODO
**
**********************************************************************
*/

undef module
undef sql_text
col module format a17
col sql_id format a19
col max_wait format a9
col "ELAP/EXEC" format 9999999.99

SELECT * 
  FROM (
				SELECT replace(max(s.sql_id)||'('||count(DISTINCT s.sql_id)||')','(1)','') sql_id,
				       replace(max(nvl(substr(s.module,1,instr(s.module,'@')-1),s.module))||'('||greatest(COUNT(DISTINCT MODULE),1)||')','(1)','') module,
				       round(sum(s.elapsed_time)/1000000) elapsed,
				       round(greatest(sum(application_wait_time), sum(concurrency_wait_time), sum(cluster_wait_time), sum(user_io_wait_time), sum(plsql_exec_time), sum(java_exec_time), sum(cpu_time))/sum(s.elapsed_time)*100)||'% '||
               CASE greatest(sum(application_wait_time), sum(concurrency_wait_time), sum(cluster_wait_time), sum(user_io_wait_time), sum(plsql_exec_time), sum(java_exec_time), sum(cpu_time))
                 WHEN sum(application_wait_time) THEN 'app'
                 WHEN sum(concurrency_wait_time) THEN 'conc'
                 WHEN sum(cluster_wait_time) THEN 'clust'
                 WHEN sum(user_io_wait_time) THEN 'io'
                 WHEN sum(plsql_exec_time) THEN 'plsql'
                 WHEN sum(java_exec_time) THEN 'java'
                 WHEN sum(cpu_time) THEN 'cpu'
               END max_wait,
               sum(s.buffer_gets) gets,
				       sum(s.disk_reads) reads,
				       sum(s.rows_processed) "ROWS",
				       round(sum(elapsed_time)/1000000/greatest(sum(executions),1),2) "ELAP/EXEC",
				       round(sum(buffer_gets)/greatest(sum(executions),1), 2) "GETS/EXEC",
				       round(sum(disk_reads)/greatest(sum(executions),1), 2) "READS/EXEC",
				       round(sum(rows_processed)/greatest(sum(executions),1), 2) "ROWS/EXEC",
				       sum(s.executions) EXEC,
               min(s.plan_hash_value) plan_hash_value
				  FROM v$sql s
				 WHERE ('&&sql_id' is null OR sql_id = '&sql_id')
				   AND ('&&sql_text' is null OR upper(s.sql_text) LIKE upper('%&sql_text%') ESCAPE '\')
				   AND ('&&module' is null OR upper(s.module) LIKE upper('%&module%') ESCAPE '\')
				 GROUP BY decode(s.plan_hash_value, 0, s.sql_id, s.plan_hash_value)
				HAVING sum(s.elapsed_time) > 0
				 ORDER BY sum(s.elapsed_time) DESC
			 )
 WHERE rownum <= 30
;

undef module
undef sql_text/*
**********************************************************************
**
**   File: sql_text.sql                                                         
**   $Date: 2014/07/07 06:40:22 $                                                                     
**   $Revision: 1.3 $                                                                 
**   Description: Show the sql_text of a particular cursor from v$sql.
**
**********************************************************************
*/

set head off

select dbms_lob.substr(sql_fulltext,4000,1),
       dbms_lob.substr(sql_fulltext,4000,4001),
       dbms_lob.substr(sql_fulltext,4000,8001),
       dbms_lob.substr(sql_fulltext,4000,12001),
       upper('sql_text_end')
  from v$sql 
 where sql_id = '&&sql_id' 
   and rownum = 1
;

set head on
/*
**********************************************************************
**
**   File: sql_undef.sql                                                         
**   $Date: 2014/07/07 06:40:22 $                                                                     
**   $Revision: 1.3 $                                                                 
**   Description: Undefine sql_id defined previously via "@@".
**
**********************************************************************
*/

undef sql_idset echo on

drop table test_kv_run_stats;
create global temporary table test_kv_run_stats 
( runid varchar2(15), 
  name varchar2(80), 
  value int )
on commit preserve rows;

/*
create or replace view test_kv_stats
as select 'STAT...' || a.name name, b.value
      from v$statname a, v$mystat b
     where a.statistic# = b.statistic#
    union all
    select 'LATCH.' || name,  gets
      from v$latch
	union all
	select 'STAT...Elapsed Time', hsecs from v$timer;
*/

delete from test_kv_run_stats;
commit;

create or replace package test_kv_runstats
as
    procedure rs_start;
    procedure rs_middle;
    procedure rs_stop( p_difference_threshold in number default 0 );
end;
/

create or replace package body test_kv_runstats
as

g_start number;
g_run1  number;
g_run2  number;

procedure rs_start
is 
begin
    delete from test_kv_run_stats;

    insert into test_kv_run_stats 
    select 'before', test_kv_stats.* from (
      select 'STAT...' || a.name name, b.value
        from v$statname a, v$mystat b
       where a.statistic# = b.statistic#
      union all
      select 'LATCH.' || name,  gets
        from v$latch
    	union all
    	select 'STAT...Elapsed Time', hsecs from v$timer) test_kv_stats;
        
    g_start := dbms_utility.get_cpu_time;
end;

procedure rs_middle
is
begin
    g_run1 := (dbms_utility.get_cpu_time-g_start);
 
    insert into test_kv_run_stats 
    select 'after 1', test_kv_stats.* from (
      select 'STAT...' || a.name name, b.value
        from v$statname a, v$mystat b
       where a.statistic# = b.statistic#
      union all
      select 'LATCH.' || name,  gets
        from v$latch
    	union all
    	select 'STAT...Elapsed Time', hsecs from v$timer) test_kv_stats;
    g_start := dbms_utility.get_cpu_time;

end;

procedure rs_stop(p_difference_threshold in number default 0)
is
begin
    g_run2 := (dbms_utility.get_cpu_time-g_start);

    dbms_output.put_line
    ( 'Run1 ran in ' || g_run1 || ' cpu hsecs' );
    dbms_output.put_line
    ( 'Run2 ran in ' || g_run2 || ' cpu hsecs' );
	if ( g_run2 <> 0 )
	then
    dbms_output.put_line
    ( 'run 1 ran in ' || round(g_run1/g_run2*100,2) || 
      '% of the time' );
	end if;
    dbms_output.put_line( chr(9) );

    insert into test_kv_run_stats 
    select 'after 2', test_kv_stats.* from (
      select 'STAT...' || a.name name, b.value
        from v$statname a, v$mystat b
       where a.statistic# = b.statistic#
      union all
      select 'LATCH.' || name,  gets
        from v$latch
    	union all
    	select 'STAT...Elapsed Time', hsecs from v$timer) test_kv_stats;

    dbms_output.put_line
    ( rpad( 'Name', 30 ) || lpad( 'Run1', 12 ) || 
      lpad( 'Run2', 12 ) || lpad( 'Diff', 12 ) );

    for x in 
    ( select rpad( a.name, 30 ) || 
             to_char( b.value-a.value, '999,999,999' ) || 
             to_char( c.value-b.value, '999,999,999' ) || 
             to_char( ( (c.value-b.value)-(b.value-a.value)), '999,999,999' ) data
        from test_kv_run_stats a, test_kv_run_stats b, test_kv_run_stats c
       where a.name = b.name
         and b.name = c.name
         and a.runid = 'before'
         and b.runid = 'after 1'
         and c.runid = 'after 2'
         -- and (c.value-a.value) > 0
         and abs( (c.value-b.value) - (b.value-a.value) ) 
               > p_difference_threshold
       order by abs( (c.value-b.value)-(b.value-a.value))
    ) loop
        dbms_output.put_line( x.data );
    end loop;

    dbms_output.put_line( chr(9) );
    dbms_output.put_line
    ( 'Run1 latches total versus runs -- difference and pct' );
    dbms_output.put_line
    ( lpad( 'Run1', 12 ) || lpad( 'Run2', 12 ) || 
      lpad( 'Diff', 12 ) || lpad( 'Pct', 10 ) );

    for x in 
    ( select to_char( run1, '999,999,999' ) ||
             to_char( run2, '999,999,999' ) ||
             to_char( diff, '999,999,999' ) ||
             to_char( round( run1/decode( run2, 0, to_number(0), run2) *100,2 ), '99,999.99' ) || '%' data
        from ( select sum(b.value-a.value) run1, sum(c.value-b.value) run2,
                      sum( (c.value-b.value)-(b.value-a.value)) diff
                 from test_kv_run_stats a, test_kv_run_stats b, test_kv_run_stats c
                where a.name = b.name
                  and b.name = c.name
                  and a.runid = 'before'
                  and b.runid = 'after 1'
                  and c.runid = 'after 2'
                  and a.name like 'LATCH%'
                )
    ) loop
        dbms_output.put_line( x.data );
    end loop;
end;

end;
/

/*
exec test_kv_runstats.rs_start;
exec test_kv_runstats.rs_middle;
exec test_kv_runstats.rs_stop;
*/
/*
**********************************************************************
**
**   File: sts_awr.sql                                                         
**   $Date: 2014/07/07 06:40:22 $                                                                     
**   $Revision: 1.3 $                                                                 
**   Description: Lists statistics from workload repository for sql statements.
**
**********************************************************************
*/

var nSnapMin NUMBER;
var nSnapMax NUMBER;

BEGIN
  SELECT MIN(snap_id), MAX(snap_id)
    INTO :nSnapMin, :nSnapMax
    FROM dba_hist_snapshot
  ;
END;
/
set lines 179 pages 999
col sql_id format a15
col MODULE format a30
undef snapshot1
undef snapshot2
SELECT substr(module,1,20) module,
       sql_id,
       round(elapsed_time / 1000000, 2) elapsed_time,
       round(cpu_time / 1000000, 2) cpu_time,
       buffer_gets,
       disk_reads, 
       round(elapsed_time / 1000000 / executions, 2) "elap/exec",
       round(cpu_time / 1000000 / executions, 2) "cpu/exec",
       round(buffer_gets / executions, 2) "buffer_gets/exec",
       round(disk_reads / executions, 2) "disk_reads/Exec",
       executions
  FROM TABLE(dbms_sqltune.select_workload_repository(
         decode('&&snapshot1', NULL, :nSnapMin, '&snapshot1'),
         decode('&&snapshot2', NULL, :nSnapMax, '&snapshot2'),
         'module like ''%''||''&module''||''%'' and sql_id like ''%''||''&sql_id''||''%'' and upper(sql_text) like upper(''%''||''&sql_text''||''%'')'
       ))          
 WHERE executions >= 1
 ORDER BY 3 DESC;
/*
**********************************************************************
**
**   File: sts_cc.sql                                                         
**   $Date: 2014/07/07 06:40:22 $                                                                     
**   $Revision: 1.3 $                                                                 
**   Description: Lists statistics from cursor cache for sql statements.
**
**********************************************************************
*/

set lines 179 pages 999
col sql_id format a15

col MODULE format a30
SELECT substr(module,1,20) module,
       sql_id,
       round(elapsed_time / 1000000, 2) elapsed_time,
       round(cpu_time / 1000000, 2) cpu_time,
       buffer_gets,
       disk_reads,
       round(elapsed_time / 1000000 / executions, 2) "elap/exec",
       round(cpu_time / 1000000 / executions, 2) "cpu/exec",
       round(buffer_gets / executions, 2) "buf_gets/exec",
       round(disk_reads / executions, 2) "dsk_rds/Exec",
       executions,
       plan_hash_value
  FROM TABLE(dbms_sqltune.select_cursor_cache('module like ''%''||''&module''||''%'' and sql_id like ''%''||''&sql_id''||''%'' and upper(sql_text) like upper(''%''||''&sql_text''||''%'')'))
 WHERE executions >= 1
 ORDER BY 3 DESC
;/*
**********************************************************************
** 
**   File: sys_binds_usage.sql                                                         
**   $Date: 2014/07/07 06:40:22 $                                                                     
**   $Revision: 1.3 $                                                                 
**   Description: Finds the biggest groups of similar SQLs in the shared pool.
**
**********************************************************************
*/

column perc format a5
SELECT CASE 
         WHEN MODULE LIKE 'msg\_q%' ESCAPE '\' 
         THEN 'msg_queue' 
         ELSE MODULE 
       END                             			MODULE,
       COUNT(*)                        			COUNT,
       trunc(COUNT(*)/total.count*100)||'%' PERC,
       v.PERSISTENT_MEM,
       v.PLAN_HASH_VALUE,
       MIN(v.SQL_ID)												SAMPLE_ID,
       MIN(v.SQL_TEXT)                 			SAMPLE_TEXT
  FROM v$sql v,
       (
         SELECT COUNT(*) COUNT FROM v$sql
       ) total
 GROUP BY
       v.PERSISTENT_MEM,
       v.PLAN_HASH_VALUE,
       substr(v.SQL_TEXT,1,30),
       CASE 
         WHEN MODULE LIKE 'msg\_q%' ESCAPE '\' 
         THEN 'msg_queue' 
         ELSE MODULE 
       END,
       total.count
HAVING trunc(COUNT(*)/total.count*100) > 0
 ORDER BY COUNT(*) DESC
 ;/*
**********************************************************************
** 
**   File: sys_cache_content.sql                                                         
**   $Date: 2014/07/07 06:40:22 $                                                                     
**   $Revision: 1.3 $                                                                 
**   Description: List the objects presented in the buffer cache ordered by cached percentage.
**
**********************************************************************
*/

column owner  heading "Owner" format a15
column objname heading "Object|Name" format a30
column subobjname heading "Subobject|Name" format a25
column objtype heading "Object|Type" format a10
column bufferblocks heading "Blocks in|Buffer" format 999,999,999
column totalblocks heading "Total|Blocks" format 999,999,999
column bufferpercent heading "Percentage|in Buffer" format 999.99
column memkb heading "Memory|in KB" format 999,999,999
column blockkb heading "Block|Size|KB" format 99
BREAK ON REPORT
COMPUTE SUM LABEL "Used memory(KB)" OF memkb ON REPORT
select s.owner owner,
			 object_name objname,
			 subobject_name subobjname,
			 substr(object_type,1,10) objtype,
			 ts.block_size / 1024 blockkb,
			 buffer.blocks blocks,
			 s.blocks totalblocks,
			 (buffer.blocks * ts.block_size / 1024) memkb,
			 (buffer.blocks/decode(s.blocks, 0, .001, s.blocks))*100 bufferpercent
  from (
			  select o.owner, o.object_name, o.subobject_name, o.object_type object_type, count(*) blocks
			    from dba_objects o, v$bh bh
			   where o.data_object_id = bh.objd 
			     and o.owner not in ('SYS','SYSTEM')
			   group by o.owner, o.object_name, o.subobject_name, o.object_type
			 ) buffer,
			 dba_segments s,
			 dba_tablespaces ts
 where s.tablespace_name = ts.tablespace_name
   and s.owner = buffer.owner
   and s.segment_name = buffer.object_name
   and s.SEGMENT_TYPE = buffer.object_type
   and (s.PARTITION_NAME = buffer.subobject_name or buffer.subobject_name is null)
 order by bufferpercent desc
;/*
**********************************************************************
**
**   File: tab_col_stats.sql                                                         
**   $Date: 2014/07/07 06:40:22 $                                                                     
**   $Revision: 1.3 $                                                                 
**   Description: Show the main column statistics for a particular table and part of column name.
**
**********************************************************************
*/

/*
Set serverout ON size 100000;                                                      
DECLARE                                                            
  d_low   DATE;                                                    
  d_high  DATE;                                                    
  n_low   NUMBER;                                                  
  n_high  NUMBER;                                                  
  v_low   VARCHAR2(100);                                           
  v_high  VARCHAR2(100);                                           
BEGIN                                                              
  -- get raw values                                                
  FOR col IN (                                                     
    SELECT column_name, low_value, high_value, data_type           
      FROM all_tab_columns                                         
     WHERE table_name = upper('&table_name')                       
       AND column_name LIKE upper('%&column_name%')                
  )                                                                
  LOOP                                                             
    dbms_output.put_line('---------------------------------');     
    dbms_output.put_line('column name : ' || col.column_name);     
    dbms_output.put_line('data type   : ' || col.data_type);       
    -- convert raw to readable values and print them               
    IF col.data_type = 'DATE' THEN                                 
      dbms_stats.convert_raw_value(col.low_value, d_low);          
      dbms_stats.convert_raw_value(col.high_value, d_high);        
      dbms_output.put_line('low value   : '||d_low);               
      dbms_output.put_line('high value  : '||d_high);              
    ELSIF col.data_type = 'NUMBER' THEN                            
      dbms_stats.convert_raw_value(col.low_value, n_low);          
      dbms_stats.convert_raw_value(col.high_value, n_high);        
      dbms_output.put_line('low value   : '||n_low);               
      dbms_output.put_line('high value  : '||n_high);              
    ELSIF col.data_type = 'VARCHAR2' THEN                          
      dbms_stats.convert_raw_value(col.low_value, v_low);          
      dbms_stats.convert_raw_value(col.high_value, v_high);        
      dbms_output.put_line('low value   : '||v_low);               
      dbms_output.put_line('high value  : '||v_high);              
    ELSE                                                           
      dbms_output.put_line('Error: unexpected data type.');        
    END IF;                                                        
  END LOOP;                                                        
  dbms_output.put_line('---------------------------------');       
END;                                                               
/                                                                  
SET serverout OFF;                                                 
undef table_name;                                                  
undef column_name;  
*/

SELECT cs.table_name, cs.column_name, cs.num_distinct, cs.density, 
       cs.num_nulls, cs.histogram, cs.last_analyzed, cs.sample_size
  FROM all_tab_col_statistics cs                                   
 WHERE cs.table_name = upper('&table_name')                       
   AND cs.column_name LIKE upper('%&column_name%')                
   AND cs.owner = :vcOwner
 ORDER BY cs.table_name, cs.column_name                            
;                                               /*
**********************************************************************
**
**   File: tab_del_stats.sql                                                         
**   $Date: 2014/07/07 06:40:22 $                                                                     
**   $Revision: 1.3 $                                                                 
**   Description: Delete the statistics of a table.
**
**********************************************************************
*/

DECLARE
  lTableName VARCHAR2(30) := upper('&table_name');
BEGIN
  dbms_stats.unlock_table_stats(ownname => USER, tabname => lTableName);
  dbms_stats.delete_table_stats(ownname => USER, tabname => lTableName);
  dbms_stats.lock_table_stats(ownname => USER, tabname => lTableName);
END;
//*
**********************************************************************
**
**   File: tab_gather_stats.sql                                                         
**   $Date: 2014/07/07 06:40:22 $                                                                     
**   $Revision: 1.3 $                                                                 
**   Description: Gather statistics of a table. If histogram parameter is filled in with a column name only a histogram on that column is gathered.
**
**********************************************************************
*/

DECLARE
  lTableName VARCHAR2(30) := upper('&table_name');
  lSampleSize VARCHAR2(30) := '&sample_size';
  lHistogram VARCHAR2(30) := '&histogram';
  lCascade VARCHAR2(30) := '&cascade';
  lForce VARCHAR2(30) := '&force';
BEGIN
	dbms_stats.unlock_table_stats(ownname => USER,tabname => lTableName);
	dbms_stats.gather_table_stats(ownname => USER, tabname => lTableName,
	  estimate_percent => case when lSampleSize is null then dbms_stats.auto_sample_size else to_number(lSampleSize) end,
	  method_opt => case when lHistogram is null then 'FOR ALL COLUMNS SIZE 1' else 'FOR COLUMNS '||lHistogram||' SIZE AUTO' end,
		degree => 8,
		cascade => case lCascade when 'true' then true else false end,
	  force => case lForce when 'true' then true else false end
	);
	dbms_stats.lock_table_stats(ownname => USER,tabname => lTableName);
END;
//*
**********************************************************************
**
**   File: tab_indexes.sql                                                         
**   $Date: 2014/07/07 06:40:22 $                                                                     
**   $Revision: 1.3 $                                                                 
**   Description: Lists the indexes and their columns for a particular table.
**
**********************************************************************
*/

break on ind_name SKIP 1 
col column_name format a22 
col column_expression format a22 
col index_type format a22 

var vcTableName varchar2(30);
var vcColumnName varchar2(30);
  
begin
  :vcTableName := upper('&table_name');
  :vcColumnName := upper('&column_name');
end;
/

SELECT i.index_name ind_name, 
       decode(i.index_type, 'NORMAL', NULL, i.index_type) index_type, 
       ic.column_name, 
       uie.column_expression 
  FROM all_ind_columns ic, all_Ind_Expressions uie, all_indexes i 
 WHERE ic.table_name = :vcTableName
   AND ic.index_owner = :vcOwner
   AND uie.table_name(+) = ic.table_name 
   AND uie.index_name(+) = ic.index_name 
   AND uie.column_position(+) = ic.column_position 
   and uie.index_owner(+)=ic.index_owner
   and i.owner=ic.index_owner
   AND i.index_name = ic.index_name 
   AND (
     	   :vcColumnName IS NULL
   		   OR
	   		 EXISTS
	       ( 
	         SELECT 1
	           FROM all_ind_columns
	          WHERE TABLE_NAME = ic.table_name
	            AND index_name = ic.index_name
	            AND column_name like '%'||:vcColumnName||'%'
	       )
	     )  
 ORDER BY 1,ic.column_position;
/*
**********************************************************************
**
**   File: tab_ind_stati.sql                                                         
**   $Date: 2014/07/07 06:40:22 $                                                                     
**   $Revision: 1.3 $                                                                 
**   Description: Show the index statistics for a particular table.
**
**********************************************************************
*/

var table_name varchar2(30);
exec :table_name := upper('&table_name');

col columns format a42
col cf format 999
SELECT *
  FROM (
				SELECT i.index_name index_name,
				       i.blevel,
				       avg_data_blocks_per_key "ROWS/KEY",
				       avg_leaf_blocks_per_key "BLOCKS/KEY",
				       i.num_rows "ROWS",
				       i.distinct_keys keys,
				       i.leaf_blocks blocks,
				       round(i.clustering_factor/greatest(t.blocks,1)) cf,
				       i.last_analyzed,
				       decode(c.column_position, 1, rtrim(
				         c.column_name||','||
				         lead(column_name,1) over(PARTITION BY c.index_name ORDER BY c.column_position)||','||
				         lead(column_name,2) over(PARTITION BY c.index_name ORDER BY c.column_position)||','||
				         lead(column_name,3) over(PARTITION BY c.index_name ORDER BY c.column_position)||','||
				         lead(column_name,4) over(PARTITION BY c.index_name ORDER BY c.column_position)||','||
				         lead(column_name,5) over(PARTITION BY c.index_name ORDER BY c.column_position),
				       ',')) columns
				  FROM all_tables t, all_indexes i, all_ind_columns c
				 WHERE t.table_name = :table_name
				   AND i.table_name = t.table_name
				   AND c.index_name = i.index_name
                   and t.owner = :vcOwner
                   and i.owner = t.owner
                   and c.index_owner = t.owner
			 )
 WHERE columns is not null
 ORDER BY columns
;/*
**********************************************************************
**
**   File: tab_stats.sql                                                         
**   $Date: 2014/07/07 06:40:22 $                                                                     
**   $Revision: 1.3 $                                                                 
**   Description: Show the main table statistics for a particular table.
**
**********************************************************************
*/

SELECT tab.owner, tab.blocks, tab.num_rows, tab.avg_row_len,                          
       seg.bytes/1024/1024 MB_As_Is,                                       
       trunc(tab.num_rows*avg_row_len/1024/1024) MB_To_Be,                 
       tab.last_analyzed,                                                  
       tab.sample_size,                                                    
       MODI.inserts,                                                       
       MODI.updates,                                                       
       MODI.deletes,                                                       
       trunc(((MODI.inserts + MODI.updates + MODI.deletes) /               
         decode(tab.num_rows, 0, 1, tab.num_rows) * 100), 2) perc_modified 
  FROM dba_segments seg, all_tables tab, all_tab_modifications MODI   
 WHERE tab.table_name = upper('&table_name')
   AND seg.segment_name = tab.table_name
   AND MODI.table_name(+) = tab.table_name
   and tab.owner = seg.owner
   and modi.table_owner=tab.owner
;
/*
**********************************************************************
**
**   File: trc.sql                                                         
**   $Date: 2014/07/07 06:40:22 $                                                                     
**   $Revision: 1.3 $                                                                 
**   Description: Enable/disable SQL*Trace for sessions identified by pid/sid/module. By default the current session is traced.
**
**********************************************************************
*/
SET serverout ON;

DECLARE
  nLevel NUMBER := nvl(to_number('&level'),0);
  vcPID varchar2(12) := '&pid'; 
  nSID number := to_number('&sid');
  vcModule varchar2(50) := '&module';
  vcTraceMethod VARCHAR2(100);
  vcPlSqlBlock VARCHAR2(1000);
  bWaits BOOLEAN := case when nLevel in (8, 12) then TRUE else FALSE end;
  bBinds BOOLEAN := case when nLevel in (4, 12) then TRUE else FALSE end;
  vcWaits varchar2(5) := case when nLevel in (8, 12) then 'TRUE' else 'FALSE' end;
  vcBinds varchar2(5) := case when nLevel in (4, 12) then 'TRUE' else 'FALSE' end;
BEGIN 
  dbms_output.enable(NULL);  
  IF vcPID IS NULL AND nSID IS NULL AND vcModule IS NULL THEN
  	nSID := userenv('sid');
  END IF;
  
  BEGIN
    SELECT DISTINCT first_value(owner||'.'||table_name) over (
             ORDER BY CASE table_name
               WHEN 'DBMS_SYSTEM'    THEN 1
               WHEN 'DBMS_MONITOR'   THEN 2
               WHEN 'USER_TRACE'     THEN 3
               WHEN 'TRACE_CODIX_ON' THEN 4
               ELSE 99
             END
           )
      INTO vcTraceMethod
      FROM dba_tab_privs
     WHERE table_name IN ('DBMS_SYSTEM', 'DBMS_MONITOR', 'USER_TRACE', 'TRACE_CODIX_ON')
       AND (
            grantee = USER
            or
            grantee IN (select granted_role from dba_role_privs where grantee = USER)
           )
       AND PRIVILEGE = 'EXECUTE'
    ;
  EXCEPTION WHEN no_data_found THEN
  	IF nSID = userenv('sid') THEN
  		vcTraceMethod := 'ALTER SESSION';
    ELSE
      raise_application_error(-20001, 'You are not authorized to execute neither DBMS_SYSTEM nor DBMS_MONITOR!');
    END IF;
  END;
  
  dbms_output.put_line('-----------------------------------------------------------------------------');
  dbms_output.put_line('Traces (host: '||SYS_CONTEXT('USERENV','HOST')||', server_host: '||SYS_CONTEXT('USERENV','SERVER_HOST')||'):');
      
  for s in (
    SELECT s.sid, s.serial#, s.program,
           'cd '||udd.value||'; ls -l | grep -i '||lower(i.instance_name)||'_ora_'||p.spid||'.trc' trace_file
      FROM v$session s,
           v$process p,
           v$parameter udd,
           v$instance i
     WHERE (s.sid = nSID or nSID is null)
       AND (s.process = vcPID or vcPID is null)
       AND (s.module like '%'||vcModule||'%')
       AND s.TYPE != 'BACKGROUND'
       AND p.addr = s.paddr
       AND udd.name = 'user_dump_dest'
  ) LOOP
    dbms_output.put_line('');
    vcPlSqlBlock := NULL;

    IF vcTraceMethod = 'SYS.DBMS_SYSTEM' THEN
      vcPlSqlBlock := 
'
begin 
  sys.dbms_system.set_int_param_in_session(:sid, :serial#, ''max_dump_file_size'', 500*1024*1024);
  sys.dbms_system.set_ev(:sid, :serial#, 10046, :level, '''');
end;';        
      EXECUTE IMMEDIATE vcPlSqlBlock USING s.sid, s.serial#, nLevel;
      dbms_output.put_line('EXECUTE IMMEDIATE '||vcPlSqlBlock||' USING '''||s.sid||''', '''||s.serial#||''', '||to_char(nLevel)||';');
    ELSIF vcTraceMethod = 'SYS.DBMS_MONITOR' THEN
      IF nLevel > 0 THEN 
        vcPlSqlBlock :=                                               
'
begin
  sys.dbms_monitor.session_trace_enable(:sid, :serial#, waits => '||vcWaits||', binds => '||vcBinds||');
end;';
        EXECUTE IMMEDIATE vcPlSqlBlock USING s.sid, s.serial#;
        dbms_output.put_line('EXECUTE IMMEDIATE '||vcPlSqlBlock||' USING '''||s.sid||''', '''||s.serial#||';');
      ELSE
        vcPlSqlBlock := 'begin dbms_monitor.session_trace_disable(:sid, :serial#); end;';
        EXECUTE IMMEDIATE vcPlSqlBlock USING s.sid, s.serial#;             
        dbms_output.put_line('EXECUTE IMMEDIATE '||vcPlSqlBlock||' USING '''||s.sid||''', '''||s.serial#||';');
      END IF;                                                            
    ELSIF vcTraceMethod LIKE '%USER_TRACE' ESCAPE '\' THEN
      vcPlSqlBlock := 'begin '||vcTraceMethod||'(:sid, :serial#, :on_off); end;';
      EXECUTE IMMEDIATE vcPlSqlBlock USING s.sid, s.serial#, CASE nLevel WHEN 0 THEN 'off' ELSE 'on' END;
      dbms_output.put_line('EXECUTE IMMEDIATE '||vcPlSqlBlock||' USING '''||s.sid||''', '''||s.serial#||''', '''||CASE nLevel WHEN 0 THEN 'off' ELSE 'on' END||''';');
    ELSIF vcTraceMethod = 'DBASECU.TRACE_CODIX_ON' THEN -- dfx specific
      IF nLevel > 0 THEN
        vcPlSqlBlock := 'begin dbasecu.trace_codix_on(:sid, :serial#); end;';
      ELSE
        vcPlSqlBlock := 'begin dbasecu.trace_codix_off(:sid, :serial#); end;';
      END IF;
      
      EXECUTE IMMEDIATE vcPlSqlBlock USING s.sid, s.serial#;
      dbms_output.put_line('EXECUTE IMMEDIATE '||vcPlSqlBlock||' USING '''||s.sid||''', '''||s.serial#||';');
    ELSIF vcTraceMethod = 'ALTER SESSION' THEN
    	IF nLevel > 0 THEN
    		vcPlSqlBlock := 'alter session set events ''10046 trace name context forever, level '||to_char(nLevel)||'''';
    	ELSE
    		vcPlSqlBlock := 'alter session set events ''10046 trace name context off''';
    	END IF;
    	
    	EXECUTE IMMEDIATE vcPlSqlBlock;
    	dbms_output.put_line('EXECUTE IMMEDIATE '||vcPlSqlBlock);
    ELSE
    	raise_application_error(-20001, 'Unexpected trace method - '|| vcTraceMethod ||'!');
    END IF;
    
    dbms_output.put_line(s.trace_file);
  end loop;
END;
/

SET serverout OFF;
/*
**********************************************************************
**
**   File: trc_module.sql                                                         
**   $Date: 2014/07/07 06:40:22 $                                                                     
**   $Revision: 1.3 $                                                                 
**   Description: Enable/disable SQL tracing for a given client globally. The trace is persistent across instance restart.
**
**********************************************************************
*/

col TRACE_TYPE format a15
col PRIMARY_ID format a10
col QUALIFIER_ID1 format a30
col QUALIFIER_ID2 format a13
col WAITS format a5
col BINDS format a5

SELECT distinct nvl(r.grantee, t.grantee) dbms_monitor_grantee
  FROM dba_tab_privs t, dba_role_privs r
 WHERE t.table_name = 'DBMS_MONITOR'
   AND t.privilege = 'EXECUTE'
   and r.granted_role(+) = t.grantee
;
      
DECLARE
  vcEnableDisable varchar2(10) := lower('&enable_disable');
  vcClientId varchar2(50) := '&client_id';
  bWaits BOOLEAN := case when lower('&waits') = 'true' then TRUE else FALSE end;
  bBinds BOOLEAN := case when lower('&binds') = 'true' then TRUE else FALSE end;
BEGIN                   
  IF vcEnableDisable = 'enable' THEN
	  dbms_monitor.client_id_trace_enable(vcClientId, bWaits, bBinds);
	ELSE
		dbms_monitor.client_id_trace_disable(vcClientId);
  END IF;
END;
/

select * from dba_enabled_traces;/*
**********************************************************************
**
**   File: trc_module.sql                                                         
**   $Date: 2014/07/07 06:40:22 $                                                                     
**   $Revision: 1.3 $                                                                 
**   Description: Enable/disable SQL tracing for a given module globally. The trace is persistent across instance restart.
**
**********************************************************************
*/

col TRACE_TYPE format a15
col PRIMARY_ID format a10
col QUALIFIER_ID1 format a30
col QUALIFIER_ID2 format a13
col WAITS format a5
col BINDS format a5

SELECT distinct nvl(r.grantee, t.grantee) dbms_monitor_grantee
  FROM dba_tab_privs t, dba_role_privs r
 WHERE t.table_name = 'DBMS_MONITOR'
   AND t.privilege = 'EXECUTE'
   and r.granted_role(+) = t.grantee
;
      
DECLARE
  vcEnableDisable varchar2(10) := lower('&enable_disable');
  vcModule varchar2(50) := '&module';
  bWaits BOOLEAN := case when lower('&waits') = 'true' then TRUE else FALSE end;
  bBinds BOOLEAN := case when lower('&binds') = 'true' then TRUE else FALSE end;
BEGIN                   
  IF vcEnableDisable = 'enable' THEN
	  dbms_monitor.serv_mod_act_trace_enable('SYS$USERS', vcModule, dbms_monitor.all_actions, bWaits, bBinds);
	ELSE
		dbms_monitor.serv_mod_act_trace_disable('SYS$USERS', vcModule);
  END IF;
END;
/

select * from dba_enabled_traces;/*
**********************************************************************
**
**   File: trc_pid.sql                                                         
**   $Date: 2014/07/07 06:40:22 $                                                                     
**   $Revision: 1.3 $                                                                 
**   Description: Enable/disable SQL*Trace for a process identified by OS PID using DBMS_SYSTEM.
**
**********************************************************************
*/

undef pid
undef level
accept pid number prompt 'Enter OS pid: '
accept level number prompt 'Enter trace event level (0,1,4,8,12): '

DECLARE 																										                                     
  nSID    NUMBER;                                                                               
  nSerial NUMBER;                                                                               
BEGIN                                                                                           
  SELECT sid, serial#                                                                           
    INTO nSID, nSerial                                                                          
    FROM v$session                                                                              
   WHERE process = '&pid'                                                                      
  ;                                                                                             
                                                                                                
  sys.dbms_system.set_int_param_in_session(nSID, nSerial, 'max_dump_file_size', 500*1024*1024); 
  sys.dbms_system.set_ev(nSID, nSerial, 10046, &level, '');                                     
END;                                                                                            
/

SELECT s.sid,
       s.serial#,
       s.username,
       s.program,
       udd.value||'/'||lower(i.instance_name)||'_ora_'||p.spid||'.trc' trace_filename
  FROM v$session s,
       v$process p,
       v$parameter udd,
       v$instance i
 WHERE p.addr = s.paddr                                                              
   AND s.TYPE != 'BACKGROUND'
   AND s.process = '&pid'
   AND udd.name = 'user_dump_dest'
;
   
undef pid
undef level
/*
**********************************************************************
**
**   File: trc_pid.sql                                                         
**   $Date: 2014/07/07 06:40:22 $                                                                     
**   $Revision: 1.3 $                                                                 
**   Description: Enable/disable SQL*Trace for a process identified by OS PID using DBMS_MINITOR.
**
**********************************************************************
*/

undef pid
undef level
accept pid number prompt 'Enter OS pid: '
accept level number prompt 'Enter trace event level (0,1,4,8,12): '                                                                                             

DECLARE                                                                                                                                                                                                                                                                                                                    
  nSID    NUMBER;
  nSerial NUMBER;
BEGIN
  SELECT sid, serial#
    INTO nSID, nSerial
    FROM v$session
   WHERE process = '&&pid'
  ;
                                                                                     
  IF &level > 0 THEN
    dbms_monitor.session_trace_enable(nSID, nSerial,
      waits => case when &level in (8, 12) then TRUE else FALSE end,
      binds => case when &level in (4, 12) then TRUE else FALSE end);
  ELSE                
    dbms_monitor.session_trace_disable(nSID, nSerial);
  END IF;
END;
/

SELECT s.sid,
       s.serial#,
       s.username,
       s.program,
       udd.value||'/'||lower(i.instance_name)||'_ora_'||p.spid||'.trc' trace_filename
  FROM v$session s,
       v$process p,
       v$parameter udd,
       v$instance i
 WHERE p.addr = s.paddr                                                              
   AND s.TYPE != 'BACKGROUND'
   AND s.process = '&pid'
   AND udd.name = 'user_dump_dest'
;
   
undef pid
undef level
