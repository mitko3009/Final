/*
**********************************************************************
**
**   File: sql_pt_text.sql                                                         
**   $Date: 2015/12/17 09:54:52 $                                                                     
**   $Revision: 1.1 $                                                                 
**   Description: Show the full sql_text of a particular cursor from pt_sql_observed.
**
**********************************************************************
*/

set head off
set lines 32676

column sql_text format a32676

SELECT sql_fulltext||';' sql_text, upper('sql_text_end') FROM pt_sql_observed WHERE sql_id = '&&sql_id'
;

set head on