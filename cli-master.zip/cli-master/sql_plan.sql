/*
**********************************************************************
**
**   File: sql_plan.sql                                                         
**   $Date: 2014/03/25 15:09:53 $                                                                     
**   $Revision: 1.5 $                                                                 
**   Description: Display the cursor cache execution plan for a particular SQL. By default it displays the RUNSTATS of the last executed SQL.
**
**********************************************************************
*/

SELECT * FROM TABLE(DBMS_XPLAN.display_cursor(
  case 
    when '&prev' is null then null
    else '&sql_id'
  end,
  null,
  case 
    when '&mode' is null then 'RUNSTATS_LAST'
  	else 'ALL ALLSTATS LAST alias +PEEKED_BINDS +outline'
  end
));
