/*
**********************************************************************
**
**   File: sql_binds.sql                                                         
**   $Date: 2016/05/13 13:12:45 $                                                                     
**   $Revision: 1.5 $                                                                 
**   Description: Dump SQL shared pool bind variables declarations for the last 12 hours.
**
**********************************************************************
*/

column last_captured format a179
break on last_captured
alter session set NLS_DATE_FORMAT='yyyy/mm/dd hh24:mi:ss';
SELECT last_captured||CHR(10)||'--------------------'||CHR(10)||
       'var '||substr(name,2)||' '||replace(replace(
         case 
           when datatype_string like 'CHAR%' then 'VARCHAR2'||substr(datatype_string,5) 
           when datatype_string = 'DATE' then 'VARCHAR2(20)'
           else datatype_string
         end
       ,'2000','1000'),'4000','1000')||';'||CHR(10)||
       'exec '||name||' := ' ||
         case 
          when datatype_string = 'NUMBER' then nvl(value_string, 'null')
          else ''''||value_string||''''
        end || ';' ||
        decode(datatype_string,'DATE',' /*to_date('||name||',''mm/dd/yyyy hh24:mi:ss'')'||'*/') decl
  FROM (
        SELECT b.last_captured,
               b.position,
               case 
                 when REGEXP_COUNT(b.name, '[[:digit:]]', 2) >= 1 and REGEXP_INSTR(b.name, '[[:alpha:]]', 2) = 0
                 then replace(b.name,':',':B')
                 else name
               end name,
               decode(value_string,'NULL',null,value_string) value_string,
               datatype_string
          FROM v$sql_bind_capture b
         WHERE b.sql_id = '&&sql_id'
           AND last_captured > SYSDATE - 12/24
         ORDER BY last_captured, position
       )
;