/*
**********************************************************************
**
**   File: par_sp_breakdown.sql
**   $Date: 2016/03/12 14:33:00 $
**   $Revision: 1.1 $
**   Description: Show memory parameters.
**
**********************************************************************
*/

SELECT name, bytes/1024/1024 megabytes
  FROM v$sgastat 
 WHERE pool = 'shared pool' 
   AND (bytes > 999999 OR name = 'free memory') 
 ORDER BY bytes DESC;
