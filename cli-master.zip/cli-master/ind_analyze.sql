/*
**********************************************************************
**
**   File: ind_analyze.sql                                                         
**   $Date: 2013/10/04 10:00:07 $                                                                     
**   $Revision: 1.1 $                                                                 
**   Description: Analyze index and show the results.
**
**********************************************************************
*/

undef INDEX_NAME;
ANALYZE INDEX &&INDEX_NAME VALIDATE STRUCTURE;
SELECT lf_blks, del_lf_rows FROM Index_Stats WHERE name='&INDEX_NAME';
undef INDEX_NAME;