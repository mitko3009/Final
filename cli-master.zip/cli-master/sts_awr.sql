/*
**********************************************************************
**
**   File: sts_awr.sql                                                         
**   $Date: 2013/05/15 14:44:56 $                                                                     
**   $Revision: 1.1 $                                                                 
**   Description: Lists statistics from workload repository for sql statements.
**
**********************************************************************
*/

var nSnapMin NUMBER;
var nSnapMax NUMBER;

BEGIN
  SELECT MIN(snap_id), MAX(snap_id)
    INTO :nSnapMin, :nSnapMax
    FROM dba_hist_snapshot
  ;
END;
/
set lines 179 pages 999
col sql_id format a15
col MODULE format a30
undef snapshot1
undef snapshot2
SELECT substr(module,1,20) module,
       sql_id,
       round(elapsed_time / 1000000, 2) elapsed_time,
       round(cpu_time / 1000000, 2) cpu_time,
       buffer_gets,
       disk_reads, 
       round(elapsed_time / 1000000 / executions, 2) "elap/exec",
       round(cpu_time / 1000000 / executions, 2) "cpu/exec",
       round(buffer_gets / executions, 2) "buffer_gets/exec",
       round(disk_reads / executions, 2) "disk_reads/Exec",
       executions
  FROM TABLE(dbms_sqltune.select_workload_repository(
         decode('&&snapshot1', NULL, :nSnapMin, '&snapshot1'),
         decode('&&snapshot2', NULL, :nSnapMax, '&snapshot2'),
         'module like ''%''||''&module''||''%'' and sql_id like ''%''||''&sql_id''||''%'' and upper(sql_text) like upper(''%''||''&sql_text''||''%'')'
       ))          
 WHERE executions >= 1
 ORDER BY 3 DESC;
