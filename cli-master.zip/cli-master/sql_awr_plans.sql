/*
**********************************************************************
**
**   File: sql_awr_plans.sql                                                         
**   $Date: 2015/02/02 13:25:55 $                                                                     
**   $Revision: 1.2 $                                                                 
**   Description: Display all execution plans for a particular SQL in the workload repository.
**
**********************************************************************
*/

SELECT tf.plan_table_output
  FROM TABLE(dbms_xplan.display_awr('&&sql_id',NULL,NULL, case 
			   when '&mode' is null then 'TYPICAL'
			 	 else 'ALL ALLSTATS LAST alias +PEEKED_BINDS +outline'
			 end)) tf
;
