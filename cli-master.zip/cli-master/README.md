<img src="https://www.codix.eu/img/app/codix-business-and-finance-software-solution-company-logo.png" alt="Generic System Wide Settings (PDM)" width="250"/>

## Name
***
Command line interface (cli)

## Description
***
Various sql scripts are placed in cli. 
Using them is easier to obtain different performance metrics from the database.

## Location
***
$IMX_HOME/perf/cli

## Technologies
***
* PL/SQL
* SQL

## Libraries
***
## Installation
***
Only file transfer is needed.

## Usage
***
Each script serve different purpose. Each of them have short description.

## Support
***
performance_and_tuning@codixfr.private

## Roadmap 
***
## Authors and acknowledgment
***
Performance & Tuning team

## License
***
Codix License
