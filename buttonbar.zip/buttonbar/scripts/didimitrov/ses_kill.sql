undef sid
undef serial#
ALTER SYSTEM KILL SESSION '&sid,&serial';
