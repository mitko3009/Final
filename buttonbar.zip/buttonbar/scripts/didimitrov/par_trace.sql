column value format a100
column name format a20
select name, value
  from v$parameter
 where name IN (
        'timed_statistics', 
        'max_dump_file_size', 
        'user_dump_dest'
       )
 union all
select name, value
  from v$diag_info
 where name = 'Diag Trace'
;