col "VALUE/TXN" format 9999999999999.99
col value format       9999999999999
SELECT decode(COUNT(DISTINCT ses.inst_id), 1, to_char(MAX(ses.inst_id)), 'ALL') inst_id,
	     n.name, count(ses.sid) sessions, sum(s.value) VALUE, round(decode(txn.cnt, 0, null, sum(s.value)/txn.cnt),2) "VALUE/TXN"
  FROM gv$sesstat s, gv$statname n, gv$session ses,
       ( SELECT ses.inst_id,
        	     SUM(stat.value) cnt
				  FROM gv$sesstat stat, gv$statname n, gv$session ses
				 WHERE (
				         '&&module' is null 
				         	OR 
				         	upper(ses.module) LIKE upper('%&module%') ESCAPE '\' 
				         	OR 
				         	upper(ses.program) LIKE upper('%&module%') ESCAPE '\'
				         	OR
				         	upper('&&module') = 'NULL' and ses.module IS NULL
				       )
				   AND ('&&sid' is null OR ses.sid = '&sid')
				   AND ( nvl('&&inst_id','ALL') = 'ALL' OR to_char(ses.inst_id) = '&&inst_id' )
				   AND stat.sid = ses.sid
				   AND stat.inst_id = ses.inst_id
				   AND stat.statistic# = n.statistic#
				   AND stat.inst_id = n.inst_id
				   AND n.name IN ('user commits', 'user rollbacks')
				 GROUP BY ses.inst_id ) txn
 WHERE (
         '&&module' is null 
         	OR 
         	upper(ses.module) LIKE upper('%&module%') ESCAPE '\' 
         	OR 
         	upper(ses.program) LIKE upper('%&module%') ESCAPE '\'
         	OR
         	upper('&&module') = 'NULL' and ses.module IS NULL
       )
   AND ('&&sid' is null OR ses.sid = '&sid')
   AND ( nvl('&&inst_id','ALL') = 'ALL' OR to_char(ses.inst_id) = '&&inst_id' )
   AND ses.sid = s.sid
   AND ses.inst_id = s.inst_id
   AND upper(n.name) like upper('%&stat_name%')
   AND s.statistic# = n.statistic#
   AND s.inst_id = n.inst_id
   AND s.value != 0
   AND txn.inst_id = ses.inst_id
 GROUP BY ses.inst_id, n.name, txn.cnt
 ORDER BY ses.inst_id, sum(s.value) desc
;