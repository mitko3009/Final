for username in $(ps -eo user= | sort | uniq)
do
� cpuusg=$( top -b -n 1 -u $username | awk -v user=$username 'NR>7 {????? sum += $9; }????? END {????? if (sum > 0.0) print user, sum; }?????' )
� if [ ! -z "$cpuusg" ];
��� then echo $cpuusg "%";
� fi
done | sort -nr -k2
