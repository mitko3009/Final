undef hh
SELECT ash.sample_time, decode(ash.session_state, 'WAITING', ash.event, ash.session_state) state, ash.sql_id, blocker.sid blocker
  FROM dba_hist_active_sess_history ash, v$session ses, t_env u, v$session blocker
 WHERE ash.sample_time BETWEEN trunc(SYSDATE)+to_number('&&hh')/24 AND trunc(SYSDATE)+(to_number('&hh')+1)/24
   AND ash.program LIKE 'frmweb%'
   AND ses.sid = ash.session_id
   AND u.pid = ses.process
   AND u.logname = '&login'
   AND blocker.sid(+) = ash.blocking_session
 ORDER BY ash.sample_time
;