define group_by=event
define sql_id=""
define sid=""
define event=""
define add_filters=""
define rownum=""
define days_back=""
define begin_time=""
define end_time=""
define login_name=""
declare
  v_mpm_start_time varchar2(20);
begin
  select to_char(to_date('&&mpm_date', 'yyyymmdd')  +  (
             to_date(tmstmp.value, 'yyyy/mm/dd hh24:mi:ss') 
           - to_date(effdt.value, 'yyyy/mm/dd hh24:mi:ss') 
           - 1
         ),'yyyy/mm/dd hh24:mi:ss') start_time
    into v_mpm_start_time
    from t_ini tmstmp, t_ini effdt
   where tmstmp.program='mpm' 
     and tmstmp.key = 'last_timestamp'
     and effdt.program='mpm' 
     and effdt.key = 'last_effective_date';
  
  select to_char(to_date(v_mpm_start_time,'yyyy/mm/dd hh24:mi:ss'),:v_time_format) into :v_begin_time from dual;
  select to_char(to_date(v_mpm_start_time,'yyyy/mm/dd hh24:mi:ss')+1,:v_time_format) into :v_end_time from dual;
end;
/