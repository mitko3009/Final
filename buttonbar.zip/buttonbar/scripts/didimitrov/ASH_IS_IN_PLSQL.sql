col IN_CONNECTION_MGMT for a10
col IN_PARSE for a10
col IN_HARD_PARSE for a10
col IN_SQL_EXECUTION for a10
col IN_PLSQL_EXECUTION for a10
col IN_PLSQL_RPC for a10
col IN_PLSQL_COMPILATION for a10
col IN_JAVA_EXECUTION for a10
col IN_BIND for a10
col IN_CURSOR_CLOSE for a10
col IN_SEQUENCE_LOAD for a10
select module,
       sql_id,
       IN_CONNECTION_MGMT,
       IN_PARSE,
       IN_HARD_PARSE,
       IN_SQL_EXECUTION,
       IN_PLSQL_EXECUTION,
       IN_PLSQL_RPC,
       IN_PLSQL_COMPILATION,
       IN_JAVA_EXECUTION,
       IN_BIND,
       IN_CURSOR_CLOSE,
       IN_SEQUENCE_LOAD,
       count(*)
  from dba_hist_active_sess_history ash
 WHERE 1 = 1
   -- AND (module like 'int_trans%' or module like 'cg_valide1%' or module like 'bkg_lettr_compt%' or module like 'lst%')
   -- AND ash.module like 'BHFM_IR%'
   -- AND client_id = 'MJ179471'
   -- AND ash.program like 'frmweb%'
   AND sql_id = 'dpj3hgy1a46tv'
   AND session_id = 351
   AND session_serial# = 1239
   -- AND ash.sample_time BETWEEN to_date('2020/10/29 12:40:00','yyyy/mm/dd hh24:mi:ss') AND to_date('2020/10/29 13:30:00','yyyy/mm/dd hh24:mi:ss') 
 group by module,
          sql_id,
          IN_CONNECTION_MGMT,
          IN_PARSE,
          IN_HARD_PARSE,
          IN_SQL_EXECUTION,
          IN_PLSQL_EXECUTION,
          IN_PLSQL_RPC,
          IN_PLSQL_COMPILATION,
          IN_JAVA_EXECUTION,
          IN_BIND,
          IN_CURSOR_CLOSE,
          IN_SEQUENCE_LOAD;