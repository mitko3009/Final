col TRACE_TYPE format a15
col PRIMARY_ID format a10
col QUALIFIER_ID1 format a30
col QUALIFIER_ID2 format a13
col WAITS format a5
col BINDS format a5
select * from dba_enabled_traces;
set serverout on      
DECLARE
  bDisableTrace BOOLEAN := case when upper('&DisableTrace_from_0_to_1_def_0')= '1' then true else false end;  
  vcModule varchar2(50) := '&module';
  bBinds BOOLEAN := case when upper('&Binds_from_0_to_1_default_1')= '0' then false else true end;
  bWaits BOOLEAN := case when upper('&Waits_from_0_to_1_default_1')= '0' then false else true end;    
  vcPlans varchar2(30) := case nvl('&nplanStat_from_0_to_3_def_3','3') when '0' then 'never' when '3' then 'all_executions' when '2' then 'clever' else 'first_execution' end;
  vcSQL varchar2(300);
BEGIN                   
  dbms_output.enable(null);
  dbms_output.put_line(chr(10));
  IF bDisableTrace = false THEN
	  if to_number(substr(&_O_RELEASE,1,8))>=11010000 
	  then     
      if to_number(substr(&_O_RELEASE,1,8))>=11020002 
      then     
        --not possible to set level 64 with dbms_monitor:
        vcPlans:=(case vcPlans when 'clever'  then 'all_executions' else vcPlans end);
      else
        vcPlans:=(case vcPlans when 'all_executions' then 'all_executions' when 'clever' then 'all_executions' when 'never' then 'never' else 'first_execution' end);
      end if;
	    vcSQL:='begin dbms_monitor.serv_mod_act_trace_enable(''SYS$USERS'', '''||vcModule||''', dbms_monitor.all_actions, '||(case when bWaits = true then 'TRUE' else 'FALSE' end)||', '||(case when bBinds = true then 'TRUE' else 'FALSE' end)||', plan_stat=>'''||vcPlans||'''); end;'	  ;
	    dbms_output.put_line(vcSQL);
	    execute immediate vcSQL;
	  else
	    dbms_output.put_line('2 dbms_monitor.serv_mod_act_trace_enable(''SYS$USERS'', '''||vcModule||''', dbms_monitor.all_actions, '||(case when bWaits = true then 'TRUE' else 'FALSE' end)||', '||(case when bBinds = true then 'TRUE' else 'FALSE' end)||');');
	    dbms_monitor.serv_mod_act_trace_enable('SYS$USERS', vcModule, dbms_monitor.all_actions, bWaits, bBinds);	  
	  end if;
	ELSE
		if lower(vcModule)='all' then
		  for s in (select QUALIFIER_ID1 module from dba_enabled_traces where TRACE_TYPE='SERVICE_MODULE')
		  loop
    		dbms_output.put_line('3 dbms_monitor.serv_mod_act_trace_disable(''SYS$USERS'', '''||s.module||''');');
    		dbms_monitor.serv_mod_act_trace_disable('SYS$USERS', s.module);
		  end loop;
		else 
  		dbms_output.put_line('3 dbms_monitor.serv_mod_act_trace_disable(''SYS$USERS'', '''||vcModule||''');');
  		dbms_monitor.serv_mod_act_trace_disable('SYS$USERS', vcModule);
  	end if;
  END IF;
  /*
  module=all when disable is 1 => disable all trace for all modules.
  
  nplanStat_from_0_to_3_def_1 0:
    0 - never - version >= 11.1
    1 - first_execution
    2 - clever - if execution_time_per_sql >1min then all_executions else first_execution - version >= 11.2.0.2
    3 - all_executions - version >= 11.1
  */  
END;
/