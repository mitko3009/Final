select distinct serv.name service_name, ash.module
  from dba_hist_active_sess_history ash, V$ACTIVE_SERVICES serv
 where ash.module like '%std_migr_exp_mvt.export_fiu%'
   and ash.service_hash = serv.NAME_HASH;