SELECT *
FROM (
SELECT decode(COUNT(DISTINCT nvl(ash.module,'NULL')), 1, MAX(nvl(substr(nvl(ash.module,'NULL'),1,instr(ash.module,'@')-1),nvl(ash.module,'NULL')))) "module",
decode(COUNT(DISTINCT nvl(ash.sql_id,'NULL')), 1, MAX(nvl(ash.sql_id,'NULL'))) "sql_id",
decode(COUNT(DISTINCT nvl(to_char(ash.sid),'NULL') ), 1, MAX(nvl(to_char(ash.sid),'NULL'))) "sid",
decode(COUNT(DISTINCT nvl(to_char(ash.serial#),'NULL') ), 1, MAX(nvl(to_char(ash.serial#),'NULL') )) "serial#",
decode(COUNT(DISTINCT nvl(ash.eve,'NULL') ), 1, MAX(nvl(ash.eve,'NULL') )) "event",
to_char(MIN(ash.sample_time),'yyyy/mm/dd hh24:mi:ss') "from",
to_char(MAX(ash.sample_time),'yyyy/mm/dd hh24:mi:ss') "to",
10*COUNT(*) "active",
to_char(round(COUNT(*)/SUM(COUNT(*)) over()*100))||'%' "perc",
module,process,login_name, client_info, client_identifier
FROM (SELECT decode(pts.session_state, 'ON CPU', 'ON CPU', pts.event) eve, pts.* FROM pt_session pts) ash
WHERE 1=1
--     AND upper(ash.module) LIKE upper('%%')
--     AND ash.sql_id = 'sql_id')
--     AND ash.sid = 'sid')
     and ash.process = '30658'
--     AND upper(nvl(ash.eve, ash.session_state)) LIKE upper('%%') 
--     AND tty = upper('login_name') 
--     and upper(login_name) = upper('login_name')
--AND ash.sample_time between to_date('202107271130','yyyymmddhh24mi') and to_date('202107271200','yyyymmddhh24mi')
AND ash.sample_time between to_date('202107271130','yyyymmddhh24mi') and to_date('202107271200','yyyymmddhh24mi')
GROUP BY module,process,login_name
ORDER BY 10*COUNT(*) desc
    )
WHERE rownum <= 20
;