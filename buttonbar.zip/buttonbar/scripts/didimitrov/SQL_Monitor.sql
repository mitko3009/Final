SELECT dbms_sqltune.report_sql_monitor(session_id => null, session_serial => null, sql_id => null, report_level => 'ALL') FROM dual;
SELECT dbms_sqltune.report_sql_monitor(session_id => null, session_serial => null, sql_id => '52rw3pfrsaxc8', report_level => 'ALL') FROM dual;
SELECT dbms_sqltune.report_sql_monitor(session_id => 26, session_serial => 45126, sql_id => null, report_level => 'ALL') FROM dual;
