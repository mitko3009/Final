select sql_id, message from v$session_longops where sid = nvl('&sid',sid) and totalwork > sofar;
