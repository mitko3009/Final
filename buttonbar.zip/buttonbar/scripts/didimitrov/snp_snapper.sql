col TRACE_TYPE format a15
col PRIMARY_ID format a10
col QUALIFIER_ID1 format a30
col QUALIFIER_ID2 format a13
col WAITS format a5
col BINDS format a5
set serverout on
DECLARE
type tstateCount_t is TABLE OF binary_integer INDEX BY VARCHAR2(50);
type tsesstat_t
IS
  TABLE OF v$sesstat%rowtype;
  tstateCount tstateCount_t;
  EToNumber EXCEPTION;
  PRAGMA EXCEPTION_INIT(EToNumber, -6502);  
  vcCurrentState VARCHAR2(50);
  vcAction     VARCHAR2(100);
  vcSnappedModule     VARCHAR2(100);
  vcClientInfo VARCHAR2(100);
  tendsnap sys.ku$_parsed_items;--tsesstat_t;
  status NUMBER:=0;
  tmidsnap sys.ku$_parsed_items;
  tbsnap sys.ku$_parsed_items;
  --time model
  tendmodelsnap sys.ku$_parsed_items;
  tmidmodelsnap sys.ku$_parsed_items;
  tbmodelsnap sys.ku$_parsed_items;
/*
CREATE OR REPLACE TYPE SYS.ku$_parsed_items IS TABLE OF sys.ku$_parsed_item;
CREATE OR REPLACE TYPE SYS.ku$_parsed_item AS OBJECT
        (       item            VARCHAR2(30),   -- item to be parsed
                value           VARCHAR2(4000), -- item's value
                object_row      NUMBER          -- object row of item
        )
*/
  --sid
  nSnappedSid NUMBER;
  nSnappedSerial NUMBER;
  nCountMiddleSnaps NUMBER:=0;
  vcExModule varchar2(40);
  vcExAction varchar2(40);
  procedure PrintInternalStats is 
    vcState      VARCHAR2(50);
  begin
    dbms_output.put_line('Internal stats: ');
    --internal diagnostic of snapper:
    vcState:=tstateCount.first;
    WHILE vcState is not null
    LOOP
      dbms_output.put_line('vcState: '||vcState|| ' tstateCount: '||tstateCount(vcState));
      vcState := tstateCount.next(vcState);
    END LOOP;            
  end PrintInternalStats;
  --print time model difference
  procedure PrintTimeModelDiff IS
  BEGIN
    FOR s IN
    (
       SELECT id, v
         FROM
        (
           SELECT en.id, en.v-NVL(beg.v,0) v
             FROM
            (
               SELECT
                /*+ NO_MERGE cardinality(100)*/
                t.value id, t.OBJECT_ROW v
                 FROM TABLE(CAST(tbmodelsnap AS sys.ku$_parsed_items) ) t
            )
            beg,
            (
               SELECT
                /*+ NO_MERGE cardinality(100)*/
                t.value id, t.OBJECT_ROW v
                 FROM TABLE(CAST(tendmodelsnap AS sys.ku$_parsed_items) ) t
            )
            en
            WHERE beg.id(+)=en.id
         ORDER BY 2 DESC nulls last
        )
        WHERE v>0
    )
    LOOP
      dbms_output.put_line('model: '||s.v||': '||s.id);
    END LOOP;
  end PrintTimeModelDiff;
  --print v$sesstat difference
  procedure PrintStatsDiff IS
  BEGIN
    --print stats difference
    FOR s IN
    (
       SELECT id, v
         FROM
        (
           SELECT sn.name id, en.v-NVL(beg.v,0) v
             FROM
            (
               SELECT
                /*+ NO_MERGE cardinality(100)*/
                t.value id, t.OBJECT_ROW v
                 FROM TABLE(CAST(tbsnap AS sys.ku$_parsed_items) ) t
            )
            beg,
            (
               SELECT
                /*+ NO_MERGE cardinality(100)*/
                t.value id, t.OBJECT_ROW v
                 FROM TABLE(CAST(tendsnap AS sys.ku$_parsed_items) ) t
            )
            en, v$statname sn
            WHERE beg.id(+)=en.id
            AND en.id=sn.statistic#
         ORDER BY 2 DESC nulls last
        )
        WHERE v>0
    )
    LOOP
      dbms_output.put_line('stat: '||s.v||': '||s.id);
    END LOOP;
  end PrintStatsDiff;          
  --print Time model - used for both start and end:
  procedure PrintTimeModel(pModel IN sys.ku$_parsed_items) IS
  BEGIN
    FOR s IN
    (
       SELECT id, v
         FROM
        (
           SELECT t.value id, t.OBJECT_ROW v
             FROM TABLE(CAST(pModel AS sys.ku$_parsed_items) ) t
         ORDER BY v DESC nulls last
        )
        WHERE v>0     
    )
    LOOP
      dbms_output.put_line('model: '||s.v||': '||s.id);
    END LOOP;        
  end PrintTimeModel;      
  --print Session statistics
  procedure PrintStats(tpstats IN sys.ku$_parsed_items) IS
  BEGIN
    FOR s IN
    (
       SELECT id, v
         FROM
        (
           SELECT sn.name id, t.OBJECT_ROW v
             FROM TABLE(CAST(tpstats AS sys.ku$_parsed_items) ) t, v$statname sn
            WHERE t.value=sn.statistic#
         ORDER BY v DESC nulls last
        )   
        WHERE v>0             
    )
    LOOP
      dbms_output.put_line('stat: '||s.v||': '||s.id);
    END LOOP;  
  end PrintStats;     
BEGIN  
  select module, action 
    into vcExModule, vcExAction
    from v$session 
   where sid=userenv('sid');
    
  DBMS_APPLICATION_INFO.SET_MODULE(module_name=>'snp_snapper',action_name=>'wait');
  dbms_output.enable(NULL);
 
  WHILE (true)
  LOOP
    begin
      SELECT action, client_info
        INTO vcAction, vcClientInfo
        FROM v$session
       WHERE module='pt_snapcaller';
    exception when no_data_found then
      dbms_output.put_line('Exit: Caller not exists yet. Please start the caller before the snapper!');
      exit;
    end;    
    CASE 
    WHEN vcAction='actstp' THEN
      BEGIN
        vcCurrentState:='actstp';
        PrintInternalStats;
        EXIT;
      END;
    WHEN (vcAction='actstastat' and status=0) or (vcAction='acttoendstat' and status=0) THEN
      BEGIN
        IF status=0 THEN
          vcCurrentState:='actstastat';
          DBMS_APPLICATION_INFO.SET_MODULE(module_name=>'snp_snapper',action_name=>vcCurrentState||'in');
          --in trace by module we are waiting for the module to appear and this will be called many times:
          IF nSnappedSid IS NULL 
          THEN          
            begin
              nSnappedSid:=to_number(vcClientInfo);
            exception when EToNumber then 
              nSnappedSid:=null;
              if vcClientInfo like 'm:%' or vcClientInfo like 'M:%'
              then
                vcSnappedModule:=substr(vcClientInfo,3);
              end if;
            end;
          END IF;       
          if nSnappedSid is not null AND vcSnappedModule IS NULL then
            --get serial#
            begin
              select serial# into nSnappedSerial from v$session where sid=nSnappedSid;
            exception 
              when no_data_found then 
                dbms_output.put_line('Exit:session with sid: '||nSnappedSid||' not exists');
                PrintInternalStats;
                exit;
            end;  
          elsif vcSnappedModule is not null AND nSnappedSid IS NULL then
            BEGIN
              --get session by its module
              select sid, serial# into nSnappedSid, nSnappedSerial from v$session where module like '%'||vcSnappedModule||'%';
            exception 
              when no_data_found then null;
            end;
          end if;
          if nSnappedSerial is not null
          then
            --get stats at the beggining:
            Select sys.ku$_parsed_item('x',STATISTIC#,value)   
              bulk collect INTO tbsnap            
              FROM v$sesstat stat, v$session ses
             WHERE ses.sid=nSnappedSid
               AND ses.serial#=nSnappedSerial
               AND stat.sid=ses.sid              
             ORDER BY STATISTIC# ;    
             
            --snap time model:            
            SELECT sys.ku$_parsed_item('x',m.stat_name,m.VALUE)
             bulk collect INTO tbmodelsnap    
              FROM v$sess_time_model m, v$session ses
             WHERE ses.sid=nSnappedSid
               AND ses.serial#=nSnappedSerial
               AND ses.sid = m.sid;
                                       
            dbms_output.put_line(rpad('-',60,'-'));
            dbms_output.put_line('start snapping sid: '||nSnappedSid||' serial#: '||nSnappedSerial||tbsnap.count);
            dbms_output.put_line(rpad('-',60,'-'));
            PrintStats(tbsnap);
            dbms_output.put_line('start - snapped model: '||tbmodelsnap.count);
            PrintTimeModel(tbmodelsnap);     
            --start has been snapped - we do not want it to snap endlessly, because director will be with the same action for a long time:
            status:=1;
            DBMS_APPLICATION_INFO.SET_MODULE(module_name=>'snp_snapper',action_name=>vcCurrentState);          
          END IF; --sid is not null  
        END IF;
      END;
    WHEN vcAction='actstpstat' and status=1 THEN
      BEGIN
        --if it has been started - this is a machine - it has n statuses and can go from one to other based on some rules.        
        IF status=1 THEN
          vcCurrentState:='actstpstat';
          DBMS_APPLICATION_INFO.SET_MODULE(module_name=>'snp_snapper',action_name=>vcCurrentState);
          dbms_output.put_line('stop stat');
          Select sys.ku$_parsed_item('x',STATISTIC#,value)   
            bulk collect INTO tendsnap            
            FROM v$sesstat stat, v$session ses
           WHERE ses.sid=nSnappedSid
             AND ses.serial#=nSnappedSerial
             AND stat.sid=ses.sid              
           ORDER BY STATISTIC# ;  

          --snap time model:            
          SELECT sys.ku$_parsed_item('x',m.stat_name,m.VALUE)
            bulk collect INTO tendmodelsnap    
            FROM v$sess_time_model m, v$session ses
           WHERE ses.sid=nSnappedSid
             AND ses.serial#=nSnappedSerial
             AND ses.sid = m.sid;
                            
          dbms_output.put_line('stop - snapped stats : '||tendsnap.count);
          --stop snapper - we do not want it to snap endlessly:          
          status:=2;
          dbms_output.put_line(rpad('-',60,'-'));
          PrintStats(tendsnap);
          PrintTimeModel(tendmodelsnap);      
          dbms_output.put_line(rpad('-',60,'-'));    
          dbms_output.put_line('difference for sid: '||nSnappedSid||' count all stats: '||tendsnap.count);
          PrintStatsDiff;
          PrintTimeModelDiff;      
          PrintInternalStats;
          --exit now - you have to start new snapper if you need a new one - no remote printing implementation yet
          EXIT;          
        END IF;
      END;
    --repeated run - to catch sessions that end not expedetely:
   WHEN vcAction='acttoendstat' and status =1 THEN
      BEGIN
        --if it has been started - this is a machine - it has n statuses and can go from one to other based on some rules.
        IF status=1 THEN
          vcCurrentState:='acttoendstat';
          DBMS_APPLICATION_INFO.SET_MODULE(module_name=>'snp_snapper',action_name=>vcCurrentState||'in');
          Select sys.ku$_parsed_item('x',STATISTIC#,value)   
            bulk collect INTO tmidsnap            
            FROM v$sesstat stat, v$session ses
           WHERE ses.sid=nSnappedSid
             AND ses.serial#=nSnappedSerial
             AND stat.sid=ses.sid              
           ORDER BY STATISTIC# ;             

          --snap time model:            
          SELECT sys.ku$_parsed_item('x',m.stat_name,m.VALUE)
            bulk collect INTO tmidmodelsnap    
            FROM v$sess_time_model m, v$session ses
           WHERE ses.sid=nSnappedSid
             AND ses.serial#=nSnappedSerial
             AND ses.sid = m.sid;

          if tmidsnap.count=tbsnap.count
          then
            tendsnap:=tmidsnap;
            nCountMiddleSnaps:=nCountMiddleSnaps+1;
            --snap v$ses_time_model
            tendmodelsnap:=tmidmodelsnap;            
          elsif tendsnap.count=tbsnap.count
          then
            DBMS_APPLICATION_INFO.SET_MODULE(module_name=>'snp_snapper',action_name=>vcCurrentState);
            dbms_output.put_line(rpad('-',60,'-'));
            dbms_output.put_line('stop - snapped endless stats : '||tendsnap.count||' middle snaps: '||nCountMiddleSnaps);
            --stop snapper - we do not want it to snap endlessly:
            status:=2;
            --print stats:
            PrintStats(tendsnap);            
            --print v$sess_time_model at the end:
            dbms_output.put_line('stop - snapped endless model : '||tendmodelsnap.count||' middle snaps: '||nCountMiddleSnaps);            
            PrintTimeModel(tendmodelsnap);
            dbms_output.put_line(rpad('-',60,'-'));
            dbms_output.put_line('difference for sid: '||nSnappedSid||' count all stats: '||tendsnap.count);
            PrintStatsDiff;
            PrintTimeModelDiff;
            dbms_output.put_line(rpad('-',60,'-'));            
            PrintInternalStats;
            EXIT;
          END IF;
        end if;
      END;    
    WHEN vcAction='actrun' THEN
      begin
        vcCurrentState:='actrun';
        DBMS_APPLICATION_INFO.SET_MODULE(module_name=>'snp_snapper',action_name=>vcCurrentState);
      end;
    ELSE
      BEGIN
        vcCurrentState:='actdefault';        
        DBMS_APPLICATION_INFO.SET_MODULE(module_name=>'snp_snapper',action_name=>vcCurrentState);
      END;
    END CASE;
    --store stats for the snapper - how much time in which state snapper has spent:
    begin
      tstateCount(vcCurrentState):=tstateCount(vcCurrentState)+1;
    exception
    when no_data_found then
      tstateCount(vcCurrentState):=1;
    end;
    dbms_lock.sleep(0.1);
  END LOOP;
  --return module and action to the ones before start of the snapper:
  DBMS_APPLICATION_INFO.SET_MODULE(module_name=>vcExModule,action_name=>vcExAction);
END;
/