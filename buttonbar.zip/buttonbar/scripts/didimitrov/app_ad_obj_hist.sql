COLUMN lo_object_name     FORMAT A30   HEADING "Object Name";
COLUMN load_begin         FORMAT A20   HEADING "Load Begin";
COLUMN load_end           FORMAT A20   HEADING "Load End";
COLUMN elapsed_time       FORMAT A9    HEADING "Elapsed";
COLUMN lo_load_status     FORMAT A20   HEADING "Load Status";
SELECT lo_object_name,lo_load_begin,lo_load_end, elapsed_time ,lo_load_status
  FROM (SELECT f.lo_object_name,
               f.lo_load_begin,
               f.lo_load_end,
               LPAD(f.elapsed_time_h, 2, '0') || ':' ||
               LPAD(f.elapsed_time_m, 2, '0') || ':' ||
               LPAD(elapsed_time_s, 2, '0')              AS elapsed_time,
               f.lo_load_status
          FROM (SELECT d.lo_object_name,
                       d.lo_load_begin,
                       d.lo_load_end,
                       CASE
                         WHEN FLOOR(elapsed_time_m) > 0 THEN
                          ROUND(elapsed_time_s, 0) -
                          FLOOR(elapsed_time_m) * 60
                         ELSE
                          ROUND(elapsed_time_s, 0)
                       END AS elapsed_time_s,
                       CASE
                         WHEN FLOOR(elapsed_time_h) > 0 THEN
                          FLOOR(elapsed_time_m) - floor(elapsed_time_h) * 60
                         ELSE
                          FLOOR(elapsed_time_m)
                       END AS elapsed_time_m,
                       FLOOR(elapsed_time_h) AS elapsed_time_h,
                       d.lo_load_status
                  FROM (SELECT SUBSTR(p.load_begin, 1, 10)                       AS load_begin,
                               SUBSTR(nvl(p.load_end, SYSDATE), 1, 10)           AS load_end,
                               lo.lo_object_name                                 AS lo_object_name,
                               TO_CHAR(lo.lo_load_begin,
                                       'DD/MM/YYYY HH24:MI:SS')                  AS lo_load_begin,
                               TO_CHAR(lo.lo_load_end, 'DD/MM/YYYY HH24:MI:SS')  AS lo_load_end,
                               (NVL(lo.lo_load_end, SYSDATE) -
                               lo.lo_load_begin) * 60 * 60 * 24                  AS elapsed_time_s,
                               (NVL(lo.lo_load_end, SYSDATE) -
                               lo.lo_load_begin) * 60 * 24                       AS elapsed_time_m,
                               (NVL(lo.lo_load_end, SYSDATE) -
                               lo.lo_load_begin) * 24                            AS elapsed_time_h,
                               lo.lo_load_status                                 AS lo_load_status
                          FROM ad_loads p,
                               ad_load_objects lo,
                               (SELECT d.id
                                  FROM (SELECT l.id,
                                               l.load_mode,
                                               l.load_begin,
                                               row_number() over(ORDER BY l.id DESC) AS rnk
                                          FROM ad_loads l
                                         WHERE l.load_mode LIKE 'COMPLETE%') d
                                 WHERE trunc(d.load_begin) BETWEEN trunc(NVL(to_date('&FROM', 'dd/mm/yyyy'), SYSDATE)) AND trunc(NVL(to_date('&TO', 'dd/mm/yyyy'), SYSDATE))) f
                         WHERE 1 = 1
                           AND p.id = lo.lo_load_id(+)
                           AND p.load_mode LIKE 'COMPLETE%'
                           AND p.id = f.id
                         ORDER BY lo.lo_load_number) d) f
         WHERE UPPER(f.lo_object_name) = UPPER('&object_name')
         ORDER BY to_date(f.lo_load_begin,'dd/mm/yyyy hh24:mi:ss') DESC);