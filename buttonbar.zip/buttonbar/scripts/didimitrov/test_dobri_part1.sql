set lines 450 pages 9999 long 99999 longchunksize 99999 sqlblanklines on
column global_name new_value gname
set termout off head off
column show_rac_instance_id new_value is_inst_id_shown
select case value when 'TRUE' then 'for a7' else 'noprint' end show_rac_instance_id
  from v$parameter where name = 'cluster_database';
col inst_id &is_inst_id_shown
define gname=idle
column global_name new_value gname
select lower(user) || '@' || sys_context('USERENV', 'INSTANCE_NAME')
      ||'@'||userenv('sid') global_name
  from dual;
exec dbms_application_info.set_module('pt',null);
var vcOwner varchar2(30);
exec SELECT t.owner INTO :vcOwner FROM all_tables t WHERE t.table_name = 'G_ETUDE';
var v_begin_snap number;
var v_end_snap number;
var v_begin_time varchar2(20);
var v_end_time varchar2(20);
var v_time_format varchar2(20);
exec :v_time_format := 'yyyymmddhh24mi';
alter session set statistics_level=all;
