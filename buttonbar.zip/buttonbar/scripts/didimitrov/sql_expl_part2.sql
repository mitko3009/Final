select * from table(cast(dbms_xplan.display('sys.plan_table$','GKUD',nvl('&format','typical')) as sys.dbms_xplan_type_table));
