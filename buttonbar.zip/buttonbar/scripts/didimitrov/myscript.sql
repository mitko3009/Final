alter session set nls_date_format='yyyymmdd hh24miss';
