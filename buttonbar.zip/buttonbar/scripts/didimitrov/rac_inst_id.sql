select to_char(inst_id) inst_id, instance_name, host_name, status from gv$instance;
undef choose_inst_id
column chosen_inst_id for a15 new_value inst_id
select nvl(max(inst_id),'ALL') chosen_inst_id
  from ( select '&choose_inst_id' inst_id
           from dual ) d
 where exists ( select 1
                  from gv$instance i
                 where to_char(i.inst_id) = to_char(d.inst_id) )
   and exists ( select 1
                  from v$parameter 
                 where name = 'cluster_database'
                   and value = 'TRUE' )
;