Please provide the resulting output from <INSTANCE_NAME> for the following statements :

Commands are for SQL*PLUS(not from SQL DEVELOPER or other third party tools) :

alter session set nls_date_format='yyyymmdd hh24miss';
select min(sample_time) from pt_session;
select max(sample_time) from pt_session;
select min(sample_time) from dba_hist_active_sess_history;
select max(sample_time) from dba_hist_active_sess_history;

set pages 32000
set lines 300
col "FROM" format a20
col "TO" format a20
col event format a20 truncate
col MODULE format a30
col perc format a6
col period format a20
col CURRENT_OBJ for a50
col interval for a23
col PROGRAM for a50
col action for a25
col client_id for a15
col number_of_executions for 999999999
select * from (
SELECT -- decode(COUNT(DISTINCT ash.inst_id), 1, to_char(MAX(ash.inst_id)), 'ALL') inst_id,
       decode(COUNT(DISTINCT ash.module), 1, MAX(nvl ( substr(ash.module,1,instr(ash.module,'@')-1),ash.module) )) MODULE,
       -- decode(COUNT(DISTINCT ash.program), 1, MAX(nvl ( substr(ash.program,1,instr(ash.program,'@')-1),ash.program) )) program,
       -- decode(COUNT(DISTINCT ash.CLIENT_ID), 1, MAX(ash.CLIENT_ID)) CLIENT_ID,
       /* case when ash.module = 'EXTRANET' 
            then substr( decode(COUNT(DISTINCT ash.action), 1, MAX(ash.action)), instr(decode(COUNT(DISTINCT ash.action), 1, MAX(ash.action)),'.',-1) + 1 ) 
            else decode(COUNT(DISTINCT ash.action), 1, MAX(ash.action))
        end action,*/
       decode(COUNT(DISTINCT ash.sql_id), 1, MAX(ash.sql_id)) sql_id,
       decode(COUNT(DISTINCT ash.sql_plan_hash_value), 1, MAX(ash.sql_plan_hash_value)) plan_hash,
       decode(COUNT(DISTINCT ash.session_id), 1, MAX(ash.session_id)) sid,
       decode(COUNT(DISTINCT ash.session_serial#), 1, MAX(ash.session_serial#)) serial#,
       decode(COUNT(DISTINCT nvl(ash.event, ash.session_state)), 1, MAX(nvl(ash.event, ash.session_state))) event,
       -- decode(COUNT(DISTINCT ash.current_obj#), 1, MAX(ao.object_name||';'||ao.object_type ) ) current_obj,
       MIN(to_char(ash.sample_time,'yyyy/mm/dd hh24:mi:ss')) "FROM",
       MAX(to_char(ash.sample_time,'yyyy/mm/dd hh24:mi:ss')) "TO", 
       count(*)*10 active,
       max(sql_exec_id) - min(sql_exec_id) + 1 as number_of_executions,
       max(ash.sample_time) - min(ash.sample_time) as interval,
       to_char(round(COUNT(*)/SUM(COUNT(*)) over()*100))||'%' perc 
        --, to_char(ash.sample_time,'yyyy/mm/dd') as period
  FROM dba_hist_active_sess_history ash,dba_objects ao    
  --FROM v$active_session_history ash, dba_objects ao
WHERE 1 = 1
   AND ash.current_obj#=ao.object_id(+)      
   --AND ash.module like 'msg%'
   -- AND client_id = 'LA25413'
   --AND ash.program like 'frmweb%'
   -- AND sql_id = 'cw0rpb1jnpscz'
   -- AND session_id = 719
   -- AND session_serial# = 5977
   AND ash.sample_time BETWEEN to_date('2021/04/14 19:00:08','yyyy/mm/dd hh24:mi:ss') AND to_date('2021/04/14 20:00:00','yyyy/mm/dd hh24:mi:ss') 
 group by module --, session_id, session_serial# --, sql_exec_id, to_char(sql_exec_start,'hh24:mi:ss'), client_id, action 
          --, to_char(ash.sample_time,'yyyy/mm/dd') 
 order by -- to_char(ash.sample_time,'yyyy/mm/dd'),
           count(*) desc
)where rownum<21;        
