SET SERVEROUTPUT OFF
set PAGESIZE 200
set linesize 400
set long 1000000
set longchunksize 3000
set sqlblanklines on
SET TIMING ON
ALTER SESSION SET nls_date_format='yyyy-mm-dd hh24:mi:ss';
alter session set statistics_level = 'ALL';
col "FROM" format a20
col "TO" format a20
col event format a20 truncate
col MODULE format a32
col perc format a6
col period format a20
col CURRENT_OBJ for a50
col interval for a23
col PROGRAM for a50
col action for a25
col client_id for a15
col number_of_executions for 999999999
col instance_number for 999
SELECT -- decode(COUNT(DISTINCT ash.instance_number), 1, to_char(MAX(ash.instance_number)), 'ALL') instance_number,
       -- decode(COUNT(DISTINCT ash.inst_id), 1, to_char(MAX(ash.inst_id)), 'ALL') inst_id,
       decode(COUNT(DISTINCT ash.module), 1, MAX(nvl ( substr(ash.module,1,instr(ash.module,'@')-1),ash.module) )) MODULE,
       -- decode(COUNT(DISTINCT ash.program), 1, MAX(nvl ( substr(ash.program,1,instr(ash.program,'@')-1),ash.program) )) program,
       -- decode(COUNT(DISTINCT ash.CLIENT_ID), 1, MAX(ash.CLIENT_ID)) CLIENT_ID,
       /* case when ash.module = 'EXTRANET' 
            then substr( decode(COUNT(DISTINCT ash.action), 1, MAX(ash.action)), instr(decode(COUNT(DISTINCT ash.action), 1, MAX(ash.action)),'.',-1) + 1 ) 
            else decode(COUNT(DISTINCT ash.action), 1, MAX(ash.action))
        end action,*/
       decode(COUNT(DISTINCT ash.sql_id), 1, MAX(ash.sql_id)) sql_id,
       decode(COUNT(DISTINCT ash.sql_plan_hash_value), 1, MAX(ash.sql_plan_hash_value)) plan_hash,
       decode(COUNT(DISTINCT ash.session_id), 1, MAX(ash.session_id)) sid,
       decode(COUNT(DISTINCT ash.session_serial#), 1, MAX(ash.session_serial#)) serial#,
       decode(COUNT(DISTINCT nvl(ash.event, ash.session_state)), 1, MAX(nvl(ash.event, ash.session_state))) event,
       -- decode(COUNT(DISTINCT ash.current_obj#), 1, MAX(ao.object_name||';'||ao.object_type ) ) current_obj,
       MIN(to_char(ash.sample_time,'yyyy/mm/dd hh24:mi:ss')) "FROM",
       MAX(to_char(ash.sample_time,'yyyy/mm/dd hh24:mi:ss')) "TO", 
       count(*) active,
       max(sql_exec_id) - min(sql_exec_id) + 1 as number_of_executions,
       max(ash.sample_time) - min(ash.sample_time) as interval,
       to_char(round(COUNT(*)/SUM(COUNT(*)) over()*100))||'%' perc 
        --, to_char(ash.sample_time,'yyyy/mm/dd') as period
  FROM dba_hist_active_sess_history ash, dba_objects ao
 WHERE 1 = 1
   AND ash.current_obj#=ao.object_id(+)  
   -- AND (module like 'int_trans%' or module like 'cg_valide1%' or module like 'bkg_lettr_compt%' or module like 'lst%')
   -- AND ash.module like 'imxbatch_ValidateCessions%'
   -- AND client_id = 'LA25413'
   -- AND ash.program like 'frmweb%'
   -- AND sql_id = '1801pnt85sas8'
   -- AND session_id = 719
   -- AND session_serial# = 5977
   AND ash.sample_time BETWEEN to_date('2023/02/13 08:00:00','yyyy/mm/dd hh24:mi:ss') AND to_date('2023/02/13 09:15:00','yyyy/mm/dd hh24:mi:ss') 
 group by module -- , session_id, session_serial# --, sql_exec_id, to_char(sql_exec_start,'hh24:mi:ss'), client_id, action 
          --, to_char(ash.sample_time,'yyyy/mm/dd') 
 order by -- to_char(ash.sample_time,'yyyy/mm/dd'),
           count(*) desc
 fetch first 50 rows only;

col "FROM" format a20
col "TO" format a20
col event format a20 truncate
col MODULE format a32
col perc format a6
col period format a20
col CURRENT_OBJ for a50
col interval for a23
col PROGRAM for a50
col action for a25
col client_id for a15
col number_of_executions for 999999999
col instance_number for 999
SELECT -- decode(COUNT(DISTINCT ash.instance_number), 1, to_char(MAX(ash.instance_number)), 'ALL') instance_number,
       -- decode(COUNT(DISTINCT ash.inst_id), 1, to_char(MAX(ash.inst_id)), 'ALL') inst_id,
       decode(COUNT(DISTINCT ash.module), 1, MAX(nvl ( substr(ash.module,1,instr(ash.module,'@')-1),ash.module) )) MODULE,
       -- decode(COUNT(DISTINCT ash.program), 1, MAX(nvl ( substr(ash.program,1,instr(ash.program,'@')-1),ash.program) )) program,
       -- decode(COUNT(DISTINCT ash.CLIENT_ID), 1, MAX(ash.CLIENT_ID)) CLIENT_ID,
       /* case when ash.module = 'EXTRANET' 
            then substr( decode(COUNT(DISTINCT ash.action), 1, MAX(ash.action)), instr(decode(COUNT(DISTINCT ash.action), 1, MAX(ash.action)),'.',-1) + 1 ) 
            else decode(COUNT(DISTINCT ash.action), 1, MAX(ash.action))
        end action,*/
       decode(COUNT(DISTINCT ash.sql_id), 1, MAX(ash.sql_id)) sql_id,
       decode(COUNT(DISTINCT ash.sql_plan_hash_value), 1, MAX(ash.sql_plan_hash_value)) plan_hash,
       decode(COUNT(DISTINCT ash.session_id), 1, MAX(ash.session_id)) sid,
       decode(COUNT(DISTINCT ash.session_serial#), 1, MAX(ash.session_serial#)) serial#,
       decode(COUNT(DISTINCT nvl(ash.event, ash.session_state)), 1, MAX(nvl(ash.event, ash.session_state))) event,
       -- decode(COUNT(DISTINCT ash.current_obj#), 1, MAX(ao.object_name||';'||ao.object_type ) ) current_obj,
       MIN(to_char(ash.sample_time,'yyyy/mm/dd hh24:mi:ss')) "FROM",
       MAX(to_char(ash.sample_time,'yyyy/mm/dd hh24:mi:ss')) "TO", 
       count(*) active,
       max(sql_exec_id) - min(sql_exec_id) + 1 as number_of_executions,
       max(ash.sample_time) - min(ash.sample_time) as interval,
       to_char(round(COUNT(*)/SUM(COUNT(*)) over()*100))||'%' perc 
        --, to_char(ash.sample_time,'yyyy/mm/dd') as period
  FROM dba_hist_active_sess_history ash, dba_objects ao
 WHERE 1 = 1
   AND ash.current_obj#=ao.object_id(+)  
   -- AND (module like 'int_trans%' or module like 'cg_valide1%' or module like 'bkg_lettr_compt%' or module like 'lst%')
   -- AND ash.module like 'imxbatch_ValidateCessions%'
   -- AND client_id = 'LA25413'
   -- AND ash.program like 'frmweb%'
   -- AND sql_id = '1801pnt85sas8'
   -- AND session_id = 719
   -- AND session_serial# = 5977
   AND ash.sample_time BETWEEN to_date('2023/02/13 08:00:00','yyyy/mm/dd hh24:mi:ss') AND to_date('2023/02/13 09:15:00','yyyy/mm/dd hh24:mi:ss') 
 group by module, event -- , session_id, session_serial# --, sql_exec_id, to_char(sql_exec_start,'hh24:mi:ss'), client_id, action 
          --, to_char(ash.sample_time,'yyyy/mm/dd') 
 order by -- to_char(ash.sample_time,'yyyy/mm/dd'),
           count(*) desc
 fetch first 50 rows only;

col "FROM" format a20
col "TO" format a20
col event format a20 truncate
col MODULE format a32
col perc format a6
col period format a20
col CURRENT_OBJ for a50
col interval for a23
col PROGRAM for a50
col action for a25
col client_id for a15
col number_of_executions for 999999999
col instance_number for 999
SELECT -- decode(COUNT(DISTINCT ash.instance_number), 1, to_char(MAX(ash.instance_number)), 'ALL') instance_number,
       -- decode(COUNT(DISTINCT ash.inst_id), 1, to_char(MAX(ash.inst_id)), 'ALL') inst_id,
       decode(COUNT(DISTINCT ash.module), 1, MAX(nvl ( substr(ash.module,1,instr(ash.module,'@')-1),ash.module) )) MODULE,
       -- decode(COUNT(DISTINCT ash.program), 1, MAX(nvl ( substr(ash.program,1,instr(ash.program,'@')-1),ash.program) )) program,
       -- decode(COUNT(DISTINCT ash.CLIENT_ID), 1, MAX(ash.CLIENT_ID)) CLIENT_ID,
       /* case when ash.module = 'EXTRANET' 
            then substr( decode(COUNT(DISTINCT ash.action), 1, MAX(ash.action)), instr(decode(COUNT(DISTINCT ash.action), 1, MAX(ash.action)),'.',-1) + 1 ) 
            else decode(COUNT(DISTINCT ash.action), 1, MAX(ash.action))
        end action,*/
       decode(COUNT(DISTINCT ash.sql_id), 1, MAX(ash.sql_id)) sql_id,
       decode(COUNT(DISTINCT ash.sql_plan_hash_value), 1, MAX(ash.sql_plan_hash_value)) plan_hash,
       decode(COUNT(DISTINCT ash.session_id), 1, MAX(ash.session_id)) sid,
       decode(COUNT(DISTINCT ash.session_serial#), 1, MAX(ash.session_serial#)) serial#,
       decode(COUNT(DISTINCT nvl(ash.event, ash.session_state)), 1, MAX(nvl(ash.event, ash.session_state))) event,
       -- decode(COUNT(DISTINCT ash.current_obj#), 1, MAX(ao.object_name||';'||ao.object_type ) ) current_obj,
       MIN(to_char(ash.sample_time,'yyyy/mm/dd hh24:mi:ss')) "FROM",
       MAX(to_char(ash.sample_time,'yyyy/mm/dd hh24:mi:ss')) "TO", 
       count(*) active,
       max(sql_exec_id) - min(sql_exec_id) + 1 as number_of_executions,
       max(ash.sample_time) - min(ash.sample_time) as interval,
       to_char(round(COUNT(*)/SUM(COUNT(*)) over()*100))||'%' perc 
        --, to_char(ash.sample_time,'yyyy/mm/dd') as period
  FROM dba_hist_active_sess_history ash, dba_objects ao
 WHERE 1 = 1
   AND ash.current_obj#=ao.object_id(+)  
   -- AND (module like 'int_trans%' or module like 'cg_valide1%' or module like 'bkg_lettr_compt%' or module like 'lst%')
   -- AND ash.module like 'imxbatch_ValidateCessions%'
   -- AND client_id = 'LA25413'
   -- AND ash.program like 'frmweb%'
   -- AND sql_id = '1801pnt85sas8'
   -- AND session_id = 719
   -- AND session_serial# = 5977
   AND ash.sample_time BETWEEN to_date('2023/02/13 08:00:00','yyyy/mm/dd hh24:mi:ss') AND to_date('2023/02/13 09:15:00','yyyy/mm/dd hh24:mi:ss') 
 group by module, sql_id -- , session_id, session_serial# --, sql_exec_id, to_char(sql_exec_start,'hh24:mi:ss'), client_id, action 
          --, to_char(ash.sample_time,'yyyy/mm/dd') 
 order by -- to_char(ash.sample_time,'yyyy/mm/dd'),
           count(*) desc
 fetch first 50 rows only;
