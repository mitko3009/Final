DROP INDEX TEST_DD_INDEX;
CREATE INDEX TEST_DD_INDEX ON MIGRLEAS_SPAC(REFEXT_FIRQ) parallel 4;
ALTER INDEX TEST_DD_INDEX NOPARALLEL;
exec DBMS_STATS.GATHER_INDEX_STATS(ownname => user, indname => 'TEST_DD_INDEX', ESTIMATE_PERCENT => dbms_stats.auto_sample_size, degree => 2, force => true, no_invalidate => false);

