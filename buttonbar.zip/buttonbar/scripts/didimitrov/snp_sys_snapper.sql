col TRACE_TYPE format a15
col PRIMARY_ID format a10
col QUALIFIER_ID1 format a30
col QUALIFIER_ID2 format a13
col WAITS format a5
col BINDS format a5
set serverout on
undef sleeptime
DECLARE
  -- Local variables here
  TYPE typ_sesstat IS TABLE OF v$sysstat%ROWTYPE;
  TYPE typ_statname IS TABLE OF v$statname%ROWTYPE;
  TYPE typ_varchar2_ind_by_varchar2 IS TABLE OF VARCHAR2(100) INDEX BY VARCHAR2(100);
  ECharToNumConversionError EXCEPTION;
  PRAGMA EXCEPTION_INIT(ECharToNumConversionError, -6502);  
  --
  starttime date;
  test number:=0;
  --
  CURSOR cWaitEvent IS  
    SELECT event, total_waits_fg, time_waited_fg, EVENT_ID
      FROM v$system_event
--     where wait_class <> 'Idle'
     ORDER BY EVENT_ID, event;
  type tWaitEvent is table of cWaitEvent%rowtype;
  begWE tWaitEvent;
  endWE tWaitEvent;      
  --
  CURSOR cTimeModel IS select TRIM(t.stat_name_prefix)||t.stat_name stat_name, t.value 
   from ( select 
                case m.stat_name
                 when 'DB time'                                          then '1. '
                 when 'DB CPU'                                           then ' 1.1. '
                 when 'connection management call elapsed time'          then ' 1.2. '
                 when 'sequence load elapsed time'                       then ' 1.3. '
                 when 'sql execute elapsed time'                         then ' 1.4. '
                 when 'parse time elapsed'                               then ' 1.5. '
                 when 'hard parse elapsed time'                          then '  1.5.1. '
                 when 'hard parse (sharing criteria) elapsed time'       then '   1.5.1.1. '
                 when 'hard parse (bind mismatch) elapsed time'          then '    1.5.1.1.1. '
                 when 'failed parse elapsed time'                        then '  1.5.2. '
                 when 'failed parse (out of shared memory) elapsed time' then '   1.5.2.1. '
                 when 'PL/SQL execution elapsed time'                    then ' 1.6. '
                 when 'inbound PL/SQL rpc elapsed time'                  then ' 1.7. '
                 when 'PL/SQL compilation elapsed time'                  then ' 1.8. '
                 when 'Java execution elapsed time'                      then ' 1.9. '
                 when 'repeated bind elapsed time'                       then ' 1.9. '
                 when 'background elapsed time'                          then '2. '
                 when 'background cpu time'                              then ' 2.1. '
                 when 'RMAN cpu time (backup/restore)'                   then '  2.1.1. '
                end stat_name_prefix,
                m.stat_name,
                m.value value
           from v$sys_time_model m
            ) t
  where 1=1
  order by t.value desc ;   
  type tTimeModel is table of cTimeModel%rowtype;
  begTM tTimeModel;
  endTM tTimeModel;      
  CURSOR cOsStats IS 
    (select *
      from v$osstat 
      where cumulative='YES' and stat_name not in ('VM_OUT_BYTES','VM_IN_BYTES')
      );
  type tOsStats is table of cOsStats%rowtype;
  begOS tOsStats;
  endOS tOsStats;  
  
  ---
  i        INTEGER;
  begStat  typ_sesstat;
  endStat  typ_sesstat;
  
--TODO: OSSTAT - cumulative and not cumulative  
--  tbsnap   sys.ku$_parsed_items;
  bufStatName typ_statname;
  statName typ_varchar2_ind_by_varchar2;  
  n NUMBER;
  buff typ_varchar2_ind_by_varchar2;
  cpu_idle_time number;
  cpu_busy_time number;
  /*Print a list of values together with their names*/
  PROCEDURE print(rowCaption in varchar2,listToSortAndPrint IN typ_varchar2_ind_by_varchar2 ) IS
  n VARCHAR2(100);
  BEGIN
    --in an associative array values are automatically sorted by the key.
    n:=listToSortAndPrint.last;
    while n is not null loop
      --remove extra characters at the end. We have added them in order to have multiple statistics with the same value
      if trim(substr(n,2, instr(n,';')-2))<>'0' then 
        begin
          dbms_output.put_line(rowCaption||substr(n,1, instr(n,';')-1)||'  '||statName(listToSortAndPrint(n)));      
        exception
          when NO_DATA_FOUND then
            dbms_output.put_line(rowCaption||substr(n,1, instr(n,';')-1)||'  '||listToSortAndPrint(n));                  
        end;
      end if;
      n:=listToSortAndPrint.prior(n);
    END LOOP;
  END print;
  
BEGIN
  dbms_output.enable(NULL);
  --get names
  SELECT * BULK COLLECT INTO bufStatName FROM v$statname;
  FOR i IN bufStatName.first..bufStatName.last
  LOOP
    statName(bufStatName(i).stat_id):=bufStatName(i).name;    
  END LOOP;
  --before wait OS stat:
  open cOsStats;
  fetch cOsStats bulk collect into begOS;
  close cOsStats;
  --before wait event:
  open cWaitEvent;
  fetch cWaitEvent bulk collect into begWE;
  close cWaitEvent;
  --before wait time model:
  open cTimeModel;
  fetch cTimeModel bulk collect into begTM;
  close cTimeModel;



  --before wait stats:
  SELECT * BULK COLLECT
    INTO begStat
    FROM v$sysstat stat
   WHERE stat.STAT_ID IN
         (SELECT /*+ NO_MERGE*/
           sn.stat_id
            FROM v$statname sn
           WHERE sn.NAME IN
                 ('cleanouts and rollbacks - consistent read gets',
                  'consistent gets',
                  'data blocks consistent reads - undo records applied',
                  'db block changes', 'execute count',
                  'opened cursors current', 'physical read IO requests',
                  'physical read total bytes',
                  'rollback changes - undo records applied', 'DB time',
                  'user commits', 'user rollbacks',
                  'table fetch continued row', 'table fetch by rowid',
                  'table scan rows gotten', 'table scan blocks gotten',
                  'undo change vector size', 'CPU used by this session'))
   ORDER BY stat_id;


  BEGIN
  n:=nvl('&&sleeptime','1');
  dbms_output.put_line('Sleep '||n||' seconds.');
  EXCEPTION WHEN ECharToNumConversionError 
    THEN 
    BEGIN
      n:=0.1;
      dbms_output.put_line('Error during conversion - sleep '||n||' seconds.');
   --   dbms_lock.sleep(n);
    END;
  END;
   
/*   
  --sleep for some time
  BEGIN
  n:=nvl('&&sleeptime','1');
  dbms_lock.sleep(n);
  dbms_output.put_line('Sleep '||n||' seconds.');
  EXCEPTION WHEN ECharToNumConversionError 
    THEN 
    BEGIN
      n:=0.1;
      dbms_output.put_line('Error during conversion - sleep '||n||' seconds.');
      --dbms_lock.sleep(n);
    END;
  END;
*/
starttime:=sysdate;
while (sysdate-starttime)*(24*3600)<=n  loop
dbms_lock.sleep(0.1);
--dbms_output.put_line('sleep');
end loop;

  --after wait stats:
  SELECT * BULK COLLECT
    INTO endStat
    FROM v$sysstat stat
   WHERE stat.stat_id IN
         (SELECT /*+ NO_MERGE*/
           sn.stat_id
            FROM v$statname sn
           WHERE sn.NAME IN
                 ('cleanouts and rollbacks - consistent read gets',
                  'consistent gets',
                  'data blocks consistent reads - undo records applied',
                  'db block changes', 'execute count',
                  'opened cursors current', 'physical read IO requests',
                  'physical read total bytes',
                  'rollback changes - undo records applied', 'DB time',
                  'user commits', 'user rollbacks',
                  'table fetch continued row', 'table fetch by rowid',
                  'table scan rows gotten', 'table scan blocks gotten',
                  'undo change vector size', 'CPU used by this session'))
   ORDER BY stat_id;
  open cTimeModel;
  fetch cTimeModel bulk collect into endTM;
  close cTimeModel; 
  --End wait event:
  open cWaitEvent;
  fetch cWaitEvent bulk collect into endWE;
  close cWaitEvent;
  --end OS statistics:
  open cOsStats;
  fetch cOsStats bulk collect into endOS;
  close cOsStats; 
  
  dbms_output.put_line('System Statistics:');   
  --make diff of the before and after wait stats:
  --we add output to associative array in order to print it sorted - keys of associative array are sorted
  FOR i IN endStat.FIRST .. endStat.LAST
  LOOP
    --add ;i to every row because keys of associative array are unique
    buff('|'||lpad((endstat(i).VALUE - begStat(i).VALUE),30,' ')||';'||i):=endstat(i).stat_id;
    IF endstat(i).stat_id<>begStat(i).stat_id THEN dbms_output.put_line('ERROR Stat order'); END IF;
  END LOOP;
  print('',buff);
  --make diff for wait event:
  dbms_output.put_line('System Wait Event');
  buff.delete;
  FOR i IN endWE.FIRST .. endWE.LAST
  LOOP
    --add ;i to every row because keys of associative array are unique
    buff('|'||lpad((endWE(i).time_waited_fg - begWE(i).time_waited_fg),30,' ')||';'||i):=endWE(i).event;
    IF endWE(i).event<>begWE(i).event THEN dbms_output.put_line('ERROR Event order'); END IF;   
  END LOOP;  
  print('',buff);
  --make diff for time model:
  dbms_output.put_line('System Time Model:');
  buff.delete;
  FOR i IN endTM.FIRST .. endTM.LAST
  LOOP
    --add ;i to every row because keys of associative array are unique
    buff('|'||lpad((endTM(i).VALUE - begTM(i).VALUE),30,' ')||';'||i):=endTM(i).stat_name;
    IF endTM(i).stat_name<>begTM(i).stat_name THEN dbms_output.put_line('ERROR Stat order'); END IF;   
  END LOOP;  
  print('',buff);
  --make diff for OS statistics:
  buff.delete;  
  dbms_output.put_line('OS Statistics:');      
  FOR i IN endOS.FIRST .. endOS.LAST
  LOOP
    --add ;i to every row because keys of associative array are unique
--    buff('|'||lpad((endOS(i).VALUE - begOS(i).VALUE),30,' ')||';'||i):=endOS(i).stat_name;    
    buff('|'||lpad(round((endOS(i).VALUE - begOS(i).VALUE)/100,2),30,' ')||';'||i):=endOS(i).stat_name;
    case endOS(i).stat_name when '                            ' then cpu_idle_time:=(endOS(i).VALUE - begOS(i).VALUE);
    when 'BUSY_TIME' then cpu_busy_time:=(endOS(i).VALUE - begOS(i).VALUE);
    else null;
    end case;
    IF endOS(i).stat_name<>begOS(i).stat_name THEN dbms_output.put_line('ERROR Stat order'); END IF;   
  END LOOP;  
  dbms_output.put_line('|'||lpad((100*round(cpu_idle_time/(cpu_idle_time+cpu_busy_time),2)),29,' ')||'%  IDLE' );
  print('',buff);
  buff.delete;
  dbms_output.put_line('OS Information:');  
  for s in (  
  select --'nvl(' || comments || ',' || stat_name || ')' a
         nvl(comments, stat_name) a
         , value
    from v$osstat
   where cumulative = 'NO'
     and stat_name not like '%TIME'
     and stat_name not like 'TCP%'
     and stat_name <> 'LOAD'
     and stat_name not like 'GLOBAL_SEND_SIZE%'
   order by (case
              when a like '%CPU%' then
               1
              else
               2
            end),
            a
  )
  loop
    dbms_output.put_line('|'||LPAD(S.VALUE,30,' ')||' '||S.A);
  end loop;
END;
/