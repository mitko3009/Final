$IMX_HOME/sysadm/reports/batchreport 3
