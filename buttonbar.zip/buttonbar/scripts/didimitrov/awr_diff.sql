@$RDBMS_HOME/rdbms/admin/awrddrpt.sql
