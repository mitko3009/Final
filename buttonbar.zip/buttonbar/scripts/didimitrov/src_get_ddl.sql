SET LONG 99999                  
SELECT dbms_metadata.get_ddl(  
         upper('&object_type'),
         upper('&object_name'),
         USER                  
       )                       
  FROM dual;                   