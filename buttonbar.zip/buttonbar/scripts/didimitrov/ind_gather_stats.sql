DECLARE 
vcIMXDB VARCHAR2(30); 
vcTABLE_NAME VARCHAR2(30); 
vcVersion varchar2(100);
vcindname VARCHAR2(30):=upper('&INDEX_NAME'); 
lSampleSize VARCHAR2(30) := '&sample_size';
BEGIN
  SELECT version
    INTO vcVersion
    FROM v$instance;
  SELECT owner, TABLE_name INTO vcIMXDB, vcTable_name FROM all_Indexes WHERE index_name=vcIndname;
  dbms_stats.unlock_table_stats(ownname => vcIMXDB,tabname => vcTABLE_NAME); 
  DBMS_STATS.GATHER_INDEX_STATS(ownname => vcIMXDB, indname => vcindname ,
  ESTIMATE_PERCENT => 
    case 
    when lSampleSize is NULL AND vcVersion NOT LIKE '10%' then 
    dbms_stats.auto_sample_size
    when lSampleSize is NULL then 30
    else to_number(lSampleSize) END 
  , degree => dbms_stats.default_degree);  
  dbms_stats.lock_table_stats(ownname => vcIMXDB,tabname => vcTABLE_NAME); 
end; 
/