col columns format a60
col cf format 999
col info format a6
col index_name format a30
SELECT *
  FROM (
        SELECT i.index_name index_name,
               decode(i.status, 'UNUSABLE', 'UNUSBL')
                 ||decode(i.visibility, 'INVISIBLE', 'INVIS')
                 ||decode(i.uniqueness,'UNIQUE','UNIQUE') info,
               i.blevel,
               i.num_rows "ROWS",
               decode(i.distinct_keys,0,0, i.num_rows/i.distinct_keys) "ROWS/KEY",
               i.distinct_keys keys,
               i.leaf_blocks blocks,
               round(i.clustering_factor/greatest(t.blocks,1)) cf,
               avg_data_blocks_per_key "DATAB/KEY",
               avg_leaf_blocks_per_key "LEAFB/KEY",
               i.last_analyzed,
               decode(c.column_position, 1, rtrim(
                 nvl(to_char(e.extension), c.column_name)||','||
                 lead(nvl(to_char(e.extension), c.column_name),1) over(PARTITION BY c.index_name ORDER BY c.column_position)||','||
                 lead(nvl(to_char(e.extension), c.column_name),2) over(PARTITION BY c.index_name ORDER BY c.column_position)||','||
                 lead(nvl(to_char(e.extension), c.column_name),3) over(PARTITION BY c.index_name ORDER BY c.column_position)||','||
                 lead(nvl(to_char(e.extension), c.column_name),4) over(PARTITION BY c.index_name ORDER BY c.column_position)||','||
                 lead(nvl(to_char(e.extension), c.column_name),5) over(PARTITION BY c.index_name ORDER BY c.column_position)||','||
                 lead(nvl(to_char(e.extension), c.column_name),6) over(PARTITION BY c.index_name ORDER BY c.column_position)||','||
                 lead(nvl(to_char(e.extension), c.column_name),7) over(PARTITION BY c.index_name ORDER BY c.column_position)||','||
                 lead(nvl(to_char(e.extension), c.column_name),8) over(PARTITION BY c.index_name ORDER BY c.column_position),
               ',')) columns
          FROM all_tables t, all_indexes i, all_ind_columns c, all_stat_extensions e
         WHERE t.table_name = upper('&table_name')
           AND i.table_name = t.table_name
           AND c.index_name = i.index_name
           AND c.column_name = e.extension_name(+)
           AND c.table_name = e.table_name(+)
           and t.owner = :vcOwner
           and i.owner = t.owner
           and c.index_owner = t.owner
           and c.index_owner = e.owner(+)
       )
 WHERE columns is not null
 ORDER BY columns
;