select 'DROP '||object_type||' '||object_name||';'||
  (select '                   --'||&v_visibility
  from all_indexes i
 where index_name=ao.object_name)  Test_objects_for_dropping from all_objects ao
    where object_name like 'TEST\_GK%' escape '\'
    or object_name like 'TEST\_SSD%' escape '\'
    or object_name like 'TEST\_KV%' escape '\'
    or object_name like 'TEST\_BD%' escape '\'
    or (object_name like 'TEST\_GD%' escape '\'    
    or (object_name like 'TEST\_DI%' escape '\'       
    and object_name <> 'TEST_DIDIER'));
select name, value from v$parameter where name IN ('optimizer_features_enable', 'control_management_pack_access')
union all
select 'IPT_MIN_MAX_SAMPLE', :v_min_pt_sample||' to '||:v_max_pt_sample from dual;
set feedback on termout on
set sqlprompt '&gname> '
set timing on
