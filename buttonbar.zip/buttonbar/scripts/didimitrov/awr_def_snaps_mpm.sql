define group_by=event
define sql_id=""
define sid=""
define event=""
define add_filters=""
define rownum=""
define days_back=""
define begin_snap=""
define end_snap=""
declare
  v_mpm_start_time varchar2(20);
begin
  select to_char(to_date('&&mpm_date', 'yyyymmdd')  +  (
             to_date(tmstmp.value, 'yyyy/mm/dd hh24:mi:ss') 
           - to_date(effdt.value, 'yyyy/mm/dd hh24:mi:ss') 
           - 1
         ),'yyyy/mm/dd hh24:mi:ss') start_time
    into v_mpm_start_time
    from t_ini tmstmp, t_ini effdt
   where tmstmp.program='mpm' 
     and tmstmp.key = 'last_timestamp'
     and effdt.program='mpm' 
     and effdt.key = 'last_effective_date';

  select distinct first_value(snap_id) over (order by end_interval_time desc) 
    into :v_begin_snap 
    from dba_hist_snapshot 
   where end_interval_time < to_date(v_mpm_start_time,'yyyy/mm/dd hh24:mi:ss')
  ;
  select distinct first_value(snap_id) over (order by end_interval_time) 
    into :v_end_snap 
    from dba_hist_snapshot 
   where end_interval_time >= to_date(v_mpm_start_time,'yyyy/mm/dd hh24:mi:ss')+1
  ;
end;
/