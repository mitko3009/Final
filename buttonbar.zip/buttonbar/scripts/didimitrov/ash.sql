@$RDBMS_HOME/rdbms/admin/ashrpti.sql
