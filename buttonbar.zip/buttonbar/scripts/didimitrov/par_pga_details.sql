col name format a30 
SELECT NAME, VALUE/1024/1024 MB FROM v$pgastat;
