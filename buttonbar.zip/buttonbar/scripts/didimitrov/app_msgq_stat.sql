col BEGIN_PERIOD format a20
col END_PERIOD format a20
SELECT to_char(BEGIN_PERIOD,'yyyy/mm/dd hh24:mi') BEGIN_PERIOD, 
       to_char(END_PERIOD,'yyyy/mm/dd hh24:mi') END_PERIOD,
       NB_CALLS_GEN "NEW_CALLS",
       PRTY0, 
       ALL_CALLS - PRTY0, 
       round(PROC_SPEED) "PROC/MIN"
  FROM T_MSGQ_STAT t
 WHERE t.begin_period >= trunc(SYSDATE)-to_number('&days_back')   
 ORDER BY BEGIN_PERIOD
;
