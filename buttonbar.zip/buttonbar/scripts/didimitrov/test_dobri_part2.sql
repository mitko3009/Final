var v_min_pt_sample varchar2(40);
var v_max_pt_sample varchar2(40);
declare
a varchar2(40);
b varchar2(40);
begin
  SELECT TO_CHAR(MIN(a.n),'yyyymmdd hh24:mi') v_min_pt_sample, TO_CHAR(MAX(B.n),'yyyymmdd hh24:mi') v_max_pt_sample
    into a,b
 FROM (SELECT MIN(sample_time) n FROM pt_session_1 UNION SELECT MIN(sample_time) n FROM pt_session_2
      UNION SELECT MIN(sample_time) n FROM pt_session_3 UNION SELECT MIN(sample_time) n FROM pt_session_4
      UNION SELECT MIN(sample_time) n FROM pt_session_5) a,
     (SELECT MAX(sample_time) n FROM pt_session_1 UNION SELECT MAX(sample_time) n FROM pt_session_2
      UNION SELECT MAX(sample_time) n FROM pt_session_3 UNION SELECT MAX(sample_time) n FROM pt_session_4
      UNION SELECT MAX(sample_time) n FROM pt_session_5) b;
:v_min_pt_sample:=a;
:v_max_pt_sample:=b;
end;
/      
col name format a30
col value format a40
col object_name format a30
col object_type format a20
col TEST_OBJECTS_FOR_DROPPING format a60
column v_visibility new_value v_visibility;
set termout off head off
select case when not &_O_RELEASE like '10%'
  then 'decode(i.visibility, ''VISIBLE'', NULL, substr(i.visibility,1,1))'
       else '''''' end v_visibility from dual
;
set head on
