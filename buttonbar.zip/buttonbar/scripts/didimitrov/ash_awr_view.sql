col "FROM" format a20
col "TO" format a20
col event format a25 truncate
col MODULE format a17
col perc format a4
col sid format 99999
col serial# format 9999999
col active format 9999999
col object_name format a30
col sample_time format a25
define order_by="8 desc"
define rownum=""
SELECT *
  FROM (
				SELECT /*+ leading(ash o) use_nl(o) */
				       decode(COUNT(DISTINCT ash.module), 1, MAX(nvl(substr(ash.module,1,instr(ash.module,'@')-1),ash.module))) "module",
				       decode(COUNT(DISTINCT ash.sql_id), 1, MAX(ash.sql_id)) "sql_id",
				       decode(COUNT(DISTINCT ash.session_id), 1, MAX(ash.session_id)) "sid",
				       decode(COUNT(DISTINCT ash.session_serial#), 1, MAX(ash.session_serial#)) "serial#",
				       decode(COUNT(DISTINCT nvl(ash.event, ash.session_state)), 1, MAX(nvl(ash.event, ash.session_state))) "event",
				       to_char(MIN(ash.sample_time),'yyyy/mm/dd hh24:mi:ss') "from",
				       to_char(MAX(ash.sample_time),'yyyy/mm/dd hh24:mi:ss') "to",
				       10*COUNT(*) "active",
				       to_char(round(COUNT(*)/SUM(COUNT(*)) over()*100))||'%' "perc",
				       &&group_by
				  FROM (
                select /*+ no_merge */ ash.* 
                  from dba_hist_active_sess_history ash
                 where ash.dbid = (select dbid from v$database) 
                   and ash.sample_time between to_date('&&from_yyyymmddhh24mi','yyyymmddhh24mi') AND to_date('&&to_yyyymmddhh24mi','yyyymmddhh24mi')  
		               AND 
		               (
						         '&&module' is null 
						         	OR 
						         	upper(ash.module) LIKE upper('%&module%') ESCAPE '\' 
						         	OR 
						         	upper(ash.program) LIKE upper('%&module%') ESCAPE '\'
						         	OR 
						         	upper('&&module') = 'NULL' and ash.module IS NULL
						       )
                   AND ('&&sql_id' IS NULL OR ash.sql_id = '&sql_id')
				           AND ('&&sid' IS NULL OR ash.session_id = '&sid')
				           AND ('&&event' IS NULL OR upper(nvl(ash.event, ash.session_state)) LIKE upper('%&event%') ESCAPE '\')                   
               ) ash, (select /*+ no_merge */ * from all_objects) o, 
               (select /*+ no_merge */ object_name plsql_entry_object_name, procedure_name plsql_entry_procedure_name, object_id, subprogram_id from dba_procedures) plsql_entry, 
               (select /*+ no_merge */ object_name plsql_object_name, procedure_name plsql_procedure_name, object_id, subprogram_id from dba_procedures) plsql_current
				 WHERE 1=1
				   &&add_filters
				   AND o.object_id(+) = ash.current_obj#
           AND plsql_entry.object_id(+) = ash.plsql_entry_object_id
           AND plsql_entry.subprogram_id(+) = ash.plsql_entry_subprogram_id
           AND plsql_current.object_id(+) = ash.plsql_object_id
           AND plsql_current.subprogram_id(+) = ash.plsql_object_id
				 GROUP BY &group_by
				 ORDER BY &order_by
			 )
  WHERE rownum <= to_number(nvl('&&rownum','30'))
;