select status, count(1), sum(bytes)/1024/1024 MB
, decode(status, 'ACTIVE','Undo data that is part of the active transaction.','EXPIRED','Undo data whose age is greater than the undo retention period.','UNEXPIRED','Undo data whose age is less than the undo retention period.') comm
   from dba_undo_extents
   group by status
   ;  