set head off
set lines 32676
column sql_text format a32676
SELECT sql_fulltext||';' sql_text, upper('sql_text_end') FROM gv$sqlarea WHERE sql_id = '&&sql_id'
;
set head on