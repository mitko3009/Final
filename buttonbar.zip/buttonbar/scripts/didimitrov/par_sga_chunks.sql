-- total shared pool memory allocated  
  SELECT ksmchcls, count(ksmchcls), sum(ksmchsiz)/1024, max(ksmchsiz)/1024
    FROM x$ksmsp
GROUP BY ksmchcls;