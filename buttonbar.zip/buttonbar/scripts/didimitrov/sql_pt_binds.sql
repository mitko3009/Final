set serverout on;
declare
  nbPrintSnaps number := nvl('&nb_bind_sets','1');
  nbPrevSnap date;
begin
  dbms_output.enable(null);
  
  for b in (
		SELECT last_captured curr_snap,
		       'var '||substr(name,2)||' '||replace(replace(
		         case 
		           when datatype_string like 'CHAR%' then 'VARCHAR2'||substr(datatype_string,5) 
		           when datatype_string = 'DATE' then 'VARCHAR2(20)'
		           else datatype_string
		         end
		       ,'2000','1000'),'4000','1000')||';' var_decl,
		       'exec '||name||' := '''||value_string||''''||
		       decode(datatype_string,'DATE',' /*to_date('||name||',''mm/dd/yyyy hh24:mi:ss'')'||'*/') var_init
		  FROM (
		        SELECT distinct
		               b.sample_time,
		               dense_rank() over (order by b.sample_time) dense_rank,
		               b.last_captured,
		               case 
                     when REGEXP_COUNT(b.name, '[[:digit:]]', 2) >= 1 and REGEXP_INSTR(b.name, '[[:alpha:]]', 2) = 0
                     then replace(b.name,':',':B')
                     else name
                   end name,
		               decode(value_string,'NULL',null,value_string) value_string,
		               datatype_string
		          FROM pt_sql_bind_capture b
		         WHERE b.sql_id = '&&sql_id'
		           -- AND last_captured > SYSDATE - 12/24
		         ORDER BY last_captured, length(name), name
		       )
		 WHERE dense_rank <= nbPrintSnaps
  )
  loop
    if nbPrevSnap is null or nbPrevSnap != b.curr_snap then
      dbms_output.put_line('');
      dbms_output.put_line(to_char(b.curr_snap,'yyyy/mm/dd hh24:mi:ss'));
      dbms_output.put_line('---------------------');
      nbPrevSnap := b.curr_snap;
    end if;
    
    dbms_output.put_line(b.var_decl);
    dbms_output.put_line(b.var_init);
  end loop;
end;
/