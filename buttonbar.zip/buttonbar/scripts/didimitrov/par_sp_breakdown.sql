SELECT name, bytes/1024/1024 megabytes
  FROM v$sgastat 
 WHERE pool = 'shared pool' 
   AND (bytes > 999999 OR name = 'free memory') 
 ORDER BY bytes DESC;
