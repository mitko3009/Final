select * from dba_enabled_traces;
