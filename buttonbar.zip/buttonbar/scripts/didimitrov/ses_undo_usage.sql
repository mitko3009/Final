col sysdat format a25
col transaction_start format a25
col session_start format a25
select  to_char(sysdate, 'mm/dd/yyyy hh24:mi:ss') sysdat, to_char(tr.start_date, 'mm/dd/yyyy hh24:mi:ss') transaction_start, to_char(se.logon_time, 'mm/dd/yyyy hh24:mi:ss') session_start, se.sid, se.serial#, se.module, tr.start_scn, tr.log_io, tr.phy_io, tr.used_ublk, tr.used_urec, recursive
from
        v$session       se,
        V$transaction   tr
where        
tr.ses_addr = se.saddr
order by start_scn
; 