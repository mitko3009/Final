undef service
undef module
undef start_date
undef end_date
undef analyzed_start_date
undef analyzed_end_date
undef metric
undef value_col_name
undef work_unit
undef date_format
undef rows_for
undef notifications
undef MinTotalValue
undef MinValue
undef MinCoefDev
undef sort_column
undef asc_desc
var service varchar2(32);
var module varchar2(32);
var start_date varchar2(32);
var end_date varchar2(32);
var analyzed_start_date varchar2(32);
var analyzed_end_date varchar2(32);
var metric varchar2(32);
var work_unit varchar2(32);
var date_format varchar2(32);
var rows_for varchar2(32);
var notifications varchar2(32);
var MinTotalValue number;
var MinValue number;
var MinCoefDev number;
var sort_column number;
var asc_desc number;
BEGIN
  SELECT nvl('&service','%'),
         nvl('&module','%'),
         nvl('&start_date',to_char(to_date(i.value, 'yyyy/mm/dd hh24:mi:ss'),'yyyymmdd')),
         nvl('&end_date',to_char(to_date(i.value, 'yyyy/mm/dd hh24:mi:ss'),'yyyymmdd')),
         nvl('&analyzed_start_date',''),
         nvl('&analyzed_end_date',''),
         CASE WHEN '&&metric' IS NULL
                OR '&&metric' NOT IN ( 'All','DB time', 'application wait time','cluster wait time','concurrency wait time',
                                       'db block changes', 'DB CPU', 'execute count', 'opened cursors cumulative',
                                       'parse count (total)', 'parse time elapsed', 'physical reads',
                                       'physical writes', 'redo size', 'session cursor cache hits',
                                       'session logical reads', 'sql execute elapsed time', 'user calls',
                                       'user commits', 'user I/O wait time', 'user rollbacks', 'work units done',
                                       'workarea executions - multipass','workarea executions - onepass', 'workarea executions - optimal',
                                       'application elapsed time', 'max queue wait time','queue wait time' )
              THEN 'DB time'
              ELSE '&&metric'
          END,
         CASE WHEN '&&work_unit' IS NULL
                OR '&&work_unit' NOT IN ('iMX Work units', 'Transactions', 'None')
              THEN 'iMX Work units'
              ELSE '&&work_unit'
          END,
         CASE WHEN '&&date_format' IS NULL
                OR '&&date_format' NOT IN ('Day', 'Week', 'Month', 'Year')
              THEN 'Day'
              ELSE '&&date_format'
          END,
         CASE WHEN '&&rows_for' IS NULL
                OR '&&rows_for' NOT IN ('Modules', 'Services')
              THEN 'Modules'
              ELSE '&&rows_for'
          END,
         CASE WHEN '&&notifications' IS NULL
                OR '&&notifications' NOT IN ('No Matter','Only Sent','Only Not Sent')
              THEN 'No Matter'
              ELSE '&&notifications'
          END,
         CASE WHEN regexp_like('&&MinTotalValue', '^[[:digit:]]+$')
              THEN to_number('&&MinTotalValue')
              ELSE null
          END,
         CASE WHEN regexp_like('&&MinValue', '^[[:digit:]]+$')
              THEN to_number('&&MinValue')
              ELSE null
          END,
         CASE WHEN regexp_like('&&MinCoefDev', '^[[:digit:]]+$')
              THEN to_number('&&MinCoefDev')
              ELSE null
          END,
         CASE WHEN regexp_like('&&sort_column', '^[[:digit:]]+$')
              THEN to_number('&&sort_column')
              ELSE 1
          END,
         CASE WHEN lower('&&asc_desc') = 'asc'
                OR '&&asc_desc' = '0'
              THEN 0
              WHEN lower('&&asc_desc') = 'desc'
                OR '&&asc_desc' = '1'
              THEN 1
              ELSE null
          END
    INTO :service,
         :module,
         :start_date,
         :end_date,
         :analyzed_start_date,
         :analyzed_end_date,
         :metric,
         :work_unit,
         :date_format,
         :rows_for,
         :notifications,
         :MinTotalValue,
         :MinValue,
         :MinCoefDev,
         :sort_column,
         :asc_desc
    FROM t_ini i
   WHERE i.program = 'mpm'
     AND i.key = 'last_effective_date';
END;
/