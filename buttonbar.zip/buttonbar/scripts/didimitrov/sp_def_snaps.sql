column snap_id     format 99999990 heading 'Snap Id';
column snapdat     format a18  heading 'Snap Started' just c;
column startup_time format a18  heading 'Instance Startup';
column lvl         format 99   heading 'Snap|Level';
column begin_time format a20 new_value s_begin_time noprint;
column end_time format a20 new_value s_end_time noprint;
select to_char(s.startup_time,'dd Mon "at" HH24:mi:ss')  startup_time
                 , s.snap_id                                         snap_id
     , to_char(s.snap_time,'dd Mon YYYY HH24:mi') snapdat
from      
stats$snapshot s
order by s.snap_id
/*1*/;

var s_begin_snap number;
var s_end_snap number;
var s_begin_time varchar2(20);
var s_end_time varchar2(20);
BEGIN
  SELECT nvl('&&begin_snap', MIN(snap_id)), nvl('&&end_snap', MAX(snap_id))
    INTO :s_begin_snap, :s_end_snap
    FROM stats$snapshot
  ;
  SELECT to_char(snap_time,'dd Mon YYYY HH24:mi') into :s_begin_time from stats$snapshot where snap_id = :s_begin_snap;
  SELECT to_char(snap_time,'dd Mon YYYY HH24:mi') into :s_end_time from stats$snapshot where snap_id = :s_end_snap;
END;
/
