col column_name format a22 
col table_name format a22 
col constraint_name format a22 
select cons.constraint_type,
       all_cols.owner, all_cols.constraint_name,
       all_cols.table_name,
       all_cols.column_name,
       all_cols.position,
       cons_pk.table_name r_table_name
  from all_cons_columns col
       inner join all_cons_columns all_cols
               on col.owner = all_cols.owner
              and col.constraint_name = all_cols.constraint_name
       inner join all_constraints cons
               on col.owner = cons.owner
              and col.constraint_name = cons.constraint_name
        left join all_constraints cons_pk 
               on cons.r_owner = cons_pk.owner
              and cons.r_constraint_name = cons_pk.constraint_name
 where col.owner = :vcOwner
   and col.table_name = upper('&table_name')
 order by owner, constraint_name, position
 ;