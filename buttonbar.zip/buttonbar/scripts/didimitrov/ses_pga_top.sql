col pid format 9999999999
select * from (
SELECT ROUND((pga_used_mem)/(1024*1024),2) PGA_USED_MB,
spid, pname, serial# FROM v$process order by 1 desc
) where rownum<=30
;
