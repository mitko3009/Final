select module_orig
  from t_module_mapping
 where module like '699264288D62D7CCD8E041A7392BBB6E%'
   and rownum = 1;

select action_orig
  from t_module_mapping
 where action like '6F7CD6C265D991ADD678DE9F8B623A71%'
   and rownum = 1;