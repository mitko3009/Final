-- Doc ID 811106.1
-- Doc ID 1087777.1
-- https://docs.oracle.com/en/database/oracle/oracle-database/19/ccref/CTX_DDL-package.html#GUID-28E079B1-D5CA-4264-B1C0-A1C5CE174C55


set head off
set pagesize 10000
select CTX_REPORT.DESCRIBE_INDEX('G_INDIVIDU_TXT_MULTI') from dual;
select CTX_REPORT.INDEX_SIZE('G_INDIVIDU_TXT_MULTI') from dual;
set head on
set pagesize 200

set serverout on
declare
  x clob := null;
  vcstr VARCHAR2(32000);
  amount number := 32000;
  offset number := 1;
  vcloblength NUMBER;
begin
  ctx_report.index_stats('G_INDIVIDU_TXT_MULTI',x);
  vcloblength := NVL(dbms_lob.getlength(x), 0);
  LOOP
    EXIT WHEN offset > vcloblength;
    dbms_lob.read(x,amount,offset,vcstr);
    dbms_output.put_line(vcstr);
    offset := offset + amount;
  
  END LOOP;
end;
/

exec CTX_DDL.OPTIMIZE_INDEX ( idx_name => 'G_INDIVIDU_TXT_MULTI', optlevel => 'FULL', parallel_degree => 8 );

exec ctx_ddl.OPTIMIZE_INDEX('G_INDIVIDU_TXT_MULTI', 'rebuild');


-- Da vidim dali ima mqsto

SELECT sum(bytes)/1024/1024 as ALL_MB FROM dba_data_files WHERE tablespace_name = 'IMXINDEX';
SELECT sum(bytes)/1024/1024 as USED_MB FROM dba_segments WHERE tablespace_name = 'IMXINDEX';



-- Predi da dopnem index da vidim po kakuv nachin se susdava

SELECT ctx_report.CREATE_INDEX_SCRIPT('G_INDIVIDU_TXT_MULTI') from dual;