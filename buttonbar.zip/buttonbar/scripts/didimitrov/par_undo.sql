show parameter undo

/*
Undo space usage
Unexpired Extents � Undo data whose age is less than the undo retention period.
Expired Extents � Undo data whose age is greater than the undo retention period.
Active Extents � Undo data that is part of the active transaction.
*/

select status, count(1), sum(bytes)/1024/1024 MB
   from dba_undo_extents
   group by status
   ;  