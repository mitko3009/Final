col "FROM" format a30
col "TO" format a30
col event format a30
col MODULE format a25
col perc format a6
col tty for a8
col login_name for a20
col sql_id for a13
col program for a20
col sid for a6
col serial# for a7
col client_id for a12
col number_of_executions for 999999999
SELECT --substr(module,1,3) module,
       decode(COUNT(DISTINCT ash.module), 1, MAX(nvl(substr(ash.module,1,instr(ash.module,'@')-1),ash.module))) module,
       -- decode(COUNT(DISTINCT ash.program), 1, MAX(nvl(substr(ash.program,1,instr(ash.program,'@')-1),ash.program))) program,
       decode(COUNT(DISTINCT nvl(ash.sql_id,'NULL')), 1, MAX(nvl(ash.sql_id,'NULL'))) sql_id,
       decode(COUNT(DISTINCT ash.sql_plan_hash_value), 1, MAX(ash.sql_plan_hash_value)) plan_hash,
       decode(COUNT(DISTINCT nvl(to_char(ash.sid),'NULL') ), 1, MAX(nvl(to_char(ash.sid),'NULL'))) sid,
       decode(COUNT(DISTINCT nvl(to_char(ash.serial#),'NULL') ), 1, MAX(nvl(to_char(ash.serial#),'NULL') )) serial#,
       --- decode(COUNT(DISTINCT ash.client_identifier), 1, MAX(ash.client_identifier)) client_id,
       -- decode(COUNT(DISTINCT ash.TTY), 1, MAX(ash.TTY)) TTY,
       -- decode(COUNT(DISTINCT ash.login_name), 1, MAX(ash.login_name)) login_name,
       /* case when ash.module = 'EXTRANET' 
               then substr( decode(COUNT(DISTINCT ash.action), 1, MAX(ash.action)), instr(decode(COUNT(DISTINCT ash.action), 1, MAX(ash.action)),'.',-1) + 1 ) 
               else decode(COUNT(DISTINCT ash.action), 1, MAX(ash.action))
           end action,*/
       decode(COUNT(DISTINCT nvl(ash.event,'NULL') ), 1, MAX(nvl(ash.event,'NULL') )) event,
       to_char(MIN(ash.sample_time),'yyyy/mm/dd hh24:mi:ss') "FROM",
       to_char(MAX(ash.sample_time),'yyyy/mm/dd hh24:mi:ss') "TO",
       MAX(conf.session_snaps_interval)*COUNT(*) ACTIVE,
       max(sql_exec_id) - min(sql_exec_id) + 1 as number_of_executions,
       to_char(round(COUNT(*)/SUM(COUNT(*)) over()*100))||'%' perc
  FROM (SELECT pts.sid,
               pts.serial#,
               pts.sql_id,
               pts.sql_plan_hash_value,
               pts.module,
               pts.program,
               pts.TTY,
               pts.login_name,
               pts.session_state,
               pts.action,
               pts.sql_exec_id,
               -- pts.client_identifier,
               decode(pts.session_state, 'ON CPU', 'ON CPU', pts.event) event,
               pts.sample_time
          FROM pt_session pts) ash, pt_config conf
 WHERE 1 = 1
   -- AND ash.event like 'enq: TX - row lock contention'
   -- AND ash.module like 'imxbatch_LimitAllocRecalc%'
   -- AND ash.sid = 1451
   -- AND ash.serial# = 43050
    AND ash.sample_time between to_date('2024/09/13 08:40:00', 'yyyy/mm/dd hh24:mi:ss') and to_date('2024/09/13 08:50:00', 'yyyy/mm/dd hh24:mi:ss')
 GROUP BY ash.module, event --, ash.sql_id, sid, serial#
 ORDER BY COUNT(*) DESC
 FETCH FIRST 50 ROWS ONLY;
