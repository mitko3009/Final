column snap_id     format 99999990 heading 'Snap Id';
column snapdat     format a18  heading 'Snap Started' just c;
column startup_time format a18  heading 'Instance Startup';
column lvl         format 99   heading 'Snap|Level';
column begin_time format a20 new_value v_begin_time noprint;
column end_time format a20 new_value v_end_time noprint;
select to_char(s.startup_time,:v_time_format)  startup_time
		 , s.snap_id                                         snap_id
     , to_char(s.end_interval_time,:v_time_format) snapdat
  from dba_hist_snapshot s
 where trunc(s.end_interval_time) >= trunc(sysdate) - to_number(nvl('&&days_back',0))
 order by s.end_interval_time, s.snap_id
/*1*/;

BEGIN
	IF :v_begin_snap IS NOT NULL AND :v_end_snap IS NOT NULL THEN
		RETURN;
	END IF;
	
  SELECT nvl('&&begin_snap', MIN(snap_id)), nvl('&&end_snap', MAX(snap_id))
    INTO :v_begin_snap, :v_end_snap
    FROM dba_hist_snapshot
  ;
  SELECT to_char(min(end_interval_time),:v_time_format) into :v_begin_time from dba_hist_snapshot where snap_id = :v_begin_snap;
  SELECT to_char(min(end_interval_time),:v_time_format) into :v_end_time from dba_hist_snapshot where snap_id = :v_end_snap;
END;
/
