/*
**********************************************************************
**
**   File: tab_stats.sql                                                         
**   $Date: 2016/01/20 09:39:33 $                                                                     
**   $Revision: 1.4 $                                                                 
**   Description: Show the main table statistics for a particular table.
**
**********************************************************************
*/

SELECT tab.blocks, tab.num_rows, tab.avg_row_len,                          
       seg.bytes/1024/1024 MB_As_Is,                                       
       trunc(tab.num_rows*avg_row_len/1024/1024) MB_To_Be,                 
       tab.last_analyzed,                                                  
       tab.sample_size,                                                    
       MODI.inserts,                                                       
       MODI.updates,                                                       
       MODI.deletes,                                                       
       trunc(((MODI.inserts + MODI.updates + MODI.deletes) /               
         decode(tab.num_rows, 0, 1, tab.num_rows) * 100), 2) perc_modified 
  FROM dba_segments seg, all_tables tab, all_tab_modifications MODI   
 WHERE tab.table_name = upper('&table_name')
   AND seg.segment_name = tab.table_name
   AND MODI.table_name(+) = tab.table_name
   and tab.owner = seg.owner
   and modi.table_owner(+)=tab.owner
   and tab.owner = :vcOwner
;