/*
**********************************************************************
**
**   File: sys_fix.sql                                                         
**   $Date: 2017/03/30 14:00:48 $                                                                     
**   $Revision: 1.4 $                                                                 
**   Description: Fix Tables and Indexes degree, rebuild unusable indexes.
**
**********************************************************************
*/

set serverout on;
exec dbms_output.enable(null);

--fix objects with degree >1
BEGIN
  FOR s IN (
    SELECT table_name FROM user_tables WHERE trim(DEGREE) != '1')
  LOOP
    dbms_output.put_line('ALTER TABLE '||s.table_name||' noparallel');
    EXECUTE IMMEDIATE 'ALTER TABLE '||s.table_name||' noparallel';
  END LOOP;
END;
/
 
--fix indexes with degree>1 
BEGIN
  FOR s IN (SELECT index_name FROM user_indexes WHERE trim(DEGREE) !='1' and index_type in ('NORMAL','FUNCTION-BASED NORMAL'))
  LOOP
    dbms_output.put_line('ALTER INDEX '||s.index_name||' noparallel');
    EXECUTE IMMEDIATE 'ALTER INDEX '||s.index_name||' noparallel';
  END LOOP;
END;
/

--rebuild unusable indexes:
DECLARE 
e VARCHAR2(300);
BEGIN
    FOR C1 IN(
      SELECT a.*, ROWNUM r 
      FROM (
        SELECT table_name, index_name
          FROM all_indexes 
         WHERE owner = USER
           AND status<>'VALID'
           and index_type in ('NORMAL','FUNCTION-BASED NORMAL')
         ORDER BY 1,2) a
    )
    LOOP
      e:='ALTER INDEX '||c1.index_name ||' REBUILD';
      dbms_output.put_line(e);
      EXECUTE IMMEDIATE e;
    end loop;  
END;
/

set serverout off;


