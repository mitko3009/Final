/*
**********************************************************************
**
**   File: awr.sql                                                         
**   $Date: 2013/05/15 14:44:55 $                                                                     
**   $Revision: 1.1 $                                                                 
**   Description: Execute the standard script for AWR generation
**
**********************************************************************
*/

@$RDBMS_HOME/rdbms/admin/awrrpt.sql
