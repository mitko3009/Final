/*
**********************************************************************
**
**   File: ses_pend_trans.sql                                                         
**   $Date: 2017/02/09 12:35:53 $                                                                     
**   $Revision: 1.1 $                                                                 
**   Description: Lists currently pending transactions. Shows objects they have locked and the amount of UNDO generated up to the point.
**
**********************************************************************
*/
undef module
undef object_name

col module for a20
col status for a15
col owner for a10
col object_name for a25
col object_type for a20
col "Undo Records" for 99999999
col "Undo Blocks" for 99999999
SELECT s.sid,
       s.serial#,
       nvl ( substr(s.module,1,instr(s.module,'@')-1),s.module) module,
       s.status,
       o.owner,
       o.object_name,
       o.object_type,
       t.used_urec "Undo Records",
       t.used_ublk "Undo Blocks",
       t.start_time
  FROM v$locked_object lo,
       dba_objects o,
       v$transaction t,
       v$session s
 WHERE lo.object_id = o.object_id
   AND lo.xidusn = t.xidusn
   AND lo.xidslot = t.xidslot
   AND t.addr = s.taddr
   AND (   '&&module' is null 
        OR upper(s.module) LIKE upper('%&module%') ESCAPE '\' 
        OR upper(s.program) LIKE upper('%&module%') ESCAPE '\'
        OR upper('&&module') = 'NULL' and s.module IS NULL )
   AND (   '&&object_name' is null 
        OR upper(o.object_name) LIKE upper('%&object_name%') ESCAPE '\' 
        OR upper('&&object_name') = 'NULL' and o.object_name IS NULL )
 ORDER BY t.used_urec desc
;