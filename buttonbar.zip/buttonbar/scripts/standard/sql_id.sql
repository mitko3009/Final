COL SQL_ID FORMAT A20
column sql_text format a165
select distinct sql_id, sql_text
  from v$sql 
 where upper(sql_text) like upper('%&sql_text%') and upper(sql_text) not like '%V$SQL%'
;