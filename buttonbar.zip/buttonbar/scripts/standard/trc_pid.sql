/*
**********************************************************************
**
**   File: trc_pid.sql                                                         
**   $Date: 2013/05/15 14:44:57 $                                                                     
**   $Revision: 1.1 $                                                                 
**   Description: Enable/disable SQL*Trace for a process identified by OS PID using DBMS_SYSTEM.
**
**********************************************************************
*/

undef pid
undef level
accept pid number prompt 'Enter OS pid: '
accept level number prompt 'Enter trace event level (0,1,4,8,12): '

DECLARE 																										                                     
  nSID    NUMBER;                                                                               
  nSerial NUMBER;                                                                               
BEGIN                                                                                           
  SELECT sid, serial#                                                                           
    INTO nSID, nSerial                                                                          
    FROM v$session                                                                              
   WHERE process = '&pid'                                                                      
  ;                                                                                             
                                                                                                
  sys.dbms_system.set_int_param_in_session(nSID, nSerial, 'max_dump_file_size', 500*1024*1024); 
  sys.dbms_system.set_ev(nSID, nSerial, 10046, &level, '');                                     
END;                                                                                            
/

SELECT s.sid,
       s.serial#,
       s.username,
       s.program,
       udd.value||'/'||lower(i.instance_name)||'_ora_'||p.spid||'.trc' trace_filename
  FROM v$session s,
       v$process p,
       v$parameter udd,
       v$instance i
 WHERE p.addr = s.paddr                                                              
   AND s.TYPE != 'BACKGROUND'
   AND s.process = '&pid'
   AND udd.name = 'user_dump_dest'
;
   
undef pid
undef level
