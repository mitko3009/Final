column sql_text format a165
select sql_id, sql_text
  from dba_hist_sqltext
 where upper(sql_text) like upper('%&sql_text%')
;