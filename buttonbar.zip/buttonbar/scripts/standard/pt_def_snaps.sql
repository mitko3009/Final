/*
**********************************************************************
**
**   File: pt_def_snaps.sql                                                         
**   $Date: 2016/02/04 15:09:17 $ 
**   $Revision: 1.4 $                                                                 
**   Description: Interactive script for defining begin/end sample times as bind variables.
**
**********************************************************************
*/

BEGIN
  select nvl('&&begin_time_yyyymmddhhmi', to_char(least(
				   (select nvl(min(sample_time),sysdate-365) from pt_session_1),
				   (select nvl(min(sample_time),sysdate-365) from pt_session_2),
				   (select nvl(min(sample_time),sysdate-365) from pt_session_3),
				   (select nvl(min(sample_time),sysdate-365) from pt_session_4),
				   (select nvl(min(sample_time),sysdate-365) from pt_session_5)
				 ),:v_time_format))
		into :v_begin_time
    from dual;

  select nvl('&&end_time_yyyymmddhhmi', to_char(greatest(
				   (select nvl(max(sample_time),sysdate) from pt_session_1),
				   (select nvl(max(sample_time),sysdate) from pt_session_2),
				   (select nvl(max(sample_time),sysdate) from pt_session_3),
				   (select nvl(max(sample_time),sysdate) from pt_session_4),
				   (select nvl(max(sample_time),sysdate) from pt_session_5)
				 ),:v_time_format))
		into :v_end_time
    from dual; 
END;
/