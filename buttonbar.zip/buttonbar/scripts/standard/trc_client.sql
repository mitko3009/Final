/*
**********************************************************************
**
**   File: trc_module.sql                                                         
**   $Date: 2017/03/22 15:49:47 $                                                                     
**   $Revision: 1.2 $                                                                 
**   Description: Enable/disable SQL tracing for a given client globally. The trace is persistent across instance restart.
**
**********************************************************************
*/

col TRACE_TYPE format a15
col PRIMARY_ID format a10
col QUALIFIER_ID1 format a30
col QUALIFIER_ID2 format a13
col WAITS format a5
col BINDS format a5

SELECT distinct nvl(r.grantee, t.grantee) dbms_monitor_grantee
  FROM dba_tab_privs t, dba_role_privs r
 WHERE t.table_name = 'DBMS_MONITOR'
   AND t.privilege = 'EXECUTE'
   and r.granted_role(+) = t.grantee
;

select * from dba_enabled_traces;

set serverout on
       
DECLARE
  bDisableTrace BOOLEAN := case when upper('&DisableTrace_from_0_to_1_def_0')= '1' then true else false end;  
  vcClientId varchar2(50) := '&client_id';
  bBinds BOOLEAN := case when upper('&Binds_from_0_to_1_default_1')= '0' then false else true end;
  bWaits BOOLEAN := case when upper('&Waits_from_0_to_1_default_1')= '0' then false else true end;    
  vcPlans varchar2(30) := case nvl('&nplanStat_from_0_to_3_def_1','1') when '0' then 'never' when '3' then 'all_executions' when '2' then 'clever' else 'first_execution' end;
  
BEGIN                   
  IF bDisableTrace = false THEN
	  if to_number(substr(&_O_RELEASE,1,8))>=11010000 then     
      if to_number(substr(&_O_RELEASE,1,8))>=11020002 then     
        --not possible to set level 64 with dbms_monitor:
        vcPlans:=(case vcPlans when 'clever'  then 'all_executions' else vcPlans end);
      else
        vcPlans:=(case vcPlans when 'all_executions' then 'all_executions' when 'clever' then 'all_executions' when 'never' then 'never' else 'first_execution' end);
      end if;
--	    dbms_monitor.serv_mod_act_trace_enable('SYS$USERS', vcModule, dbms_monitor.all_actions, bWaits, bBinds, plan_stat=>vcPlans);
--	    dbms_output.put_line('dbms_monitor.client_id_trace_enable('''||vcClientId||''','||(case when bWaits = true then 'TRUE' else 'FALSE' end)||', '||(case when bBinds = true then 'TRUE' else 'FALSE' end)||');');
   	  dbms_monitor.client_id_trace_enable(vcClientId, bWaits, bBinds,vcPlans);
	    dbms_output.put_line('dbms_monitor.client_id_trace_enable('''||vcClientId||''','||(case when bWaits = true then 'TRUE' else 'FALSE' end)||', '||(case when bBinds = true then 'TRUE' else 'FALSE' end)||','''||vcPlans||''');');    
	  else
   	  dbms_monitor.client_id_trace_enable(vcClientId, bWaits, bBinds);
	    dbms_output.put_line('dbms_monitor.client_id_trace_enable('''||vcClientId||''','||(case when bWaits = true then 'TRUE' else 'FALSE' end)||', '||(case when bBinds = true then 'TRUE' else 'FALSE' end)||');');
	  end if;	  
	ELSE
		dbms_monitor.client_id_trace_disable(vcClientId);
		dbms_output.put_line('dbms_monitor.client_id_trace_disable('''||vcClientId||''');');
  END IF;
END;
/

set serverout off

select * from dba_enabled_traces;