SELECT * FROM TABLE(DBMS_XPLAN.display_cursor(
  case 
    when '&prev' is null then null
    else '&sql_id'
  end,
  null,
  case 
    when '&mode' is null then 'RUNSTATS_LAST'
  	else 'ALL ALLSTATS LAST alias +PEEKED_BINDS +outline'
  end
));