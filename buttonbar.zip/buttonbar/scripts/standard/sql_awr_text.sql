set lines 32676
column sql_text format a32676
SELECT sql_text||chr(10)||';' sql_text, upper('sql_text_end') FROM dba_hist_sqltext s, v$database d WHERE sql_id = '&&sql_id' and s.dbid=d.dbid
;