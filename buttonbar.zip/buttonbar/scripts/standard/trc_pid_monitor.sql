undef pid
undef level
accept pid number prompt 'Enter OS pid: '
accept level number prompt 'Enter trace event level (0,1,4,8,12): '                                                                                             
DECLARE                                                                                                                                                                                                                                                                                                                    
  nSID    NUMBER;
  nSerial NUMBER;
BEGIN
  SELECT sid, serial#
    INTO nSID, nSerial
    FROM v$session
   WHERE process = '&&pid'
  ;
                                                                                     
  IF &level > 0 THEN
    dbms_monitor.session_trace_enable(nSID, nSerial,
      waits => case when &level in (8, 12) then TRUE else FALSE end,
      binds => case when &level in (4, 12) then TRUE else FALSE end);
  ELSE                
    dbms_monitor.session_trace_disable(nSID, nSerial);
  END IF;
END;
/

SELECT s.sid,
       s.serial#,
       s.username,
       s.program,
       udd.value||'/'||lower(i.instance_name)||'_ora_'||p.spid||'.trc' trace_filename
  FROM v$session s,
       v$process p,
       v$parameter udd,
       v$instance i
 WHERE p.addr = s.paddr                                                              
   AND s.TYPE != 'BACKGROUND'
   AND s.process = '&pid'
   AND udd.name = 'user_dump_dest'
;
   
undef pid
undef level
