col sql_id format a19;
col max_wait format a9;
col period format a11;
col "ELAP/EXEC" format 9999999.99
column begin_time format a20 new_value v_begin_time noprint;
column end_time format a20 new_value v_end_time noprint;
SELECT *
  FROM (
        SELECT replace(max(s.sql_id)||'('||count(DISTINCT s.sql_id)||')','(1)','') sql_id,
               round(sum(s.elapsed_time)/1000000) elapsed,
               round(greatest(sum(s.application_wait_time), sum(s.concurrency_wait_time), sum(s.cluster_wait_time), sum(s.user_io_wait_time), sum(s.plsql_exec_time), sum(s.java_exec_time), sum(s.cpu_time))/sum(s.elapsed_time)*100)||'% '||
               CASE greatest(sum(s.application_wait_time), sum(s.concurrency_wait_time), sum(s.cluster_wait_time), sum(s.user_io_wait_time), sum(s.plsql_exec_time), sum(s.java_exec_time), sum(s.cpu_time))
                 WHEN sum(s.application_wait_time) THEN 'app'
                 WHEN sum(s.concurrency_wait_time) THEN 'conc'
                 WHEN sum(s.cluster_wait_time) THEN 'clust'
                 WHEN sum(s.user_io_wait_time) THEN 'io'
                 WHEN sum(s.plsql_exec_time) THEN 'plsql'
                 WHEN sum(s.java_exec_time) THEN 'java'
                 WHEN sum(s.cpu_time) THEN 'cpu'
               END max_wait,
               sum(s.buffer_gets) gets,
               sum(s.disk_reads) reads,
               sum(s.rows_processed) "ROWS",
               round(sum(s.elapsed_time)/1000000/greatest(sum(s.executions),1),2) "ELAP/EXEC",
               round(sum(s.buffer_gets)/greatest(sum(s.executions),1)) "GETS/EXEC",
               round(sum(s.disk_reads)/greatest(sum(s.executions),1)) "READS/EXEC",
               round(sum(s.rows_processed)/greatest(sum(s.executions),1)) "ROWS/EXEC",
               sum(s.executions) EXEC,
               min(s.plan_hash_value) plan_hash_value,
               :v_begin_time begin_time,
               :v_end_time end_time,
        			 decode('&&group_by',
                 's', to_char(s.sample_time),
                 'h', to_char(s.sample_time,'hh24:mi'),
                 'd', to_char(s.sample_time,'yyyy/mm/dd'),
                 'w', to_char(s.sample_time,'ww')
               ) period
           FROM pt_sql_metrics_delta s, pt_sql_observed t
          WHERE t.sql_id = s.sql_id
            AND s.sample_time BETWEEN to_date(:v_begin_time,:v_time_format) AND to_date(:v_end_time,:v_time_format)+1/24
            AND ('&&sql_id' is null OR s.sql_id = '&sql_id')
            AND ('&&sql_text' is null OR upper(t.sql_fulltext) LIKE upper('%&sql_text%') ESCAPE '\')
            AND ('&&plan_hash_value' is null OR s.plan_hash_value = '&plan_hash_value')
          GROUP BY decode('&group_by',
                     's', to_char(s.sample_time),
                     'h', to_char(s.sample_time,'hh24:mi'),
                     'd', to_char(s.sample_time,'yyyy/mm/dd'),
                     'w', to_char(s.sample_time,'ww'),
                     'n', null,
                     'id', s.sql_id,
                     decode(s.plan_hash_value, 0, s.sql_id, 1546270724, s.sql_id, s.plan_hash_value)
                   ),
                   decode('&group_by',
		                 's', to_char(s.sample_time),
		                 'h', to_char(s.sample_time,'hh24:mi'),
		                 'd', to_char(s.sample_time,'yyyy/mm/dd'),
		                 'w', to_char(s.sample_time,'ww')
		               )
         HAVING sum(s.elapsed_time) > 0
          ORDER BY decode('&group_by', '', sum(s.elapsed_time), MAX(s.sample_time)-SYSDATE) desc
        )
 WHERE rownum <= to_number(nvl('&&rownum','30'))
;