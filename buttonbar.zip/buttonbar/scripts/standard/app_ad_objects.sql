/*
**********************************************************************
**
**   File: app_ad_objects.sql                                                         
**   $Date: 2013/12/14 13:29:20 $                                                                     
**   $Revision: 1.1 $                                                                 
**   Description: List AD objects information for a particular ETL run.
**
**********************************************************************
*/

 SELECT lo_object_name,
        to_char(lo_load_begin,'dd/mm/yyyy hh24:mi:ss') load_begin,
        to_char(lo_load_end,'dd/mm/yyyy hh24:mi:ss') load_end,
        lo_load_status
   FROM ad_load_objects
  WHERE lo_load_id = &load_id
  ORDER BY lo_load_number
;