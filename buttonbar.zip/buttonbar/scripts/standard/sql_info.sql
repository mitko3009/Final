col program_name format a30
col program_type format a30
col first_load_time format a20
col last_load_time format a20
col module_at_parse_time format a20 truncate

col sensitive format a5
col aware format a5
col shareable format a5

col peeked format a4

column v_sensitive new_value v_sensitive;
select case when not &_O_RELEASE like '10%' 
       then 'is_bind_sensitive as "SENSITIVE", is_bind_aware as "AWARE", is_shareable as "SHAREABLE",  '
       else ' ' end v_sensitive from dual
;
        
SELECT sql_id,
       child_number,  
       &v_sensitive
       s.module module_at_parse_time,
       s.first_load_time,
       s.last_load_time,
       o.object_name program_name,
       o.object_type program_type,
       s.program_line#,
       plan_hash_value 
  FROM v$sql s, all_objects o
 WHERE s.sql_id = '&&sql_id'
   AND o.object_id(+) = s.program_id
;

SELECT child_number,
   peeked, executions, rows_processed, buffer_gets 
FROM v$sql_cs_statistics  
WHERE sql_id = '&sql_id'
ORDER BY child_number;  

SELECT child_number, trim(predicate) AS  predicate, low, high 
FROM v$sql_cs_selectivity   
WHERE sql_id = '&sql_id'
ORDER BY child_number;  

col bucket format a20
SELECT child_number, (case bucket_id when 0 then 'efficient' when 1 then 'inefficient' else 'very inefficient' end) bucket, count 
FROM v$sql_cs_histogram 
WHERE sql_id = '&sql_id' 
ORDER BY child_number, bucket_id; 
  
  