set long 100000
SELECT dbms_sqltune.report_sql_monitor(sql_id => '&&sql_id', session_id => '&&sid', report_level=> 'all') FROM dual;