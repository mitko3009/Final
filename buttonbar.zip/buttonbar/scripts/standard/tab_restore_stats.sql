/*
**********************************************************************
**
**   File: tab_restore_stats.sql                                                         
**   $Date: 2016/01/11 10:55:00 $                                                                     
**   $Revision: 1.1 $                                                                 
**   Description: Restore statistics of a table as of a specified timestamp (yyyymmddhh24). 
**
**********************************************************************
*/

exec DBMS_STATS.RESTORE_TABLE_STATS (user, '&table_name', to_date('&as_of_timestamp_yyyymmddhh24','yyyymmddhh24'), force => TRUE, no_invalidate => case '&invalidate' when 'true' then false else true end);