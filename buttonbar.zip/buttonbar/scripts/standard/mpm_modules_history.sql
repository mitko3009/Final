/*
**********************************************************************
**
**   File: mpm_modules_history.sql
**   $Date: 2018/03/15 10:04:40 $
**   $Revision: 1.1 $
**   Description: The script is called from the "mpm" tab, modules history button.
                  mpm_define_variables.sql is a prerequisite for this script.
                  This script tries to resemble the mpm_html.modules_history web interface in sqlplus environment. 
**
**********************************************************************
*/
column v new_value value_col_name noprint
SELECT CASE WHEN :metric = 'All'
            THEN 'Value'
            WHEN :metric IS NULL
            THEN 'DB time'
            ELSE :metric
        end v
  FROM dual;

column wu new_value work_unit noprint
SELECT :work_unit wu
  FROM dual;

col RID noprint
col WORK_UNIT noprint
col "Service" for a10
col "Module" for a50
col "Start Date" for a20
col "End Date" for a20
col "Analyzed start date" for a20
col "Analyzed end date" for a20
col "Timestamp" for a20
col "Stat Name" for a30
col WORK_UNITS heading '&work_unit' for 999999
col VALUE heading '&value_col_name' for 9999999999
col DATE_FORMAT for a11
col rows_for for a8
col notifications for a14

SELECT TO_CHAR(ROWNUM) RID, 
       NVL(M.WORK_UNIT, 'undefined') WORK_UNIT, 
       MH.SERVICE "Service",
       MH.MODULE "Module",
       to_date(MH.TS,'yyyymmdd') "Timestamp",
       MH.STAT_NAME "Stat Name",
       to_number(MH.WORK_UNITS) WORK_UNITS,
       MH.VALUE,
       AVERAGE "Average",
       STD_DEV "Std Dev",
       COEF_DEV "Coef Dev"
  FROM TABLE (MPM_HTML.V_MPM_STATS( :service,
                                    :module,
                                    :start_date,
                                    :end_date,
                                    :analyzed_start_date,
                                    :analyzed_end_date,
                                    :metric,
                                    :work_unit,
                                    :date_format,
                                    :rows_for,
                                    :MinTotalValue,
                                    :MinValue,
                                    :MinCoefDev,
                                    :sort_column,
                                    :asc_desc ) ) MH, 
       V_MPM_MODULES M
 WHERE MH.MODULE=M.MODULE(+) 
   AND (    :notifications = 'No Matter'
         OR (    EXISTS ( SELECT 1 
                            FROM T_MPM_NOTIFS N, 
                                 T_MPM_NOTIF_DETAILS D, 
                                 V_MPM_NOTIF_RULES R 
                           WHERE N.ID = D.NOTIF_ID 
                             AND N.RULE_ID = R.ID 
                             AND D.SERVICE = MH.SERVICE 
                             AND D.MODULE = MH.MODULE 
                             AND D.TS = MH.TS 
                             AND D.STAT_NAME = MH.STAT_NAME 
                             AND R.WORK_UNITS = :work_unit 
                             AND R.GROUP_PERIOD = :date_format
                             AND R.GROUP_LEVEL = :rows_for ) 
              AND :notifications = 'Only Sent' )
         OR (     NOT EXISTS ( SELECT 1 
                                 FROM T_MPM_NOTIFS N, 
                                      T_MPM_NOTIF_DETAILS D, 
                                      V_MPM_NOTIF_RULES R 
                                WHERE N.ID = D.NOTIF_ID 
                                  AND N.RULE_ID = R.ID 
                                  AND D.SERVICE = MH.SERVICE 
                                  AND D.MODULE = MH.MODULE 
                                  AND D.TS = MH.TS 
                                  AND D.STAT_NAME = MH.STAT_NAME 
                                  AND R.WORK_UNITS = :work_unit 
                                  AND R.GROUP_PERIOD = :date_format
                                  AND R.GROUP_LEVEL = :rows_for ) 
              AND :notifications = 'Only Not Sent' ) )
;