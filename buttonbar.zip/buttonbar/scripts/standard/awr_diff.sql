/*
**********************************************************************
**
**   File: awr_diff.sql                                                         
**   $Date: 2013/07/18 07:54:36 $                                                                     
**   $Revision: 1.1 $                                                                 
**   Description: Execute the standard script for AWR report that compares 2 periods.
**
**********************************************************************
*/

@$RDBMS_HOME/rdbms/admin/awrddrpt.sql