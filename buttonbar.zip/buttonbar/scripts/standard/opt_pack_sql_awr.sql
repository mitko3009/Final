/*
**********************************************************************
**
**   File: opt_pack_sql_awr.sql                                                         
**   $Date: 2016/10/19 14:56:53 $                                                                     
**   $Revision: 1.9 $                                                                 
**   Description: Get everything necessary for creation of an optimization file: get binds, get SQL and output all as an optimization file. Final goal is to automate creation of an optimization file.
**
**********************************************************************
*/

SET serverout ON
set lines 300
DECLARE
  lineLen      number:=250;
  vcSqlText1   VARCHAR2(8001);  
  vcSqlText2   VARCHAR2(8001);  
  vcSqlText3   VARCHAR2(8001);  
  vcSqlText4   VARCHAR2(8001);        
  vcSqlText    VARCHAR2(32767);
  vcHostName   VARCHAR2(100);
  vcSourceName VARCHAR2(100);
  nSourceLine NUMBER;
  vcModule VARCHAR2(40);
  vcTypeWait VARCHAR2(30);
  nElapsedTime NUMBER;
  nTypedWaitTime NUMBER;
  nTypeWaitTime NUMBER;
  nbgets NUMBER;
  nExecutions NUMBER;  
  nPlanHash NUMBER;  
  nReads NUMBER;
  nRows NUMBER;
  nSnapMin NUMBER:=to_number('&begin_snap');
  nSnapMax NUMBER:=to_number('&end_snap');
  vcSqlId VARCHAR2(50):= '&sql_id';
  --SQL ID of the sql before optimization
  vcOldSqlId VARCHAR2(30) := '&old_sql_id';
  --SQL ID of the sql after optimization
  vcNewSqlId VARCHAR2(30) := '&new_sql_id';  
  --print function used for strings longer than 255 characters
  PROCEDURE p(p_string IN VARCHAR2) IS
    l_string varchar2(32767) DEFAULT p_string;    
  BEGIN
    LOOP
      EXIT WHEN l_string IS NULL;
      dbms_output.put_line(substr(l_string, 1, lineLen));
      l_string := substr(l_string, lineLen+1);
    END LOOP;
  END;
  procedure setLen is 
    ver varchar2(30);
  begin
    select substr(version,1,2) into ver from v$instance;
    if ver='10' then 
      lineLen:=250;--765;
    else
      lineLen:=32767/2;
    end if;
  end;  
BEGIN
  --make output buffer large
  dbms_output.enable(NULL);
  setLen;
  dbms_output.put_line('linelen:'||linelen);
  SELECT instance_name||' '||host_name INTO vcHostName FROM v$instance; 
  SELECT instance_name||' - '||vcHostName INTO vcHostName FROM g_etude;
  --get min and max snapshots on the instance if user has not entered some
  IF nSnapMin IS NULL THEN
    SELECT MIN(snap_id)
      INTO nSnapMin
      FROM dba_hist_snapshot;      
  END IF;
  IF nSnapMax IS NULL THEN
    SELECT MAX(snap_id)
      INTO nSnapMax
      FROM dba_hist_snapshot;      
  END IF;
  
--get SQL details
  SELECT MODULE, elapsed, EXEC, wt, max_wait, gets, pl, sreads, sROWS
    INTO vcModule,
         nElapsedTime,       
         nExecutions,
         nTypedWaitTime,
         nTypeWaitTime,
         nbgets,         
         nPlanHash,
         nReads,
         nRows                    
    FROM (
          SELECT --s.sql_id,
                 min(substr(s.module,1,12)) module,
                 round(sum(s.elapsed_time_delta)/1000000,2) elapsed,
                 sum(s.executions_delta) EXEC,            
                 round(greatest(sum(s.apwait_delta), sum(s.ccwait_delta), sum(s.clwait_delta), sum(s.iowait_delta), sum(s.plsexec_time_delta), sum(s.javexec_time_delta), sum(s.cpu_time_delta))) wt,
                 CASE greatest(sum(s.apwait_delta), sum(s.ccwait_delta), sum(s.clwait_delta), sum(s.iowait_delta), sum(s.plsexec_time_delta), sum(s.javexec_time_delta), sum(s.cpu_time_delta)) 
             WHEN sum(s.apwait_delta) THEN
              0
             WHEN sum(s.ccwait_delta) THEN
              1
             WHEN sum(s.clwait_delta) THEN
              2
             WHEN sum(s.iowait_delta) THEN
              3
             WHEN sum(s.plsexec_time_delta) THEN
              4
             WHEN sum(s.javexec_time_delta) THEN
              5
             WHEN sum(s.cpu_time_delta) THEN
              6
                 END max_wait,
                  sum(s.buffer_gets_delta) gets,
                min(s.plan_hash_value) pl,                  
                  sum(s.disk_reads_delta) sreads,
                  sum(s.rows_processed_delta) sROWS
/*                  round(sum(s.elapsed_time_delta)/1000000/greatest(sum(s.executions_delta),1),2) "ELAP/EXEC",
                  round(sum(s.buffer_gets_delta)/greatest(sum(s.executions_delta),1), 2) "GETS/EXEC",
                  round(sum(s.disk_reads_delta)/greatest(sum(s.executions_delta),1), 2) "READS/EXEC",
                  round(sum(s.rows_processed_delta)/greatest(sum(s.executions_delta),1), 2) "ROWS/EXEC",
    */
             FROM dba_hist_sqlstat s, dba_hist_sqltext t
            WHERE t.sql_id = s.sql_id
              AND s.snap_id BETWEEN nSnapMin AND nSnapMax
              AND s.sql_id = vcSqlId
            GROUP BY s.sql_id
                      )
   WHERE rownum <= 1;
  dbms_output.put_line('/********************************************************************************');
  dbms_output.put_line('*********       E-mail subject: ');
  dbms_output.put_line('*********             Instance: ' || vcHostName);
  dbms_output.put_line('*********          Description: ');
  dbms_output.put_line('Problem: ');
  dbms_output.put_line('Slowness has been experienced in '|| vcModule||' module.');
  dbms_output.put_line('Analysis:');
  dbms_output.put_line('SQL '||vcSqlId||' from '||vcSourceName||' is one of the top statements in '||vcModule ||' module.');
  dbms_output.put_line('Execution of SQL '||vcSqlId||' is problematic due to its '
  ||(case when nExecutions>10000 then 'high number of executions: '|| nEXECUTIONS
  when nTypeWaitTime=3 then 'high IO wait time: '||nTypedWaitTime
  when nTypeWaitTime=6 then 'high CPU time: '||nTypedWaitTime
  when nbgets>100000 then 'high number of logical reads: ' ||nbgets END));
  dbms_output.put_line('Suggestions:');
  IF nExecutions>10000 THEN dbms_output.put_line('Could you please check if it is possible to decrease number of executions of the statement?'); 
  END IF;
  
  dbms_output.put_line('*********               SQL_ID: '||vcSqlId);
  dbms_output.put_line('*********      Program/Package: ' || vcSourceName || ' Line: ' || nSourceLine);
  dbms_output.put_line('*********              Request: ');
  dbms_output.put_line('*********               Author: ');
  dbms_output.put_line('********* Received e-mail date: ' ||
                       to_char(SYSDATE, 'dd-mm-yyyy'));
  dbms_output.put_line('*********      Resolution date: ' ||
                       to_char(SYSDATE, 'dd-mm-yyyy'));
  dbms_output.put_line('***********************************************************************************/');
  dbms_output.put(chr(10));
  dbms_output.put_line('/********************************OLD SQL*******************************************/');
  dbms_output.put(chr(10));

 
  dbms_output.put_line(chr(10));
  dbms_output.put_line('set lines 300');
  dbms_output.put_line(chr(10));
  --get bind data for the SQL
  FOR s IN (
SELECT snap_id||', '||begin_interval_time||CHR(10)||'--------------------------------' snap_info,
       'var '||substr(name,2)||' '||replace(
         case 
           when datatype_string like 'CHAR%' 
           then 'VARCHAR2'||substr(datatype_string,5) 
           else datatype_string
         end
       ,'2000','1333')||';'||CHR(10)||
       'exec '||name||' := '''||value_string||''';' decl
  FROM (
        SELECT s.snap_id,
               s.begin_interval_time,
               b.position,
               case 
                 when substr(name,2,1) between '0' and '9'
                 then ':B'||substr(name,2,1)
                 else name
               end name,
               decode(value_string,'NULL',null,value_string) value_string,
               datatype_string
          FROM dba_hist_sqlbind b, dba_hist_snapshot s
         WHERE b.sql_id = vcSqlId
           AND b.snap_id = s.snap_id
           AND s.snap_id BETWEEN nSnapMin AND nSnapMax           
         ORDER BY snap_id, position
       )
 WHERE ROWNUM < 100
                     )
  LOOP
--    dbms_output.put_line(replace(replace(s.decl,'''',''''''),chr(10), ' '));
    dbms_output.put_line(s.snap_info);
    dbms_output.put_line(s.decl);
  END LOOP;
  dbms_output.put_line(chr(10));

  --get sql text
  select /*dbms_lob.substr(sql_text,4000,1) */
       dbms_lob.substr(sql_text,4000,1),
       dbms_lob.substr(sql_text,4000,4001),
       dbms_lob.substr(sql_text,4000,8001),
       dbms_lob.substr(sql_text,4000,12001)       
    INTO vcSqlText1, vcSqlText2, vcSqlText3, vcSqlText4
    from dba_hist_sqltext
   where sql_id = vcSqlId
     AND rownum = 1;   

  vcSqlText:=vcSqlText1||vcSqlText2||vcSqlText3||vcSqlText4;
  p(vcSqlText);
  dbms_output.put_line(';');

  dbms_output.put_line(chr(10));

  dbms_output.put_line('/********************************OLD SQL*******************************************/');

  dbms_output.put_line('/********************************OLD Metrics***************************************/');
  --write statement ot output the plan  
  dbms_output.put_line('SELECT * FROM table(dbms_xplan.display_cursor(vcOldSqlId, NULL ,''RUNSTATS_LAST''));');
  dbms_output.put_line(chr(10));

  dbms_output.put_line('/*');
  dbms_output.put_line(chr(10));
  --write awr metrics for the SQL
  dbms_output.put_line('AWR Metrics:');  
  dbms_output.put_line(
  'SQL_ID        MODULE             ELAPSED     MAX_WAIT         GETS      READS       ROWS    ELAP/EXEC    GETS/EXEC READS/EXEC  ROWS/EXEC      EXEC PLAN_HASH_VALUE');
  dbms_output.put_line(
  '------------- --------------- ---------- ------------ ------------ ---------- ---------- ------------ ------------ ---------- ---------- --------- ---------------'
  );
  dbms_output.put_line(
  vcSqlId||' '||rpad(vcModule,15)||' '||lpad(nElapsedTime,10)||' '||lpad(nTypedWaitTime,12)||' '|| lpad(nbgets,12)||' '||lpad(nReads,10)||' '||lpad(nRows,10)||' '
  ||lpad(round(nElapsedTime/greatest(nExecutions,1),2),12)||' '||lpad(round(nbgets/greatest(nExecutions,1),2),12)
  ||' '||lpad(round(nReads/greatest(nExecutions,1),2),10)||' '
  ||lpad(round(nRows/greatest(nExecutions,1),2),10)||' '||lpad(nExecutions,10)||' '||nPlanHash
  );
  dbms_output.put_line('');
  
  IF vcOldSqlId IS NOT NULL
  THEN
    -- print metrics of the reproduced version of the old SQL
    FOR s IN (SELECT *
                FROM TABLE(DBMS_XPLAN.display_cursor(vcOldSqlId, NULL, 'RUNSTATS_LAST')))
    LOOP
      dbms_output.put_line(s.plan_table_output);
    END LOOP;
  END IF;  
  dbms_output.put_line('');  
  dbms_output.put_line('*/');
  dbms_output.put_line('/********************************OLD Metrics***************************************/');

  dbms_output.put_line('/********************************New SQL*******************************************/');
  IF vcNewSqlId IS NOT NULL
  THEN
    --get sql text
    SELECT dbms_lob.substr(sql_fulltext, 4000, 1)
      INTO vcSqlText
      FROM v$sql
     WHERE sql_id = vcNewSqlId
       AND rownum = 1;
  END IF;
--  dbms_output.put_line(vcSqlText);
  p(vcSqlText);
  dbms_output.put_line(';');

  dbms_output.put_line('');
  dbms_output.put_line('/********************************New SQL*******************************************/');
  dbms_output.put_line('/********************************New Metrics***************************************/');
  dbms_output.put_line('/*');
  IF vcNewSqlId IS NOT NULL
  THEN
    -- print metrics of the proposed version of the old SQL
    FOR s IN (SELECT *
                FROM TABLE(DBMS_XPLAN.display_cursor(vcNewSqlId, NULL, 'RUNSTATS_LAST')))
    LOOP
      dbms_output.put_line(s.plan_table_output);
    END LOOP;
  END IF;
  dbms_output.put_line('');  
  dbms_output.put_line('*/');
  dbms_output.put_line('/********************************New Metrics***************************************/');
  dbms_output.put_line('/********************************Index statistics**********************************/');
  dbms_output.put_line('/*');
  dbms_output.put_line('*/');
  dbms_output.put_line('/********************************Index statistics**********************************/');
  dbms_output.put_line('/********************************Other SQLs****************************************/');
  dbms_output.put_line('/*');
  dbms_output.put_line('*/ ');
  dbms_output.put_line('/********************************Other SQLs****************************************/');
END;
/
SET serverout OFF;
