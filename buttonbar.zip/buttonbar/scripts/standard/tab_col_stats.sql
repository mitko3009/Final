/*
**********************************************************************
**
**   File: tab_col_stats.sql                                                         
**   $Date: 2016/03/07 09:04:20 $                                                                     
**   $Revision: 1.4 $                                                                 
**   Description: Show the main column statistics for a particular table and part of column name.
**
**********************************************************************
*/

/*
Set serverout ON size 100000;                                                      
DECLARE                                                            
  d_low   DATE;                                                    
  d_high  DATE;                                                    
  n_low   NUMBER;                                                  
  n_high  NUMBER;                                                  
  v_low   VARCHAR2(100);                                           
  v_high  VARCHAR2(100);                                           
BEGIN                                                              
  -- get raw values                                                
  FOR col IN (                                                     
    SELECT column_name, low_value, high_value, data_type           
      FROM all_tab_columns                                         
     WHERE table_name = upper('&table_name')                       
       AND column_name LIKE upper('%&column_name%')                
  )                                                                
  LOOP                                                             
    dbms_output.put_line('---------------------------------');     
    dbms_output.put_line('column name : ' || col.column_name);     
    dbms_output.put_line('data type   : ' || col.data_type);       
    -- convert raw to readable values and print them               
    IF col.data_type = 'DATE' THEN                                 
      dbms_stats.convert_raw_value(col.low_value, d_low);          
      dbms_stats.convert_raw_value(col.high_value, d_high);        
      dbms_output.put_line('low value   : '||d_low);               
      dbms_output.put_line('high value  : '||d_high);              
    ELSIF col.data_type = 'NUMBER' THEN                            
      dbms_stats.convert_raw_value(col.low_value, n_low);          
      dbms_stats.convert_raw_value(col.high_value, n_high);        
      dbms_output.put_line('low value   : '||n_low);               
      dbms_output.put_line('high value  : '||n_high);              
    ELSIF col.data_type = 'VARCHAR2' THEN                          
      dbms_stats.convert_raw_value(col.low_value, v_low);          
      dbms_stats.convert_raw_value(col.high_value, v_high);        
      dbms_output.put_line('low value   : '||v_low);               
      dbms_output.put_line('high value  : '||v_high);              
    ELSE                                                           
      dbms_output.put_line('Error: unexpected data type.');        
    END IF;                                                        
  END LOOP;                                                        
  dbms_output.put_line('---------------------------------');       
END;                                                               
/                                                                  
SET serverout OFF;                                                 
undef table_name;                                                  
undef column_name;  
*/

col table_name format a30
col column_name format a30
col histogram format a15
SELECT cs.table_name, cs.column_name, cs.num_distinct, cs.density, 
       cs.num_nulls, cs.histogram, cs.last_analyzed, cs.sample_size
  FROM all_tab_col_statistics cs                                   
 WHERE cs.table_name = upper('&table_name')                       
   AND cs.column_name LIKE upper('%&column_name%')                
   AND cs.owner = :vcOwner
 ORDER BY cs.table_name, cs.column_name                            
;                                               