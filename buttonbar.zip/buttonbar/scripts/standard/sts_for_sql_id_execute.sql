/*
**********************************************************************
**
**   File: ind_create.sql                                                         
**   $Date: 2013/12/16 12:16:30 $                                                                     
**   $Revision: 1.2 $                                                                 
**   Description: Create a test index with "test_pt_" prefix.
**
**********************************************************************
*/

SET serverout ON
DECLARE
  res VARCHAR2(100); 
  cur dbms_sqltune.sqlset_cursor;
  my_sql_id VARCHAR2(30):='&sql_id';
BEGIN
  BEGIN
    dbms_sqltune.drop_tuning_task('kv_task2');
  EXCEPTION WHEN OTHERS THEN dbms_output.put_line('not dropped task');
  END;
  BEGIN
    dbms_sqltune.drop_sqlset('kv_test1');
  EXCEPTION WHEN OTHERS THEN dbms_output.put_line('not dropped set');
  END;
--create sqlset
  dbms_sqltune.create_sqlset(sqlset_name => 'kv_test1'); 
--load an sqlset with statements
  OPEN cur FOR 
    SELECT VALUE(p)
      FROM TABLE(dbms_sqltune.select_cursor_cache('sql_id='''||my_sql_id||''''))p;
  dbms_sqltune.load_sqlset(sqlset_name => 'kv_test1',populate_cursor => cur);
--create tuning task
  res := dbms_sqltune.create_tuning_task(sqlset_name => 'kv_test1', time_limit => 300, task_name => 'kv_task2'); 
  dbms_output.put_line('res:' || res); 
--execute tuning task  
  dbms_sqltune.execute_tuning_task(task_name => 'kv_task2'); 
END; 
/
