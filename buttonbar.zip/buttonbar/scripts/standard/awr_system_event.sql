/*
**********************************************************************
**
**   File: awr_system_event.sql                                                         
**   $Date: 2016/01/20 07:42:09 $
**   $Revision: 1.1 $
**   Description: Shows the top 5 wait events on system level for a predifined period.
**
**********************************************************************
*/

var top_n_evt number;
exec :top_n_evt := 5;
var dbtime number;
var dbcpu number;

begin
  with stm as (
   select b.stat_name, (b.value - a.value) as value_in_sec
     from dba_hist_sys_time_model a,
          dba_hist_sys_time_model b
     where a.snap_id = :v_begin_snap
       and b.snap_id = :v_end_snap
       and a.stat_id = b.stat_id
       and b.stat_name IN ('DB time','DB CPU')
       and b.value - a.value > 0
     group by b.stat_name, b.value, a.value
  )
   SELECT dbtime.value_in_sec, dbcpu.value_in_sec
     INTO :dbtime, :dbcpu 
     FROM stm dbtime, stm dbcpu
    WHERE dbtime.stat_name='DB time' 
      AND dbcpu.stat_name='DB CPU'
  ;
end;
/

col event format a25 truncate
col perc format a4
col wait_class format a20            
select event
     , wtfg waits
     , round(tmfg/1000000) time
     , round(decode(wtfg, 0, to_number(null), tmfg/wtfg)/1000)  average_wait
     , round(decode(:dbtime, 0, to_number(null), tmfg/:dbtime)*100)||'%'   perc
     , wcls wait_class
  from (
   select event, wtfg, ttofg, tmfg, wcls
     from (
      select e.event_name                                      event
           , case when e.total_waits_fg is not null
                  then e.total_waits_fg - nvl(b.total_waits_fg,0)
                  else (e.total_waits - nvl(b.total_waits,0))
                        - greatest(0,(nvl(ebg.total_waits,0)
                                  - nvl(bbg.total_waits,0)))
             end                                               wtfg
           , case when e.total_timeouts_fg is not null
                  then e.total_timeouts_fg - nvl(b.total_timeouts_fg,0)
                  else (e.total_timeouts - nvl(b.total_timeouts,0))
                        - greatest(0,(nvl(ebg.total_timeouts,0)
                                  - nvl(bbg.total_timeouts,0)))
             end                                              ttofg
           , case when e.time_waited_micro_fg is not null
                  then e.time_waited_micro_fg - nvl(b.time_waited_micro_fg,0)
                  else (e.time_waited_micro - nvl(b.time_waited_micro,0))
                        - greatest(0,(nvl(ebg.time_waited_micro,0)
                                  - nvl(bbg.time_waited_micro,0)))
             end                                              tmfg
           , e.wait_class                                     wcls
        from dba_hist_system_event b
           , dba_hist_system_event e
           , dba_hist_bg_event_summary bbg
           , dba_hist_bg_event_summary ebg
       where b.snap_id  (+) = :v_begin_snap
         and e.snap_id      = :v_end_snap
         and bbg.snap_id (+) = :v_begin_snap
         and ebg.snap_id (+) = :v_end_snap
         and e.dbid            = b.dbid (+)
         and e.instance_number = b.instance_number (+)
         and e.event_id        = b.event_id (+)
         and e.dbid            = ebg.dbid (+)
         and e.instance_number = ebg.instance_number (+)
         and e.event_id        = ebg.event_id (+)
         and e.dbid            = bbg.dbid (+)
         and e.instance_number = bbg.instance_number (+)
         and e.event_id        = bbg.event_id (+)
         and e.total_waits     > nvl(b.total_waits,0)
         and e.wait_class     <> 'Idle'
      union all
      select 'DB CPU'                   event
           , to_number(null)              wtfg
           , to_number(null)              ttofg
           , :dbcpu                        tmfg
           , ' '                        wcls
        from dual
       where :dbcpu > 0)
    order by tmfg desc, wtfg desc)
 where rownum <= :top_n_evt
 ;