/*
**********************************************************************
**
**   File: par_memory.sql                                                         
**   $Date: 2014/10/17 09:31:49 $                                                                     
**   $Revision: 1.1 $                                                                 
**   Description: Show memory parameters.
**
**********************************************************************
*/

column value format a8;
column name format a20
column component format a20

column v_dynamic_components new_value v_dynamic_components;

select case 
         when &_O_RELEASE like '10%' then 'v$sga_dynamic_components'
         else 'v$memory_dynamic_components'
       end v_dynamic_components
  from dual
;

select name, lpad(display_value,8,' ') value from v$parameter where name IN (
        'memory_max_target',
        'memory_target',
        'sga_max_size',
        'sga_target',
        'shared_pool_size',
        'db_cache_size',
        'db_keep_cache_size',
        'db_recycle_cache_size',
        'pga_aggregate_target'
       ) and value <> '0' order by value desc;

select component, lpad(round(current_size/1024/1024)||'M',8,' ') value from &v_dynamic_components where round(current_size/1024/1024) > 0 order by current_size desc;