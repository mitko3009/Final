undef sql_id
undef begin_snap
undef end_snap
undef days_back