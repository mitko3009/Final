/*
**********************************************************************
** 
**   File: sys_binds_usage.sql                                                         
**   $Date: 2014/04/24 06:18:38 $                                                                     
**   $Revision: 1.1 $                                                                 
**   Description: Finds the biggest groups of similar SQLs in the shared pool.
**
**********************************************************************
*/

column perc format a5
SELECT CASE 
         WHEN MODULE LIKE 'msg\_q%' ESCAPE '\' 
         THEN 'msg_queue' 
         ELSE MODULE 
       END                             			MODULE,
       COUNT(*)                        			COUNT,
       trunc(COUNT(*)/total.count*100)||'%' PERC,
       v.PERSISTENT_MEM,
       v.PLAN_HASH_VALUE,
       MIN(v.SQL_ID)												SAMPLE_ID,
       MIN(v.SQL_TEXT)                 			SAMPLE_TEXT
  FROM v$sql v,
       (
         SELECT COUNT(*) COUNT FROM v$sql
       ) total
 GROUP BY
       v.PERSISTENT_MEM,
       v.PLAN_HASH_VALUE,
       substr(v.SQL_TEXT,1,30),
       CASE 
         WHEN MODULE LIKE 'msg\_q%' ESCAPE '\' 
         THEN 'msg_queue' 
         ELSE MODULE 
       END,
       total.count
HAVING trunc(COUNT(*)/total.count*100) > 0
 ORDER BY COUNT(*) DESC
 ;