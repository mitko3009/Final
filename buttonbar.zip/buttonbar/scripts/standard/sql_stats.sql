col module format a17
col sql_id format a19
col max_wait format a9
col "ELAP/EXEC" format 9999999.99
SELECT * 
  FROM (
				SELECT decode(COUNT(DISTINCT s.inst_id), 1, to_char(MAX(s.inst_id)), 'ALL') inst_id,
				       replace(max(s.sql_id)||'('||count(DISTINCT s.sql_id)||')','(1)','') sql_id,
				       replace(max(nvl(substr(s.module,1,instr(s.module,'@')-1),s.module))||'('||greatest(COUNT(DISTINCT MODULE),1)||')','(1)','') module,
				       round(sum(s.elapsed_time)/1000000) elapsed,
				       round(greatest(sum(application_wait_time), sum(concurrency_wait_time), sum(cluster_wait_time), sum(user_io_wait_time), sum(plsql_exec_time), sum(java_exec_time), sum(cpu_time))/sum(s.elapsed_time)*100)||'% '||
               CASE greatest(sum(application_wait_time), sum(concurrency_wait_time), sum(cluster_wait_time), sum(user_io_wait_time), sum(plsql_exec_time), sum(java_exec_time), sum(cpu_time))
                 WHEN sum(application_wait_time) THEN 'app'
                 WHEN sum(concurrency_wait_time) THEN 'conc'
                 WHEN sum(cluster_wait_time) THEN 'clust'
                 WHEN sum(user_io_wait_time) THEN 'io'
                 WHEN sum(plsql_exec_time) THEN 'plsql'
                 WHEN sum(java_exec_time) THEN 'java'
                 WHEN sum(cpu_time) THEN 'cpu'
               END max_wait,
               sum(s.buffer_gets) gets,
				       sum(s.disk_reads) reads,
				       sum(s.rows_processed) "ROWS",
				       round(sum(elapsed_time)/1000000/greatest(sum(executions),1),2) "ELAP/EXEC",
				       round(sum(buffer_gets)/greatest(sum(executions),1), 2) "GETS/EXEC",
				       round(sum(disk_reads)/greatest(sum(executions),1), 2) "READS/EXEC",
				       round(sum(rows_processed)/greatest(sum(executions),1), 2) "ROWS/EXEC",
				       sum(s.executions) EXEC,
               min(s.plan_hash_value) plan_hash_value
				  FROM gv$sql s
				 WHERE ('&&sql_id' is null OR sql_id = '&sql_id')
				   AND ('&&sql_text' is null OR upper(s.sql_text) LIKE upper('%&sql_text%') ESCAPE '\')
				   AND ('&&module' is null OR upper(s.module) LIKE upper('%&module%') ESCAPE '\')
				   AND ( nvl('&&inst_id','ALL') = 'ALL' OR to_char(s.inst_id) = '&&inst_id' )
				 GROUP BY inst_id, decode(s.plan_hash_value, 0, s.sql_id, s.plan_hash_value)
				HAVING sum(s.elapsed_time) > 0
				 ORDER BY inst_id, sum(s.elapsed_time) DESC
			 )
 WHERE rownum <= 30
;