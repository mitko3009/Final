undef days_back
undef begin_snap
undef end_snap
undef begin_time
undef end_time
undef begin_time_yyyymmddhhmi
undef end_time_yyyymmddhhmi
undef mpm_date