col module format a17 truncate
col sql_id format a19;
col max_wait format a9;
col period format a11;
col "ELAP/EXEC" format 9999999.99
TTITLE left "Analyzed from '" v_begin_time "' to '" v_end_time "'" SKIP 1 center ''
SELECT *
  FROM (
        SELECT replace(max(s.sql_id)||'('||count(DISTINCT s.sql_id)||')','(1)','') sql_id,
               replace(max(nvl(substr(s.module,1,instr(s.module,'@')-1),s.module))||'('||greatest(COUNT(DISTINCT MODULE),1)||')','(1)','') module,
               round(sum(s.elapsed_time_delta)/1000000) elapsed,
               round(greatest(sum(s.apwait_delta), sum(s.ccwait_delta), sum(s.clwait_delta), sum(s.iowait_delta), sum(s.plsexec_time_delta), sum(s.javexec_time_delta), sum(s.cpu_time_delta))/sum(s.elapsed_time_delta)*100)||'% '||
               CASE greatest(sum(s.apwait_delta), sum(s.ccwait_delta), sum(s.clwait_delta), sum(s.iowait_delta), sum(s.plsexec_time_delta), sum(s.javexec_time_delta), sum(s.cpu_time_delta))
                 WHEN sum(s.apwait_delta) THEN 'app'
                 WHEN sum(s.ccwait_delta) THEN 'conc'
                 WHEN sum(s.clwait_delta) THEN 'clust'
                 WHEN sum(s.iowait_delta) THEN 'io'
                 WHEN sum(s.plsexec_time_delta) THEN 'plsql'
                 WHEN sum(s.javexec_time_delta) THEN 'java'
                 WHEN sum(s.cpu_time_delta) THEN 'cpu'
               END max_wait,
               sum(s.buffer_gets_delta) gets,
               sum(s.disk_reads_delta) reads,
               sum(s.rows_processed_delta) "ROWS",
               round(sum(s.elapsed_time_delta)/1000000/greatest(sum(s.executions_delta),1),2) "ELAP/EXEC",
               round(sum(s.buffer_gets_delta)/greatest(sum(s.executions_delta),1)) "GETS/EXEC",
               round(sum(s.disk_reads_delta)/greatest(sum(s.executions_delta),1)) "READS/EXEC",
               round(sum(s.rows_processed_delta)/greatest(sum(s.executions_delta),1)) "ROWS/EXEC",
               sum(s.executions_delta) EXEC,
               min(s.plan_hash_value) plan_hash_value,
               :v_begin_time begin_time,
               :v_end_time end_time,
        			 decode('&&group_by',
                 's', to_char(snap.snap_id),
                 'h', to_char(snap.begin_interval_time,'hh24:mi'),
                 'd', to_char(snap.begin_interval_time,'yyyy/mm/dd'),
                 'w', to_char(snap.begin_interval_time,'ww')
               ) period
           FROM dba_hist_sqlstat s, dba_hist_sqltext t, dba_hist_snapshot snap
          WHERE t.sql_id = s.sql_id
            AND s.snap_id BETWEEN :v_begin_snap AND :v_end_snap
            AND ('&&sql_id' is null OR s.sql_id = '&sql_id')
            AND ('&&sql_text' is null OR upper(t.sql_text) LIKE upper('%&sql_text%') ESCAPE '\')
            AND ('&&module' is null OR upper(s.module) LIKE upper('%&module%') ESCAPE '\')
            AND ('&&plan_hash_value' is null OR s.plan_hash_value = '&plan_hash_value')
            AND snap.snap_id = s.snap_id
          GROUP BY decode('&group_by',
                     's', to_char(snap.snap_id),
                     'h', to_char(snap.begin_interval_time,'hh24:mi'),
                     'd', to_char(snap.begin_interval_time,'yyyy/mm/dd'),
                     'w', to_char(snap.begin_interval_time,'ww'),
                     'n', null,
                     'id', s.sql_id,
                     decode(s.plan_hash_value, 0, s.sql_id, 1546270724, s.sql_id, s.plan_hash_value)
                   ),
                   decode('&group_by',
		                 's', to_char(snap.snap_id),
		                 'h', to_char(snap.begin_interval_time,'hh24:mi'),
		                 'd', to_char(snap.begin_interval_time,'yyyy/mm/dd'),
		                 'w', to_char(snap.begin_interval_time,'ww')
		               )
         HAVING sum(s.elapsed_time_delta) > 0
          ORDER BY decode('&group_by', '', sum(s.elapsed_time_delta), MAX(s.snap_id)) desc
        )
 WHERE rownum <= to_number(nvl('&&rownum','30'))
;