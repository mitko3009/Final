/*
**********************************************************************
**
**   File: ses_kill.sql                                                         
**   $Date: 2013/07/16 08:40:00 $                                                                     
**   $Revision: 1.1 $                                                                 
**   Description: Kill a session identified by (sid, serial#)
**
**********************************************************************
*/

undef sid
undef serial#
ALTER SYSTEM KILL SESSION '&sid,&serial';