SELECT tf.plan_table_output
  FROM TABLE(dbms_xplan.display_awr('&&sql_id',NULL,NULL, case 
			   when '&mode' is null then 'TYPICAL'
			 	 else 'ALL ALLSTATS LAST alias +PEEKED_BINDS +outline'
			 end)) tf
;