/*
**********************************************************************
**
**   File: awr_snapshots.sql                                                         
**   $Date: 2013/12/14 13:09:28 $                                                                     
**   $Revision: 1.2 $                                                                 
**   Description: List the AWR snapshots in a format similar to the standard AWR script.
**
**********************************************************************
*/

column snap_id     format 99999990 heading 'Snap Id';
column snapdat     format a18  heading 'Snap Started' just c;
column startup_time format a18  heading 'Instance Startup';
column lvl         format 99   heading 'Snap|Level';

select to_char(s.startup_time,'dd Mon "at" HH24:mi:ss')  startup_time
		 , s.snap_id                                         snap_id
     , to_char(s.end_interval_time,'dd Mon YYYY HH24:mi') snapdat
  from dba_hist_snapshot s
 where trunc(s.end_interval_time) = trunc(sysdate) - to_number(nvl('&days_back',0))
 order by s.startup_time, s.snap_id
 ;