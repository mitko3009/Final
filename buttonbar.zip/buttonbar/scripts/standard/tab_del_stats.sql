/*
**********************************************************************
**
**   File: tab_del_stats.sql                                                         
**   $Date: 2013/07/09 09:14:09 $                                                                     
**   $Revision: 1.2 $                                                                 
**   Description: Delete the statistics of a table.
**
**********************************************************************
*/

DECLARE
  lTableName VARCHAR2(30) := upper('&table_name');
BEGIN
  dbms_stats.unlock_table_stats(ownname => USER, tabname => lTableName);
  dbms_stats.delete_table_stats(ownname => USER, tabname => lTableName);
  dbms_stats.lock_table_stats(ownname => USER, tabname => lTableName);
END;
/