col "FROM" format a20
col "TO" format a20
col event format a25 truncate
col MODULE format a17 truncate
col perc format a4
col sid format a5
col serial# format a7
col active format 9999999
col object_name format a30
col sample_time format a25
col tty format a8
col sql_id format a13
col login_name format a17
col v_pt_col_list new_value v_pt_col_list;
SELECT LTRIM(MAX(SYS_CONNECT_BY_PATH(column_name,','))
       KEEP (DENSE_RANK LAST ORDER BY curr),',') AS v_pt_col_list
FROM   (
        SELECT column_name, 
               row_number() over (order by column_id) AS curr,
               row_number() over (order by column_id) - 1 AS prev
          FROM all_tab_columns
         WHERE table_name = 'PT_SESSION'
           AND column_name <> 'EVENT'
        )
CONNECT BY prev = PRIOR curr
START WITH curr = 1;

define order_by="8 desc"

SELECT *
  FROM (
         SELECT decode(COUNT(DISTINCT nvl(ash.module,'NULL')), 1, MAX(nvl(substr(nvl(ash.module,'NULL'),1,instr(ash.module,'@')-1),nvl(ash.module,'NULL')))) "module",
                decode(COUNT(DISTINCT nvl(ash.sql_id,'NULL')), 1, MAX(nvl(ash.sql_id,'NULL'))) "sql_id",
                decode(COUNT(DISTINCT nvl(to_char(ash.sid),'NULL') ), 1, MAX(nvl(to_char(ash.sid),'NULL'))) "sid",
                decode(COUNT(DISTINCT nvl(to_char(ash.serial#),'NULL') ), 1, MAX(nvl(to_char(ash.serial#),'NULL') )) "serial#",
                decode(COUNT(DISTINCT nvl(ash.event,'NULL') ), 1, MAX(nvl(ash.event,'NULL') )) "event",
                to_char(MIN(ash.sample_time),'yyyy/mm/dd hh24:mi:ss') "from",
                to_char(MAX(ash.sample_time),'yyyy/mm/dd hh24:mi:ss') "to",
                MAX(conf.session_snaps_interval)*COUNT(*) "active",
                to_char(round(COUNT(*)/SUM(COUNT(*)) over()*100))||'%' "perc",
                &&group_by
           FROM (SELECT decode(pts.session_state, 'ON CPU', 'ON CPU', pts.event) event, &v_pt_col_list FROM pt_session pts) ash, 
                pt_config conf
          WHERE 
                (
                  '&&module' is null
                   OR
                   upper(ash.module) LIKE upper('%&module%') ESCAPE '\'
                   OR
                   upper(ash.program) LIKE upper('%&module%') ESCAPE '\'
                   OR
				         	 upper('&&module') = 'NULL' and ash.module IS NULL
                )
            AND ('&&sql_id' IS NULL OR ash.sql_id = '&sql_id')
            AND ('&&sid' IS NULL OR ash.sid = '&sid')
            and ('&&pid' IS NULL OR ash.process = '&pid')
            AND ('&&event' IS NULL OR upper(nvl(ash.event, ash.session_state)) LIKE upper('%&event%') ESCAPE '\')
            AND ('&&login_name' IS NULL OR tty = upper('&login_name') OR upper(login_name) = upper('&login_name'))
            AND ash.sample_time between to_date('&&begin_time','yyyymmddhh24mi') and to_date('&&end_time','yyyymmddhh24mi')
            &&add_filters
          GROUP BY &group_by
          ORDER BY &order_by
                    )
  WHERE rownum <= to_number(nvl('&&rownum','30'))
;
