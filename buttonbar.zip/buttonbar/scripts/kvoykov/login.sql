set lines 450 pages 9999 long 99999 longchunksize 99999 sqlblanklines on
column global_name new_value gname
set termout off head off
column show_rac_instance_id new_value is_inst_id_shown
select case value when 'TRUE' then 'for a7' else 'noprint' end show_rac_instance_id 
  from v$parameter where name = 'cluster_database';
col inst_id &is_inst_id_shown
define gname=idle
column global_name new_value gname
select lower(user) || '@' || sys_context('USERENV', 'INSTANCE_NAME')
      ||'@'||userenv('sid') global_name 
  from dual;
exec dbms_application_info.set_module('pt',null);
var vcOwner varchar2(30);
exec SELECT t.owner INTO :vcOwner FROM all_tables t WHERE t.table_name = 'G_ETUDE';
var v_begin_snap number;
var v_end_snap number;
var v_begin_time varchar2(20);
var v_end_time varchar2(20);
var v_time_format varchar2(20);
exec :v_time_format := 'yyyymmddhh24mi';
alter session set statistics_level=all;
var v_min_pt_sample varchar2(40);
var v_max_pt_sample varchar2(40);
declare 
a varchar2(40); 
b varchar2(40);
begin 
  SELECT TO_CHAR(MIN(a.n),'yyyymmdd hh24:mi') v_min_pt_sample, TO_CHAR(MAX(B.n),'yyyymmdd hh24:mi') v_max_pt_sample
    into a,b
 FROM (SELECT MIN(sample_time) n FROM pt_session_1 UNION SELECT MIN(sample_time) n FROM pt_session_2 
      UNION SELECT MIN(sample_time) n FROM pt_session_3 UNION SELECT MIN(sample_time) n FROM pt_session_4
      UNION SELECT MIN(sample_time) n FROM pt_session_5) a, 
     (SELECT MAX(sample_time) n FROM pt_session_1 UNION SELECT MAX(sample_time) n FROM pt_session_2
      UNION SELECT MAX(sample_time) n FROM pt_session_3 UNION SELECT MAX(sample_time) n FROM pt_session_4
      UNION SELECT MAX(sample_time) n FROM pt_session_5) b;
:v_min_pt_sample:=a;
:v_max_pt_sample:=b;
end;
/      
col name format a30
col value format a40
col object_name format a30
col object_type format a20
col TEST_OBJECTS_FOR_DROPPING format a60
column v_visibility new_value v_visibility;
set termout off head off
select case when not &_O_RELEASE like '10%' 
  then 'decode(i.visibility, ''VISIBLE'', NULL, substr(i.visibility,1,1))'
       else '''''' end v_visibility from dual
;
set head on
select 'DROP '||object_type||' '||object_name||';'||
  (select '                   --'||&v_visibility 
  from all_indexes i 
 where index_name=ao.object_name)  Test_objects_for_dropping from all_objects ao 
	where object_name like 'TEST\_GK%' escape '\' 
	or object_name like 'TEST\_SSD%' escape '\' 
	or object_name like 'TEST\_KV%' escape '\' 
	or object_name like 'TEST\_BD%' escape '\' 
	or (object_name like 'TEST\_GD%' escape '\'	
	or (object_name like 'TEST\_DI%' escape '\' 	  
	and object_name <> 'TEST_DIDIER'));
select name, value from v$parameter where name IN ('optimizer_features_enable', 'control_management_pack_access')
union all
select 'IPT_MIN_MAX_SAMPLE', :v_min_pt_sample||' to '||:v_max_pt_sample from dual;
set feedback on termout on
set sqlprompt '&gname> '
set timing on
